# Shardrail — Stage 0 Planning Workspace

**Fork Horizon · Documentation restructure only · No application code**

Start at [`planning/MASTER_PLAN.md`](planning/MASTER_PLAN.md).

This package separates the original single-file Stage 0 architecture draft into topic-scoped Level 1 files so that future models can review one domain without reading all 20 original sections. A lossless copy of the original document remains under `planning/source/`.

**Important:** The uploaded draft is Russian. The source extracts remain Russian to avoid changing meaning during a structural-only transformation. All governance, index, and future revised project documentation are English; translate each domain to English before its full architecture review using the included procedure.

Nothing in this package approves the architecture, begins Level 2 detailed planning, or authorizes code implementation.
