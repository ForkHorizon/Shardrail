# Reviewer Handoff — Next Independent Review of Shardrail Stage 0

> For the next AI reviewer. Stage 0: research and planning only.

## Rules for you

1. **Do not assume Claude's recommendations are correct.** Treat them as hypotheses, as Claude treated Grok's.
2. **Do not rewrite the project.** Review one packet at a time; propose targeted changes with IDs.
3. **Do not implement code**, run builds, install dependencies, execute providers, commit, or change configs.
4. **Verify important technical claims independently** using primary sources; record URL + access date.
5. **Focus on material architectural disagreements**, not style.
6. **Report evidence and confidence** with labels VERIFIED / INFERRED / UNVERIFIED / CONTRADICTED / REQUIRES FUTURE EXPERIMENT.
7. **Preserve traceability:** keep IDs (F, N, B, D, R, U, S, CR, C, E, X); never edit earlier reviews; save yours as a new file, e.g. `reviews/<reviewer>-stage0-r01/` or per-domain per `governance/REVIEW_PROTOCOL.md`.
8. Nothing is owner-approved. Do not mark anything approved.

## Five layers — keep them distinct

| Layer | Where | Nature |
| --- | --- | --- |
| 1. Original Grok architecture | `source/MASTER_PLAN.original.ru.md` (authoritative), English in `level-1/` | baseline |
| 2. Claude's independent critique | `reviews/claude-stage0-r01/01-INDEPENDENT-REVIEW.md`, `02-STRESS-TEST.md` | written before any revision |
| 3. Claude's proposed revisions | `candidates/claude-stage0-v0.2/` | PROPOSED delta over the baseline |
| 4. Unresolved disagreements | `candidates/claude-stage0-v0.2/90-CONSISTENCY-REPORT.md`, registers (U9–U15), packets "Challenge especially" | open |
| 5. Provisional future planning | `level-2/proposed/`, `backlog/proposed/` | PROPOSED; governance conflict C-13 |

## Recommended review sequence

| Order | Packet | Why first |
| --- | --- | --- |
| 1 | [P1 security & approvals](packets/P1-security-and-approvals.md) | Highest-severity findings (CR-01, CR-03, CR-04) |
| 2 | [P4 providers & Claude terms](packets/P4-provider-integrations.md) | Product-critical open question U9 |
| 3 | [P3 session/event engine](packets/P3-session-event-engine.md) | Foundation for everything else |
| 4 | [P2 transport & multi-host](packets/P2-client-transport-and-multihost.md) | Defines client boundary |
| 5 | [P5 technology/UI/performance](packets/P5-technology-ui-performance.md) | Depends on 3–4 |
| 6 | [P6 roadmap/backlog](packets/P6-roadmap-and-backlog.md) | Depends on all |

## Known weak points in Claude's evidence
Primary sources not read: Grok/xAI docs, `claude-agent-acp` README and license, Codex behavior on approval waits/concurrent turns. All performance numbers are proposed budgets. The Level 1 English text was produced by one translation agent; bilingual modality review is pending.

## Output expected from you
Per packet: findings (severity, IDs, evidence, confidence), agreement/disagreement with each relevant CR and D, recommended edits with exact target files, and a recommendation (ACCEPT / ACCEPT WITH CHANGES / REWORK / INSUFFICIENT EVIDENCE).
