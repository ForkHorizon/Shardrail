# Final Architecture Work Summary — Claude Stage 0 Round r01

> 2026-10-15 · Claude (Opus 5.5) · Stage 0 only: **no application code, no builds, no installs, no provider execution, no commits, no config changes.** Nothing is owner-approved.

## 1. Activities completed

| WP | Result |
| --- | --- |
| A Inventory | Repo had no commits; Grok plan preserved byte-for-byte; 15 Russian domain extracts; governance in English; no prior reviews |
| B Baseline | All 15 Level 1 files translated in place to English (one agent; ID/table/URL/fence counts verified identical; 2 translation questions; bilingual modality review pending) |
| B Review | 25 findings + minor set; 4 BLOCKING (CR-01 agents can drive the approval channel; CR-02 WebView cannot use the specified socket API; CR-03 untrusted rendering; CR-04 Git viewing executes repo config) + CR-11 Claude terms (blocking for commercialization); verdicts on D1–D15 |
| C Stress test | 12 scenarios: 6 require architecture change, 6 local patches |
| D/E Candidate v0.2 | Delta candidate: improvement proposal, ADR-style register (D1–D15 dispositions, new D16–D30), requirements/budget/risk/question register, change log (40 entries), 8 domain delta docs |
| F Modules | 18-module index; 5 Level 2 outlines (core/supervision, session-event engine, adapter framework, approvals/control plane, client gateway) |
| G Backlog | Phases P0–P4 (P1 sliced 1a–1d), 33 epics, 19 candidate tasks (6 research), dependency graph with gates |
| H Consistency | 14 contradictions (1 fixed in own draft), impact map, adversarial self-review |
| I Handoff | Reviewer handoff + 6 domain packets |

## 2. Changed / created files

- **Modified (translation only):** `planning/level-1/01…15-*.md` (header `Language status:` line + bodies).
- **Created:** `planning/translation/records/2026-10-15-claude-en-r01.md`; `planning/reviews/claude-stage0-r01/{00-DOCUMENTATION-INVENTORY,01-INDEPENDENT-REVIEW,02-STRESS-TEST}.md`; `planning/candidates/claude-stage0-v0.2/*` (12 files); `planning/level-2/proposed/*` (6 files); `planning/backlog/proposed/BACKLOG.md`; `planning/handoffs/claude-stage0/{CHECKPOINT,REVIEWER-HANDOFF,FINAL-SUMMARY}.md` + `packets/` (6 files).
- **Appended (index pointers only):** `planning/MASTER_PLAN.md`, `planning/reviews/README.md`.
- **Untouched:** `source/`, `manifest.json`, `governance/`, `README.md`.

## 3. Key findings (short)

1. The baseline's direction is sound and disciplined; retain it.
2. The approval channel must be protected **from the agents it governs** (same-UID problem).
3. The client path needs one wire protocol plus a desktop relay; the browser and remote hosts need explicit, authenticated paths (SSH stdio bridge).
4. Provider streams are token-granular and replay on load: use two event tiers, replay reconciliation, intent journaling, and schema versioning.
5. Window close must not kill agents; approvals must survive client disconnects and resolve exactly once.
6. Hard refusal of unknown provider versions will not survive real release cadences; use compatibility classes.
7. **Claude Agent SDK terms** (no claude.ai login for third-party products without approval) are a product-level open question.

## 4. Remaining disagreements / open items for the owner

U9 Claude terms · U10 approval expiry default · U11 separate agent user · U13 Rust vs Go proficiency · U14 repo visibility and U3 license (not decided by Claude) · U6 continuous Mac · D24 warn-and-run · governance conflict C-13 (Level 2 drafts in Stage 0).

## 5. Recommended next review sequence

Independent reviewer per `REVIEWER-HANDOFF.md`: P1 → P4 → P3 → P2 → P5 → P6. In parallel the owner can act on U9 (legal/policy) and U13/U14/U3 without waiting for reviews. Then reconcile, owner decisions, and only then authorize Phase 0 spikes (S1–S8).
