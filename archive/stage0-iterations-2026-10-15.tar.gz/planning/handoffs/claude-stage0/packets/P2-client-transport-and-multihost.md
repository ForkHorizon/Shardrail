# Review Packet P2 — Client Transport, Identity, Multi-Host

| Field | Content |
| --- | --- |
| Primary document | `level-2/proposed/L2-05-client-gateway-and-wire-protocol.md` |
| Minimal context | `candidates/claude-stage0-v0.2/d04-system-and-process.md`; baseline `level-1/03-technology-selection.md` §4.6, `level-1/04-system-and-process-architecture.md`; review CR-02, CR-13, CR-14, CR-15 |
| Decision IDs | D2, D4, D11, D16, D21, D25, D28; U4, U6, U15; C-03, C-05, C-06 |
| Key external evidence | none primary for relay performance (UNVERIFIED); Codex `--listen unix://` (E-03) for comparison |
| Status | PROPOSED |
| Outstanding questions | relay latency (S5); browser credential storage; remote `shardraild` PATH friction |
| Disagreement with baseline | baseline routes the WebView to the Unix socket directly (not possible) and leaves SSH forwarding manual |
| Challenge especially | Is the Tauri relay better than a loopback WebSocket for the desktop? Is the SSH stdio bridge the right default? Is client-side federation enough for "unified management"? |
