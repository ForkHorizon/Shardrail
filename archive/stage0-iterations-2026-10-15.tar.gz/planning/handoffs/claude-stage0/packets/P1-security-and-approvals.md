# Review Packet P1 — Security, Approvals, Control Plane

> PROPOSED material under review. Do not assume Claude's recommendations are correct.

| Field | Content |
| --- | --- |
| Primary document | `candidates/claude-stage0-v0.2/d08-security.md` |
| Minimal context | baseline `level-1/08-security-and-trust.md`; review `reviews/claude-stage0-r01/01-INDEPENDENT-REVIEW.md` CR-01, CR-03, CR-04, CR-07, CR-14, CR-19; `level-2/proposed/L2-04-approval-and-control-plane-security.md` |
| Decision IDs | D12 (modified), D13, D14, D19, D20, D21, D22, D23; R3, R15, R17, R18, R19; U10, U11, U12 |
| Key external evidence | E-06 (Hermes timeout/auto-allow warning), E-07 (git `core.fsmonitor`), E-03 (Codex approvals, `serverRequest/resolved`) |
| Status | PROPOSED; S7/S8 not run |
| Outstanding questions | U10 default expiry; U11 separate agent user; effectiveness of D20 per sandbox profile |
| Areas of disagreement with baseline | D12 timeout/window-close semantics; single bridge secret; Git via CLI |
| Challenge especially | (1) Is CR-01 overstated given provider sandboxes? (2) Is `hold_until_provider_limit` safe given stale-context approvals? (3) Is library-based Git realistic for worktrees/diff? (4) Is D22 sufficient for approval-card integrity? |
