# Review Packet P3 — Session/Event Engine, Journal, Recovery

| Field | Content |
| --- | --- |
| Primary document | `level-2/proposed/L2-02-session-event-engine.md` |
| Minimal context | `candidates/claude-stage0-v0.2/d06-sessions-events.md`, `d07-data-recovery.md`; baseline `level-1/06-…`, `level-1/07-…`; review CR-05, CR-06, CR-09, CR-16, CR-17; stress test S-1, S-2, S-5, S-9, S-12 |
| Decision IDs | D5, D17, D18, D26, D30; B4, B7, B10, B12, B13, B15; R22 |
| Key external evidence | E-01 (ACP load replays, resume does not), E-03 (`item/completed` authoritative, deltas) |
| Status | PROPOSED; delta rates unknown (X-03) |
| Outstanding questions | checkpoint interval; projection snapshot persistence; retention defaults |
| Disagreement with baseline | every update as durable event; dedup by external IDs; linear state enum |
| Challenge especially | Is the two-tier model worth its complexity vs journaling all deltas with compaction? Are the state dimensions minimal? |
