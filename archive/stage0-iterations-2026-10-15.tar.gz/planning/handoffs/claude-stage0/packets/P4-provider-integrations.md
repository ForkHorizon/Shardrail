# Review Packet P4 — Provider Integrations and Claude Terms

| Field | Content |
| --- | --- |
| Primary document | `candidates/claude-stage0-v0.2/d05-provider-integrations.md` |
| Minimal context | baseline `level-1/05-provider-integrations.md`; `level-2/proposed/L2-03-provider-adapter-framework.md`; review CR-05, CR-10, CR-11, CR-12, CR-20, CR-25 |
| Decision IDs | D6, D7, D8, D24, D29; F1, F13, F15; R1, R16, R20; U9 |
| Key external evidence | E-01…E-06, E-09, E-10 (with labels) |
| Status | PROPOSED; S1–S4 not run; E-10 UNVERIFIED |
| Outstanding questions | U9 Claude terms (owner/legal); Grok `session/resume`; Codex concurrent turns |
| Disagreement with baseline | hard version refusal; uniform process-per-session; Claude gated only by license |
| Challenge especially | Does E-04 actually apply to a locally installed orchestrator? Is warn-and-run for untested versions safe enough for approval semantics? |
