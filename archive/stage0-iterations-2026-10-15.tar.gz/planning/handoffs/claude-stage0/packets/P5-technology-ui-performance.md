# Review Packet P5 — Technology, UI Pipeline, Performance Budgets

| Field | Content |
| --- | --- |
| Primary document | `candidates/claude-stage0-v0.2/01-IMPROVEMENT-PROPOSAL.md` §3.1–3.4 |
| Minimal context | baseline `level-1/03-…`, `level-1/09-performance.md`, `level-1/10-…`; `candidates/…/d10-interface.md`; register `03-RISK-QUESTION-REGISTER.md` §2; review CR-18, CR-21, CR-22, CR-23 |
| Decision IDs | D1, D2, D3, D27; B3, B4, B8, B11–B16; U8, U13; C-07, C-08, C-14 |
| Key external evidence | E-08 (Tauri 2.12.3). No measurements exist. |
| Status | PROPOSED; all budgets unmeasured |
| Outstanding questions | WKWebView total footprint; framework choice; owner Rust/Go proficiency |
| Disagreement with baseline | B3 methodology; Rust safety argument vs Go; UI scope |
| Challenge especially | Are B11–B16 the right budgets? Is a web UI the right bet for "exceptional responsiveness" vs a native/GPU UI on desktop? |
