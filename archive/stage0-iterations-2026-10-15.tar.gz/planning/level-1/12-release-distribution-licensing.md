# Packaging, Delivery, and Licensing

> **Stage:** 0 / Architecture Sandbox  \
> **Status:** DRAFT — NOT APPROVED  \
> **Source:** `planning/source/MASTER_PLAN.original.ru.md`, sections 14, 15  \
> **Scope:** Delivery targets, provider updates, repository policy, and distribution/licensing assumptions.  \
> **Language status:** English translation (Claude, 2026-10-15, record: planning/translation/records/2026-10-15-claude-en-r01.md). The Russian original in planning/source/MASTER_PLAN.original.ru.md remains authoritative for what the drafting agent wrote.

---

## 14. Build, Delivery, Updates

| Target | Form |
| --- | --- |
| macOS | a signed and notarized application. The shell updates through its own channel (Tauri updater, as long as D2 is alive). The daemon lies inside the bundle and is not registered as a LaunchAgent in the MVP |
| Linux | a single binary `shardraild`, a systemd user unit, a checksum in the release. A distribution package — later, if demand appears |
| Browser | static files from the same frontend, served by the daemon only on loopback together with the bridge |
| Android | phase 3, a separate decision: Play internal or a direct apk. Not in the MVP |
| Providers | not inside the Shardrail installer |

Shardrail auto-update does not pull new Codex, Grok, Claude, and Hermes. Grok officially has `GROK_DISABLE_AUTOUPDATER` and `--no-auto-update`; the daemon sets them for the Grok process it spawned itself. For Codex, Claude, and Hermes no such flag was recorded in this pass: there the protection is the version pin and refusal to start on an unknown version, not an invented environment variable. The user updates the provider explicitly, after which Shardrail re-checks the version.

The daemon data directory on Mac: `~/Library/Application Support/Shardrail/`. On Linux: `$XDG_DATA_HOME/shardrail/`. Nothing is written alongside it into `~/.codex`, `~/.grok`, `~/.claude`, `~/.hermes`, other than what the provider itself writes in the course of its work.

---

## 15. GitHub, License, Distribution

The repository ForkHorizon/Shardrail currently has no commits. The plan recommends:

- Keep the repository private until a license is chosen (U3).
- The product license by default for Fork Horizon's commercial path: all rights reserved, proprietary source. Apache-2.0 / MIT are applied only to those pieces that Fork Horizon deliberately publishes.
- v1 dependencies: Rust crates under Apache-2.0/MIT (including `agent-client-protocol` and Tauri). GPL/AGPL are not accepted.
- Codex and Hermes are not build dependencies. Their licenses (Apache-2.0 and MIT) allow the user to run them alongside. This does not give Shardrail the right to embed their sources.
- The Claude adapter and the Agent SDK are distributed through their own channels. Before **embedding** an npm package into the application, a lawyer reviews the license of the specific package. Until then the package is installed on the user's machine, like Claude Code itself. This is a condition of a commercial installer.
- `NOTICE` is maintained from the first dependency, not "before release".
- Session logs are not put into public issues. The bug template asks for the Shardrail version, the provider version, and a redacted diagnostic.
- Secrets, `auth.json`, and session databases are in `.gitignore` from the first code commit. The `planning/` directory is included in the repository.

The trademark and the name Shardrail are checked separately (U5). The plan does not consider the name free merely because the repository was created.

---
