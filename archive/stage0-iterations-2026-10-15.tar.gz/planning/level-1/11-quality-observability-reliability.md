# Quality, Observability, and Reliability

> **Stage:** 0 / Architecture Sandbox  \
> **Status:** DRAFT — NOT APPROVED  \
> **Source:** `planning/source/MASTER_PLAN.original.ru.md`, sections 13  \
> **Scope:** Contract testing, operational diagnostics, failure recovery, and reliability behavior.  \
> **Language status:** English translation (Claude, 2026-10-15, record: planning/translation/records/2026-10-15-claude-en-r01.md). The Russian original in planning/source/MASTER_PLAN.original.ru.md remains authoritative for what the drafting agent wrote.

---

## 13. Verification, Observability, Reliability

### 13.1. Tests

- Adapter contract on recorded JSON fixtures. The model network does not go into ordinary CI.
- Drift: the Codex schema taken from the pinned CLI is compared with the file in the repository.
- Journal: kill -9 between WAL commits, replay of commands with the same `command_id`, secret redact.
- Approval: a fake agent, the timer, closing the client; deny does not turn into allow on repeated delivery.
- Trust: starting the Claude adapter in `unknown` does not spawn a process.
- UI: one end-to-end path on a fake daemon — open a session, receive a tool, answer deny, see `idle`. This is a behavior check, not a screenshot.
- Soak B8 — an overnight run before closing a phase, not on every commit.
- The live Phase 0 spikes lie separately and do not become mandatory CI.

### 13.2. Observability

Structured spans: `provider.spawn`, `provider.event`, `journal.append`, `client.flush`, `approval.wait`. Session identifiers may be logged. Prompt bodies and tool outputs are not written to the daemon log by default; for that there is the journal with redact and a separate debug flag for a single session.

The diagnostics panel shows: provider versions, binary path, socket state, event count, the adapter's last error. This is enough. An external APM is not connected.

### 13.3. Reliability That Is Easy to Overcomplicate

Redelivery of incoming events: dedup by (`ProviderSessionRef`, external event id), if there is one. If the provider gives no id, dedup is not invented, and a process break starts a new projection with the marker "stream reconnected".

Exponential retries to the model are not written. The providers already do them. The supervisor restarts a process only on a human's command, when the state is `degraded`.

---
