# Performance and Resource Budgets

> **Stage:** 0 / Architecture Sandbox  \
> **Status:** DRAFT — NOT APPROVED  \
> **Source:** `planning/source/MASTER_PLAN.original.ru.md`, sections 11  \
> **Scope:** Resource budgets B1–B10, measuring methodology, UI event workload, and scope of measurements.  \
> **Language status:** English translation (Claude, 2026-10-15, record: planning/translation/records/2026-10-15-claude-en-r01.md). The Russian original in planning/source/MASTER_PLAN.original.ru.md remains authoritative for what the drafting agent wrote.

---

## 11. Performance

The dominant memory consumers are the WebView and the provider processes (Grok's Rust binary, the Codex process, Python Hermes, the Claude process and possibly Node for the Claude adapter and for the Codex npm wrapper). Optimizing the daemon's language will not compensate for an extra Chromium or a process "just in case". Therefore Electron is excluded, a shared provider process is not enabled until a spike, and Hermes browser tools are not installed.

The budgets are phase gates, not a report of measurements. Reference machine: an Apple Silicon Mac with 16 GB, which Fork Horizon will name explicitly (U1 may replace the model, not the orders of magnitude of the budgets, without a new entry in the plan).

| ID | Budget | What is included | How to measure |
| --- | --- | --- | --- |
| B1 | daemon RSS at idle ≤ 40 MB after 60 s | `shardraild`, 0 sessions | process RSS sampling |
| B2 | ≤ 15 MB per idle session projection inside the daemon | daemon only | RSS difference |
| B3 | macOS window at idle ≤ 180 MB | shell + WKWebView, empty transcript | shell RSS |
| B4 | p95 from event receipt by the daemon to the frame ≤ 50 ms | local socket, 1 active session | span in the daemon and a frame mark in the UI |
| B5 | composer input on an empty turn fits within a 16 ms frame | UI | input trace in spike S5 |
| B6 | cold start to a ready window ≤ 1.5 s | shell + daemon listening on the socket | time mark, without provider login |
| B7 | after kill -9 the session list is visible again ≤ 1 s | daemon + SQLite | integration test |
| B8 | over 8 hours daemon RSS ≤ 1.3× the value at the 10th minute | 1 active + 2 idle projections | soak; provider leaks are recorded separately and are not "fixed" by the daemon's budget |
| B9 | no periodic timer more often than 15 s at rest | daemon and UI code | supervisor review + a test that fails on a forbidden interval |
| B10 | writing a batch of events ≤ 50 ms at 200 events per turn | SQLite, one writer | bench in the journal crate, on the reference machine |

Provider processes are not included in B1–B3. The phase report shows them in a separate column. If WKWebView on the reference machine is by itself above B3, the budget is revisited **together with the measurement** and with a decision on whether Tauri stays. The number cannot be quietly raised.

Git status does not tick on a timer. The source is FSEvents/inotify with a 200 ms debounce and a refresh button. A large tree is virtualized. A full repository walk is not done when the window opens: first one level, deeper on expansion.

The transcript is virtualized. Holding tens of thousands of DOM nodes is not allowed. The spike's target scenario: 5,000 events in one session, scrolling without the window RSS growing by more than 80 MB over B3. This is also a budget, checked by S5.

The model's network is not included in the budgets. Shardrail does not speed up the provider.

---
