# Original Self-Review and Evidence

> **Stage:** 0 / Architecture Sandbox  \
> **Status:** DRAFT — NOT APPROVED  \
> **Source:** `planning/source/MASTER_PLAN.original.ru.md`, sections 19, 20  \
> **Scope:** The drafting agent’s own retrospective and the source bibliography; not an independent review.  \
> **Language status:** English translation (Claude, 2026-10-15, record: planning/translation/records/2026-10-15-claude-en-r01.md). The Russian original in planning/source/MASTER_PLAN.original.ru.md remains authoritative for what the drafting agent wrote.

---

## 19. Critical Review

A check of the plan for excess complexity, hidden dependencies, security holes, and unrequested numbers.

**Excess that was deliberately struck out.** Separate services per adapter, a broker, a shared "tool platform" process, a plugin marketplace, a code editor, kanban, synchronization of several writers, an embedded Chromium, client-side execution of the ACP terminal, auto-continuation of a turn after a reboot, FTS before measurement, a second state manager, a bundle of other vendors' CLIs.

**Hidden dependencies that remain.** Python for Hermes. Possible Node for the Claude adapter and for the Codex wrapper. The system WebView. OpenSSH in phase 2. These are dependencies of the user's machine, not of the core build graph, and they are named in 17.1. They are easy to overlook in RSS. That is why the provider budget is a separate column.

**The framework that the plan still accepts.** Tauri. The justification is narrow: a window shell and the system WebView, with the domain protocol outside. The fallback exit is recorded in D2 before business logic is written on Tauri. If the implementation starts calling `invoke` for sessions and approvals, that is a violation of D2, not a "convenient extension".

**Holes that the plan does not close, stated directly.** R3: isolation of agents on one unix user is weak. macOS does not cut the network for child processes in the Grok profiles `read-only` and `strict`. Shardrail does not verify the provider binary's signature in the MVP. A handoff may carry a secret away if a human pastes it themselves or the denylist does not know the prefix. These are residual risks, not forgotten tasks.

**Where the plan could lie about speed.** B1–B8, Go GC pauses, Electron RSS, and the gain of Rust over Go are not measured. In the text these are budgets and risk classes. The only quantitative facts from outside that are used as facts: version numbers, Tauri release dates, the existence of protocols. If the implementation substitutes "it's approximately so" for a budget without a run, the phase is not closed.

**Where the plan could promise excess control.** Attach to a live TUI, loading an arbitrary Hermes CLI session, the Codex `queue` through app-server, Grok's `auto` mode as human approval, Grok's network-deny on macOS. All of this is either Unsupported or awaits a spike.

**Internal consistency.** D4 (the socket) makes D2 reversible. D7 is consistent with R7 and with the ban on `thread/shellCommand`. D8 is consistent with R9: the process memory is not hidden in the daemon's budget. D10 is consistent with F11. D11 is consistent with U6. D14 does not let "CLI convenience" override the safe default. Phase 3 does not start while U4 is open. Claude may drop out of Phase 1 without rewriting the other adapters, because the capability model allows it.

A repeat pass through the local Codex reference caught the `daemon` and `proxy` subcommands and the experimental marker on `generate-json-schema`. The plan narrowed the channel to a separate stdio process and stopped promising auto-update suppression where the official flag is visible only for Grok. The Claude `-p` signals are no longer carried over to the ACP adapter.

**What this review did not do.** It did not run live protocols, did not measure RSS, did not read secrets in the providers' home directories, and did not change their settings.

The plan is internally consistent at the level of decisions. It has not yet been confirmed by spikes. Approval of the architecture permits Phase 0, not the writing of the product.

---

## 20. Evidence

Access date: 2026-10-13. Local versions were taken with `--version` / `--help` commands without changing the configuration.

| Source | What was taken |
| --- | --- |
| <https://developers.openai.com/codex/app-server> | app-server as a rich-client protocol; stdio; WebSocket experimental and not for production; WS-auth; omission of the `jsonrpc` header on the wire |
| <https://developers.openai.com/blog/codex-as-a-platform> (page dated 2026-10-10) | app-server for a product with a stream and approval; SDK for programmatic tasks; `codex exec` for non-interactive jobs |
| <https://developers.openai.com/codex/sdk> | the SDK controls a local Codex, sandbox presets |
| <https://developers.openai.com/codex/concepts/sandboxing> | sandbox and approval are different axes; `workspace-write` + `on-request`; `danger-full-access` |
| App-server documentation, the `thread/shellCommand` fragment | a user command outside the sandbox and without the thread's policy. The method is forbidden in the regular UI |
| Local `codex --help` and `codex app-server --help` 0.160.0 | `app-server` experimental; there are `queue`, `resume`, `fork`, `agents`; app-server has `daemon`, `proxy`, `generate-json-schema` (also experimental); `--analytics-default-enabled` is not the default |
| <https://github.com/openai/codex> and `docs/license.md` | Apache-2.0 |
| <https://code.claude.com/docs/en/headless> | `-p`, `stream-json`, `--bare`, hooks without a trust dialog, permission host, SIGTERM 143, `--permission-prompts none` |
| <https://code.claude.com/docs/en/agent-sdk/overview> and the TypeScript reference | the Agent SDK launches Claude Code; `canUseTool`; `interrupt()`; the package `@anthropic-ai/claude-agent-sdk` |
| <https://code.claude.com/docs/en/permission-modes> | modes, including auto and default/manual; the document's dates 2026-10-11 |
| <https://github.com/agentclientprotocol/claude-agent-acp> | the official Agent SDK adapter into ACP; repository activity as of the plan date |
| Local Grok Build 1.0.52 guide: `14-headless-mode.md`, `15-agent-mode.md`, `17-sessions.md`, `18-sandbox.md`, `22-permissions-and-safety.md` | ACP `grok agent stdio` and `serve`; headless is not a two-way channel; `x.ai/*` extensions; sandbox profiles; network no-op on macOS; session storage; auto-update flags |
| <https://agentclientprotocol.com/protocol/overview> | ACP v1: `initialize`, `session/new`, `session/load`, `session/prompt`, `session/cancel`, `session/request_permission`, client-side fs and terminal |
| Grok guide, SDK section | Rust `agent-client-protocol`; Go `acp-go-sdk`; TypeScript, Python, Kotlin |
| <https://hermes-agent.nousresearch.com/docs/user-guide/features/acp> | `hermes acp`, approvals, toolset, persistence, a warning about auto-allow on other vendors' hosts |
| Local Hermes 0.21.6 `--help` | the command `hermes-acp` exists |
| <https://github.com/NousResearch/hermes-agent> | MIT |
| <https://v2.tauri.app/release/core/> | Tauri 2.12.3 of 2026-10-10, the stable line; mobile fixes in the same notes |
| <https://v2.tauri.app/distribute/> | official android/ios build and signing |
| Tauri release notes | `3.0.0-alpha.4` as of 2026-10-01, not taken into the product |
| <https://github.com/agentclientprotocol/agent-client-protocol> | stable protocol version 1; Apache-2.0 |

A third-party overview of "which agents support ACP" was used only as a pointer to the adapter's repository. Capabilities were taken from the primary documents listed above.
