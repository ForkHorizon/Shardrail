# Technology Selection and Alternatives

> **Stage:** 0 / Architecture Sandbox  \
> **Status:** DRAFT — NOT APPROVED  \
> **Source:** `planning/source/MASTER_PLAN.original.ru.md`, sections 4  \
> **Scope:** Language, shell, UI, storage, and transport candidates, plus local environment assumptions.  \
> **Language status:** English translation (Claude, 2026-10-15, record: planning/translation/records/2026-10-15-claude-en-r01.md). The Russian original in planning/source/MASTER_PLAN.original.ru.md remains authoritative for what the drafting agent wrote.

---

## 4. Technology Selection and Alternatives

### 4.1. How They Were Compared

Criteria, in order of weight: official controllability; isolation and recoverability; predictable memory consumption; number of languages and processes; reversibility; license. Fork Horizon has no measured benchmarks for these options. Where a number is unknown, a budget and a spike are given.

### 4.2. Core Language

**Recommendation D1. A Rust-centric core.** One daemon and the adapter code in Rust. TypeScript remains only in the frontend, because the browser and WKWebView require it. There is no Go in v1.

Why Rust is appropriate here:

- Stable ACP v1 has an official Rust crate `agent-client-protocol` (Apache-2.0). Grok and Hermes speak the same protocol.
- Tauri 2, chosen as the macOS shell, already brings Rust. A second systems language simplifies nothing.
- The daemon lives long, parses untrusted JSON, and holds many stdio streams. The absence of a GC removes a whole class of pauses. This is a risk, not a measured win: if budget B4 fails and the trace shows it is not GC, the language is not to blame.
- The Linux daemon builds into a single binary with no runtime, alongside the Python and Node processes that the providers bring anyway.

**Alternative A. A Go daemon + Rust only inside Tauri.** Per decision D4, the domain protocol does not go through Tauri IPC. Rust would then remain only for the window frame. That is two systems toolchains and a shared protocol model that must be maintained in both, or dead Rust. Such a split gives no isolation and does not reduce RSS: it is eaten up by the WebView and the provider processes.

**Alternative B. A Go daemon and a thin WKWebView without Tauri.** An honest alternative, not "Go + Rust". Go handles processes, HTTP, and cancellation well. The ACP library `acp-go-sdk` (coder) is listed in the Grok guide; it is not a crate of the agentclientprotocol organization. It is the fallback path if a spike or the first phase shows that the Rust edit cycle derails the calendar. Condition for revisiting D1: two consecutive phases run late because of compilation or hiring, or B4 fails for a reason Rust does not cure.

**Alternative C. A TypeScript daemon.** The Claude Agent SDK and the ACP examples are written in TypeScript. Rejected as the core: Node becomes a mandatory runtime for all sessions, not just for the Claude adapter. Memory and dependence on the npm graph contradict N1 and N8.

Performance: the gain from the core language is smaller than the decision not to embed Chromium and not to keep an extra process per session. Security: Rust does not replace the provider's sandbox. It reduces the chance of memory corruption in the supervisor. Maintenance: one systems language, a cargo workspace. Risk: slow compilation. Mitigation: small crates, no monolith of procedural macros. Confidence: **medium**. Facts about the libraries are verified; the latency gain is not.

### 4.3. Interface Shell

**Recommendation D2. One web client. On macOS it is hosted by Tauri 2 (stable line 2.12.x as of 2026-10-10) and the system WKWebView.** The client's domain API is the daemon socket, not Tauri commands. The shell provides the window, menu, dialogs, deep link, and keychain for Shardrail's own token.

Tauri 3 was `3.0.0-alpha.4` as of 2026-10-01. It is not taken into the product.

Why:

- Three native UIs (SwiftUI, Kotlin, web) are more expensive for the Fork Horizon team than one interface, and the scenarios coincide.
- The system WebView does not drag in a second Chromium. Tauri's official architecture is the OS's native renderer. The concrete RSS on Mac is budget B3 and spike S5, not a promise.
- Electron is rejected: a separate Chromium for each window conflicts with the principle of low consumption. No number is put in the plan until it is measured against B3.
- GPUI / a custom immediate-mode UI give speed on desktop and do not give a browser with Android without a second client.
- Dioxus reduces the languages to Rust, but the ecosystem of accessible complex UI is weaker than the web platform's. For the visual bar this is a bigger risk than the WebView.

**Fallback path for D2:** if S5 shows that WKWebView through Tauri does not fit B4 or B5, the macOS shell is replaced with a thin Swift WKWebView. The frontend and the daemon are not rewritten, because they are not tied to Tauri IPC.

Android: the official Tauri 2 documentation supports `android build` and Play publication. This is not proof that the side panel, keyboard, and long stream will be good. The Android client is phase 3, after the web client already talks to the daemon over the socket. The fallback path is the system WebView in a small Kotlin shell. Confidence in Tauri desktop: **medium**. Confidence in Tauri Android as Shardrail quality: **low**, which is why it is not the MVP.

### 4.4. Frontend

**Recommendation D3. TypeScript without a separate state layer.** The source of truth is the daemon journal. The window holds a projection plus local view state (expansion, focus, draft). Redux, MobX, and similar stores are not added.

The rendering candidate is SolidJS: the session stream is appended frequently, and fine-grained updates are more suitable here than a virtual DOM. React is acceptable if an accessible component without which N7 cannot be met exists only for React. The choice is closed by spike S5 on the same transcript mockup. Until the spike, the framework in product code is not fixed more tightly than "TypeScript, one renderer, no second state manager".

A heavy UI kit (Material, full Chakra) is not adopted. It imposes someone else's look and an extra runtime. Our own set of tokens and a short list of primitives are in section 12.

### 4.5. Storage

**Recommendation D5. SQLite in WAL mode, one file per daemon, one writer.** `rusqlite` with bundled SQLite, so the engine version does not depend on the OS. A separate Postgres, an object store, and a search cluster are not needed at the scale of a single owner.

The event journal is an append-only table. Session snapshots are a projection that can be rebuilt. FTS is enabled only if search over local history does not fit the budget on a journal of reasonable size. There is no FTS before measurement.

### 4.6. Client — Daemon Transport

**Recommendation D4. Locally: a unix socket and a single JSON protocol over it.** Frames are length plus JSON. For a browser that needs a WebSocket, the daemon raises a loopback bridge only together with the window or an explicit "open in browser". `Origin` check. The bridge secret is in a `0600` file, not in command-line arguments.

Remotely in phase 2: an SSH local forward to this socket. Its own NAT traversal, its own public TLS, and Tailscale as a mandatory dependency are not included. The convenience of SSH on Android is open question U4. While it is open, phase 3 does not promise "a phone without tunnel setup".

Background state polling is not used. The socket is either alive and events flow, or it is dropped and the session is `degraded`.

### 4.7. What Is Already on the Development Machine (Fact, Not a Goal)

The reference was taken on 2026-10-13, configurations unchanged.

| Tool | Fact |
| --- | --- |
| Codex | `codex-cli 0.160.0`, path through the npm wrapper `@openai/codex` |
| Grok Build | `grok 1.0.52` |
| Hermes | `0.21.6+763.g1fd1827`, git installation in `~/.hermes/hermes-agent`, commands `hermes` and `hermes-acp` |
| Claude Code | the `~/.claude` directory exists, the `claude` binary was not found in `PATH` |

The Codex npm wrapper may remain resident. Its RSS counts toward the provider's budget, not the daemon's. Spike S1 measures this.

---
