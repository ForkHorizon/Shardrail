# Provider Integration and Capabilities

> **Stage:** 0 / Architecture Sandbox  \
> **Status:** DRAFT — NOT APPROVED  \
> **Source:** `planning/source/MASTER_PLAN.original.ru.md`, sections 7  \
> **Scope:** Adapter contracts, per-provider capabilities, protocol-specific handling, and limitations.  \
> **Language status:** English translation (Claude, 2026-10-15, record: planning/translation/records/2026-10-15-claude-en-r01.md). The Russian original in planning/source/MASTER_PLAN.original.ru.md remains authoritative for what the drafting agent wrote.

---

## 7. Adapters and Capability Matrix

### 7.1. Adapter Contract

An adapter reports capabilities. The core does not call a method that is not in the capability set. The mandatory MVP minimum: `start`, `prompt`, `stream`, `cancel`, `approve`, `health`. Everything else is optional.

The common event projection: `session_started`, `turn_started`, `text`, `thought`, `tool_started`, `tool_updated`, `permission_requested`, `permission_resolved`, `plan`, `usage`, `turn_finished`, `session_degraded`, `notice`. Fields with no counterpart are not invented. Provider-specific fields are preserved in `provider_ext` and may have their own block in the UI.

ACP v1 is the baseline for Grok and Hermes. The ACP v2 draft is not used. Grok's `x.ai/*` extensions are vendor-specific. By the ACP specification, custom methods should start with `_`, while Grok uses the prefix `x.ai/`. They are discovered from `initialize`, not hardcoded as a list from the guide as an eternal contract.

In the MVP the ACP client **does not declare** `fs.writeTextFile` and `terminal`. Otherwise the agent would ask Shardrail itself to write files and run commands, bypassing the provider's sandbox. File operations are performed by the agent's tool. Shardrail merely answers `session/request_permission`. Reading the tree for the UI is done by the daemon itself, read-only, for a known cwd.

### 7.2. Matrix

Confidence refers to the documents as of 2026-10-13, not to a protocol that was actually run.

| Capability | Codex 0.160.0 | Claude Code | Grok 1.0.52 | Hermes 0.21.6 |
| --- | --- | --- | --- | --- |
| Official rich-client channel | app-server stdio. **Verified** docs; the local help marks it experimental | Agent SDK Python/TS; CLI `-p` for scripts. **Verified** | `grok agent stdio` ACP. **Verified** local guide | `hermes acp`. **Verified** docs and local `--help` |
| Text and tool stream | thread/turn/item. **Verified** description | `stream-json` and SDK partial messages. **Verified** | `session/update`. **Verified** | ACP updates, diff and terminal in the docs. **Verified** description |
| Approval in both directions | app-server protocol. **Verified** presence; exact method names to be checked against the S1 schema | SDK `canUseTool`. For bare `-p` without a permission host the request is **denied**. **Verified** | `session/request_permission`; `_meta.yoloMode`. **Verified** | allow once / session / always / deny. Timeout = deny. **Verified** |
| Resume | `thread/resume`. **Verified** | `--resume` / SDK. **Verified** | `session/load`. **Verified** | load/resume/fork after an ACP restart, history in state.db. **Verified** description |
| Fork | `thread/fork`. **Verified** | not recorded in this pass | `x.ai/session/fork`, `/fork`. **Verified** docs | fork is described. **Verified** docs |
| Sandbox | `read-only`, `workspace-write`, `danger-full-access` separate from the approval policy. **Verified** | permission modes + a separate Bash sandbox. The mode details are fresh and broad as of the docs date; the adapter takes only what the SDK accepts explicitly | profiles `off`, `workspace`, `read-only`, `strict`, `devbox`. On macOS the network block for child processes is a no-op. **Verified** | terminal approval; a Docker backend exists and is **not included** in the MVP |
| Cancel | interrupt in the app-server description. Exact method — S1 | SDK `interrupt()`; SIGTERM with `-p` does **not** end the turn cleanly, code 143. **Verified** | `session/cancel`. **Verified** ACP | `session/cancel`. **Plausible** per ACP, check with S3 |
| Worktree | not consolidated in this pass | not consolidated | `x.ai/git/worktree/*`, `grok worktree`. **Verified** | git worktrees in the user documentation. The link to the ACP cwd is **Plausible** |
| Capturing a live TUI | `codex agents` exists locally. The semantics of intercepting an interactive turn are **Plausible / not promised** | **Unsupported** | the leader socket is described fragmentarily. **Unsupported** as a product | loading a CLI session into ACP is **Plausible**, not promised |
| Remote official transport | WS experimental, not for production. SSH to stdio on the host is our path | not needed: the process is on the host | `serve` on loopback with a secret; we do not need a public relay | stdio; we do not use someone else's relay |
| Cost of an integration mistake | `thread/shellCommand` in the docs executes **outside the sandbox with full access**. It is not exposed in the regular UI | `-p` without `--bare` loads hooks and MCP even from an untrusted folder and does not show the trust dialog. **Verified** | `x.ai/fs/write_file` and `x.ai/terminal/*` are privileged methods. The UI does not call them for "just open a file" | `allow_always` writes a permanent Hermes allowlist |

### 7.3. Per-Provider Policy

**Grok.** The channel is `grok agent stdio`. Headless `grok -p` is suitable for a one-off script, and the document itself says that two-way approvals live in ACP. `updates.jsonl` files are a storage format, not an API. The default sandbox in the product for a new workspace: `workspace`, not `off`. The user may strengthen it to `read-only` or `strict`. `off` requires separate confirmation. On macOS network-deny cannot be promised: the guide says it is a no-op.

**Hermes.** The channel is `hermes acp`. The toolset is the curated `hermes-acp`. Browser tools and their Node/Chromium are not installed in the MVP (`--setup-browser` is not called). The credential stays in `~/.hermes`. `allow_always` in the UI is labeled as a permanent Hermes rule, not as "this time".

**Codex.** The channel is a separate child `codex app-server --listen stdio://` per session until the S1 results. The shared `daemon` / `proxy` is not used. Default policy: `workspace-write` + `on-request`. `danger-full-access` together with `approval never` requires a separate confirmation phrase. `thread/shellCommand` is not bound to a "run in terminal" button. The schema is generated from the pinned CLI and checked in CI as a drift test: a mismatch between the schema and the adapter's expected file stops the build. The schema generator is itself marked experimental, so the reference is the saved file, not "generate on the fly on the user's machine". The adapter does not link the Codex sources. The types are our own, from the schema. The Codex repository license is Apache-2.0; this is not a reason to vendor the tree. `--analytics-default-enabled` is not passed.

**Claude.** The channel for the first implementation is the official adapter `@agentclientprotocol/claude-agent-acp` from the agentclientprotocol organization (the repository was updated 2026-10-13, description: Claude Agent SDK for any ACP client). Permission and resume behavior **was not run**. Spike S4 compares it with the direct SDK. If the adapter loses approval or session resume, the core keeps the ACP client for Grok/Hermes, and Claude gets a narrow supervisor over the SDK. Bare `claude -p` remains a fallback only for a one-off mode without a human: without a permission host, requests are denied. For an interactive Shardrail that is not enough.

Starting Claude in an `unknown` workspace is forbidden. `--bare` is acceptable as a viewing mode, which according to the documentation skips hooks, skills, plugins, MCP, auto memory, and CLAUDE.md. A normal start is only in `trusted` and with an explicit permission mode chosen by the user. `bypassPermissions` is never the default.

The Claude binary was absent from `PATH` on the planning machine. The adapter must detect the version itself. An unverified version does not start without an override.

### 7.4. Incompatibilities That Must Not Be Flattened

- In Codex, sandbox and approval are two axes. In Grok, the sandbox profile and permission mode are also two axes, and they are not equal to Codex's axes. The UI shows both, not a single "autonomy strength".
- In Claude, `auto` is a classifier. In Grok, `auto` in a non-interactive session blocks what the classifier did not let through and does not ask a human. Shardrail, being an ACP client, is exactly what gives the human a channel. Grok's `auto` mode is enabled only if spike S2 shows that requests still reach `session/request_permission`. Otherwise `auto` is hidden in the UI.
- Spend: Grok reports ticks and may omit the cost if it is incomplete. Claude reports an estimate `total_cost_usd` in JSON. Codex was not checked for cost fields in this pass. The UI says "no data", not zero.
- Cancel in Claude via SIGTERM corrupts the turn. The supervisor sends the protocol cancel, then waits, and only then stops the process.

---
