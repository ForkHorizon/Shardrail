# Functional and Nonfunctional Requirements

> **Stage:** 0 / Architecture Sandbox  \
> **Status:** DRAFT — NOT APPROVED  \
> **Source:** `planning/source/MASTER_PLAN.original.ru.md`, sections 3  \
> **Scope:** Functional requirements F1–F13, nonfunctional requirements N1–N9, and acceptance language.  \
> **Language status:** English translation (Claude, 2026-10-15, record: planning/translation/records/2026-10-15-claude-en-r01.md). The Russian original in planning/source/MASTER_PLAN.original.ru.md remains authoritative for what the drafting agent wrote.

---

## 3. Requirements

### 3.1. Functional

| ID | Requirement | Acceptance |
| --- | --- | --- |
| F1 | Detect local binaries and show the version. An unknown or too-new build is marked "not verified"; a session does not start without an explicit override. | Four providers on the reference machine; a substituted `--version` in a fixture. |
| F2 | Create a session with cwd, model, and admission policy. | Protocol fixture test for each adapter. |
| F3 | Send an instruction and show the stream up to the stop reason. | `session/update` / app-server events fixture; the UI renders the final frame. |
| F4 | Show a tool call: name, target, status, truncated input and result. Raw input is available on expansion. | Snapshot of the tool card. |
| F5 | Handle an approval and return the response into the provider's protocol. A timeout and closing the window are equal to deny. | A fake agent does not receive allow after the timer. |
| F6 | Cancel the current turn using the provider's method (`session/cancel`, app-server interrupt, SDK interrupt). | Fixture; live Phase 0 spike. |
| F7 | A queue of one pending instruction per session, if the provider does not accept a second turn. | The second instruction is not sent to stdio until the turn is closed. |
| F8 | Read-only tree and diff of the session directory. If the directory is unknown, that state is shown, not someone else's checkout. | Worktree path test. |
| F9 | The journal survives kill -9 of the daemon. After start, the session list and the last confirmed cursor are in place. | SQLite integration test. |
| F10 | After the provider process dies, the session becomes `degraded`. Resume is offered only if the capability supports it. | stdio-drop fixture. |
| F11 | The handoff bundle opens as the first prompt of another session. The user sees the text before sending. | Bundle assembly test; secrets from the denylist do not get in. |
| F12 | A client that dropped off for 30 seconds catches up on the journal from the cursor and does not duplicate cards. | Cursor test. |
| F13 | A workspace has a trust state: `unknown`, `restricted`, `trusted`. In `unknown` and `restricted`, a session that loads project hooks does not start. | Start-policy test for Claude and Grok. |

### 3.2. Nonfunctional

| ID | Requirement |
| --- | --- |
| N1 | The budgets in section 11 are measured on the reference machine before a phase is declared closed. |
| N2 | In steady state there is no periodic polling more often than every 15 seconds. A stdio drop, FSEvents/inotify, and an explicit refresh button replace polling. |
| N3 | Provider secrets are not read into the Shardrail database and do not leave for another host. |
| N4 | The daemon listens only on a user-owned unix socket `0600` or on loopback with a secret file `0600`. No port is opened externally. |
| N5 | The failure of one adapter does not stop the others. |
| N6 | Every decision in this plan has a condition for revisiting it. A change in a provider's protocol is a sufficient condition. |
| N7 | The interface targets WCAG 2.2 AA for the main scenarios: stream, approval, composer, tree. |
| N8 | Dependency licenses allow Fork Horizon's commercial distribution. Copyleft dependencies are not accepted without a separate legal decision. |
| N9 | Approval correctness and secret isolation are not traded for meeting the latency budget. |

---
