# UI/UX and Visual System

> **Stage:** 0 / Architecture Sandbox  \
> **Status:** DRAFT — NOT APPROVED  \
> **Source:** `planning/source/MASTER_PLAN.original.ru.md`, sections 12  \
> **Scope:** Product interaction principles, accessibility, visual constraints, and UI primitives.  \
> **Language status:** English translation (Claude, 2026-10-15, record: planning/translation/records/2026-10-15-claude-en-r01.md). The Russian original in planning/source/MASTER_PLAN.original.ru.md remains authoritative for what the drafting agent wrote.

---

## 12. Interface and Visual System

Principles:

- Session state is visible without reading solid text: `idle`, `running`, `waiting_approval`, `degraded`, `stalled`.
- Approval is a separate modality, not a line in the chat. The command is monospaced, line breaks are preserved, cwd and sandbox are labeled.
- The model's thought is collapsed by default. It is easy to open, and it does not shout with an error color.
- A file diff reads as a diff, not as raw JSON.
- Protocol errors are written in human language and keep the provider's code on a single line for support.
- Keyboard: composer, send, cancel turn, allow, deny, jump to the next approval. Visible focus.
- Motion is short and can be disabled via `prefers-reduced-motion`. No animation "for liveliness" on every token. Tokens are appended to the text; the tool card is updated in place and not recreated.
- Density is desktop. The phone shows the same data, one column, approval on the first screen.
- Dark and light themes. Contrast of text and states — AA.

Tokens v1, until there is a Fork Horizon brand book (U2): a neutral dark base, one accent color for focus and one for approval-wait, a separate color for deny/degraded. The interface font is the system font. Mono is the system mono. No illustration set and no icon package heavier than a sprite of a dozen glyphs.

MVP primitives: button, field, virtualized list, tool card, approval card, tree, diff, state banner, sandbox indicator. This is the entire design-system scope of the first phase. New primitives are added when a scenario cannot be assembled from these.

The macOS shell respects the system window: ordinary traffic lights, a normal title bar, not a homemade borderless chrome panel. A full-screen "cockpit" is not needed for session management.

Accessibility is checked on scenarios F3–F5 and F8, not by an automated linter report alone. The linter stays in CI as a cheap filter.

---
