# Data, Synchronization, and Recovery

> **Stage:** 0 / Architecture Sandbox  \
> **Status:** DRAFT — NOT APPROVED  \
> **Source:** `planning/source/MASTER_PLAN.original.ru.md`, sections 9  \
> **Scope:** Data ownership, single-writer model, disconnection behavior, and persistence.  \
> **Language status:** English translation (Claude, 2026-10-15, record: planning/translation/records/2026-10-15-claude-en-r01.md). The Russian original in planning/source/MASTER_PLAN.original.ru.md remains authoritative for what the drafting agent wrote.

---

## 9. Data, Synchronization, Recovery

### 9.1. What Lives Where

| Data | Location | Owner |
| --- | --- | --- |
| Shardrail journal, projections, trust, queue, handoff | daemon SQLite, `0600` file | Shardrail |
| Agent transcript and memory | `~/.codex`, `~/.claude`, `~/.grok`, `~/.hermes` | provider |
| Provider secrets | provider stores and the OS keychain, as they do it | provider |
| Loopback bridge token and the shell's update key | OS keychain on Mac; `0600` file on Linux | Shardrail |
| Checkout and worktree | workspace disk | user and agent |

The daemon does not copy the providers' home directories into its database "for offline". After a crash it asks the provider (`thread/resume`, `session/load`) and does not replay a turn from its own copy. Its own copy is needed to show history when the provider process is dead, and it is marked as a projection that may lag.

### 9.2. Synchronization

One writer. Clients are readers with a cursor. There is no two-writer conflict, so CRDT is not needed. Two daemons on one database file are forbidden by a file lock. The second instance exits with a clear error.

The remote daemon is the writer for the agents on that Linux machine. The Mac does not keep a second journal of the same sessions. It shows the remote journal. The Mac's local agents and the Linux agents are different daemons and different databases. Merging the feeds into one global inbox is outside the plan until a real scenario appears. This is a condition for revisiting.

### 9.3. Recovery

| Failure | Behavior |
| --- | --- |
| kill -9 of the daemon | WAL restores the committed events. The uncommitted tail is lost. Sessions start as `degraded`. A repeat prompt is not sent on its own. |
| stdio drop | `degraded`. The `resume` capability decides whether the button is active. |
| Hang without a drop | no polling once a second. If the protocol is silent longer than the turn threshold (starting value 15 minutes without a single event, configurable), the session is `stalled`. The process is not killed automatically. |
| Linux reboot | the daemon comes up, turns are not continued, resume is manual. |
| Mac reboot in the MVP | the daemons were not a service. Sessions are restored as local history plus the provider's resume, if its files are intact. |
| Client dropped in the middle of an approval | the card timeout expires, deny goes to the provider. The safe side is not to execute the command. |
| SQLite corruption | startup stops, the file is renamed to `.corrupt-<time>`, an empty database is created. The providers' directories are not touched. Shardrail history is restored from the user's copy, if there is one. |

Idempotency of client commands: `command_id` on mutate requests. A retry after a network timeout does not create a second session and does not send a second prompt.

---
