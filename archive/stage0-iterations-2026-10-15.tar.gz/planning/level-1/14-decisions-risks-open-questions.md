# Decisions, Risks, and Open Questions

> **Stage:** 0 / Architecture Sandbox  \
> **Status:** DRAFT — NOT APPROVED  \
> **Source:** `planning/source/MASTER_PLAN.original.ru.md`, sections 17, 18  \
> **Scope:** Dependency graph, decisions D1–D15, risks R1–R14, and unknowns U1–U8.  \
> **Language status:** English translation (Claude, 2026-10-15, record: planning/translation/records/2026-10-15-claude-en-r01.md). The Russian original in planning/source/MASTER_PLAN.original.ru.md remains authoritative for what the drafting agent wrote.

---

## 17. Dependencies, Decision Log, Risks

### 17.1. Delivery Dependency Graph

```mermaid
flowchart TD
  S1[S1 Codex] --> P1[Phase 1]
  S2[S2 Grok sandbox] --> P1
  S3[S3 Hermes] --> P1
  S4[S4 Claude] --> P1
  S5[S5 UI budget] --> P1
  S6[S6 no TUI attach] --> P1
  P1 --> P2[Phase 2 Linux]
  P2 --> U4[U4 phone tunnel]
  U4 --> P3[Phase 3 Android]
  P1 --> P4[Phase 4 handoff]
```

External runtime dependencies, not core build dependencies: provider binaries, the system WebView, and on Linux OpenSSH for the phase 2 client. Python is needed by Hermes, not by Shardrail. Node is needed only if S4 keeps the npm Claude adapter or if the Codex npm wrapper does not exec the native binary and exit. S1 and S4 check this.

### 17.2. Decision Log

| ID | Decision | Alternatives | Why | Performance | Security | Maintenance | Risk | Evidence | Confidence | When to revisit |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| D1 | Rust core, no Go in v1 | Go+Tauri; Go+thin WebView; TS daemon | the ACP crate and Tauri are already Rust; a split does not protect the data | gain not measured; budgets B1–B4 | the supervisor's memory is safer in terms of bug class | one systems language | slow build | the ACP crate, the Grok guide with the SDK list, the Tauri 2.12 release | medium | two phases derailed by Rust, or B4 failing for a reason other than the language |
| D2 | Tauri 2 + WKWebView; API through the daemon socket | Electron; 3 native UIs; Dioxus; GPUI | one UI, system WebView, the shell is replaceable | B3, B5, S5 | Tauri IPC is not a trust boundary | Tauri is a framework, accepted only as a shell | mobile quality not proven | tauri.app release 2.12.3 of 2026-10-10; Tauri 3 alpha | medium desktop, low Android | failure of S5 |
| D3 | TS projection without a second state layer | Redux and analogues; pure Rust UI | the journal is the source of truth anyway | less extra runtime | one write path | simple | the Solid/React choice is open until S5 | an architectural consequence of D4/D5 | medium | S5 |
| D4 | Unix socket, remotely SSH forward | public mTLS; Tailscale as a dependency; poll | do not build a network product before a scenario | no background poll | the port does not stick out | little code | inconvenient for a phone | requirement N2, N4 | high for the MVP | U4 before phase 3 |
| D5 | SQLite WAL, one writer | Postgres; CRDT; JSONL-only | the scale of one owner, a process crash is understandable | B7, B10 | file 0600 | one library | file corruption | ordinary practice of local agents; Grok has its own SQLite for search, a journal is enough for us | high | a second writer or a multi-machine inbox |
| D6 | ACP v1 for Grok and Hermes; Codex on app-server stdio; Claude through an adapter after S4 | everything through ACP; everything through CLI `-p` | Codex has an official rich protocol richer than the common subset; `-p` without a host does not carry approval | fewer wrapper layers | approval is not lost in the "common denominator" | two protocols, not four | the experimental marker in the local Codex help | OpenAI app-server docs and SDK blog 2026-10-10; local `--help`; Claude headless docs; Hermes ACP docs; the local Grok guide | high on the channel choice, medium on schema stability | a major version change of a provider |
| D7 | Do not declare ACP fs.write and terminal | hand execution to the client | a second execution path bypasses the agent's sandbox | no extra work in the UI process | closes a class of bypass | less code | some agents work worse without client fs; check with a spike | the ACP specification: these methods are called by the agent on the client | high | S2/S3 show that the agent is useless without client fs |
| D8 | One process per session until S2 allows a shared one | one process per provider right away | sandbox isolation matters more than savings before measurement | worse provider RSS, honestly shown separately | less mixing of sessions | more supervisor | memory | the Grok doc on leader mode refusal under sandbox | medium | the S2 report |
| D9 | Providers are not bundled | embed the CLI into the application | other vendors' updates and the installer's licenses | no double copy of binaries | the user sees the binary they installed | version checks | "not found in PATH" | licenses Codex Apache-2.0, Hermes MIT; the Claude SDK separately | high | a commercial installer with a lawyer |
| D10 | Handoff is an explicit bundle | shared agent memory | officially memory is not transferred | cheap | secrets are visible before sending | little code | a human may transfer extra on their own | principle 8 of the assignment and the Hermes/Grok memory docs | high | an official context export API |
| D11 | The Mac daemon is a child of the application in the MVP | LaunchAgent right away | TCC and no orphans | the process dies with the window | simpler boundary | fewer modes | no local continuity | the macOS TCC model, not a measurement | high | phase 2, by an explicit flag |
| D12 | Approval timeout = deny | timeout = allow | the safe side on a UI drop | no effect | the core invariant | consistent with Hermes | a human did not make it in time | Hermes docs: timeout/error deny | high | never toward allow without a separate "unattended" mode, which is not the default |
| D13 | Read-only files and Git by our own code for a known cwd | read files through the agent's tools | viewing must not spend a turn and widen rights | FSEvents, not poll | the UI does not call `x.ai/fs/write` | our own tree walk | cwd may diverge from the worktree | the Grok worktree docs; ACP requires absolute paths | medium | S2 shows a reliable cwd-change signal |
| D14 | A new workspace does not get bypass / full access | "let it be as in their CLI" | the CLIs may already have been in an always-allow mode for the user | no difference | a predictable Shardrail default | an explicit policy | more approvals than a human is used to in the TUI | the Codex and Grok sandbox docs | high | a separate profile "repeat the CLI default", turned off |
| D15 | Planning documents live in `planning/` of this repository | write the plan into another project or into the agents' home directories | the product repository is empty and belongs to Fork Horizon; the assignment forbids writing into agent configurations | none | does not mix in another project's memory | one index | the directory will land in the first commit, which is desirable | this repository | high | if Fork Horizon specifies another path |

For each row, "maintenance" briefly: D1 low extra cost, D2 medium (the shell framework), D6 medium (two protocols), the rest low.

### 17.3. Risk Register

| ID | Risk | Severity | What we do |
| --- | --- | --- | --- |
| R1 | The Codex schema changes between patches, the help already says experimental | high | version pin, drift test, refusal to start |
| R2 | `claude-agent-acp` falls short on approval | high | S4 and the fallback SDK supervisor; otherwise Claude is outside Phase 1 |
| R3 | Shared unix user: an agent reads other credential files | high | do not copy secrets ourselves; on Linux in phase 2 offer a separate user; do not promise isolation that does not exist |
| R4 | WKWebView does not fit B3/B5 | medium | S5, the fallback shell, the API is already on the socket |
| R5 | The worktree diverges from the tree the UI shows | high | an unknown cwd is shown as unknown; S2 |
| R6 | Provider auto-update in the middle of a session | medium | suppress auto-update on the spawned process where there is an official flag |
| R7 | Project hooks in an untrusted repository | high | F13, `--bare` only as an explicit viewing mode |
| R8 | A human takes `allow_always` for a one-time permission | medium | the label "permanent provider rule" |
| R9 | The Codex npm wrapper or the Node Claude adapter bloat memory | medium | a provider column in the budget report; do not hide in B1 |
| R10 | Legal ambiguity of embedding the Claude SDK | medium | D9, do not embed until checked |
| R11 | The name Shardrail is taken | medium | U5 before the public release |
| R12 | An attempt by a following session to "just a little" scrape the TUI for a missing function | high | S6 is recorded; such a function does not pass review without an official method |
| R13 | The projectmem MCP of this environment points to another project | medium | do not write Shardrail decisions there; set up separate memory when code appears |
| R14 | The child Codex app-server shares `~/.codex` or the control socket with the user's TUI | high | do not call `daemon` and `proxy`; S1 confirms isolation before Phase 1 |

There are no risks that the plan treats with a microservice or background polling.

---

## 18. Open Questions

By priority. While a question is open, the dependent phase does not pretend that the answer already exists.

| ID | Question | Blocks | Temporary behavior |
| --- | --- | --- | --- |
| U1 | Which exact machine counts as the reference for the budgets | closing Phase 1 | Apple Silicon, 16 GB, as a class |
| U2 | The Fork Horizon brand book: color, font, mark | visual polish, not the skeleton | the neutral tokens of section 12 |
| U3 | Public or proprietary license | public release | private repository, all rights reserved |
| U4 | How the phone reaches the daemon: SSH, a corporate mesh, or our own mTLS | Phase 3 | Phase 2 is SSH only |
| U5 | Trademark check of Shardrail | public marketing | the internal repository name is acceptable |
| U6 | Whether continuous operation of agents on the Mac itself with the window closed is needed | scope of Phase 2 | not needed in the MVP, agents live on Linux |
| U7 | Whether to include provider binaries in the commercial installer | release packaging | do not include |
| U8 | SolidJS or React | only after S5, does not block the plan | S5 compares both on one mockup if the first candidate fails B5 |

Not open and must not be reopened without a new fact: Electron as the shell; CRDT; TUI capture; approval timeout = allow; storing provider keys in SQLite; Tauri 3 alpha; a shared Go+Rust in v1.

---
