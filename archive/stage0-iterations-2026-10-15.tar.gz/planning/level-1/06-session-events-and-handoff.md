# Session, Events, and Handoff

> **Stage:** 0 / Architecture Sandbox  \
> **Status:** DRAFT — NOT APPROVED  \
> **Source:** `planning/source/MASTER_PLAN.original.ru.md`, sections 8  \
> **Scope:** Identifiers, event journal semantics, and explicit task transfer boundaries.  \
> **Language status:** English translation (Claude, 2026-10-15, record: planning/translation/records/2026-10-15-claude-en-r01.md). The Russian original in planning/source/MASTER_PLAN.original.ru.md remains authoritative for what the drafting agent wrote.

---

## 8. Session, Events, Tasks

### 8.1. Identifiers

- `WorkspaceId` — a stable id of the directory (realpath + git common dir, if present).
- `SessionId` — a Shardrail UUIDv7. Not equal to the provider's id.
- `ProviderSessionRef` — a pair (provider, external id). For Grok the external id may be a UUID that the client is entitled to set with the `-s` flag only at creation. For ACP the id comes from `session/new`.
- `TurnId`, `ToolCallId`, `ApprovalId` — our own, with a reference to the external id if there is one.
- `EventId` — a monotonic int in the daemon journal, also the replication cursor to the client.

Replacing the provider's id with a Shardrail id is forbidden. Otherwise resume would break after an update.

### 8.2. Journal

An event is immutable. A state correction is a new event. The session projection is built by folding. A client may discard the projection and request a range of events.

The following are not put into an event: environment variables, the contents of `auth.json`, `Authorization` headers, cookies, values resembling keys per a denylist of prefixes (`xai-`, `sk-`, `ghp_`, `github_pat_`, and a list that is extended by a note, not by code "just in case" in ten places). A match is cut out in the stored copy and marked `redacted`. Shardrail does not rewrite the original in the provider.

Large tool output is stored in full up to a per-event byte limit (starting value 256 KiB, to be revisited based on disk). The tail is cut with a marker. The full output remains with the provider.

### 8.3. Task and Handoff

`Task` is a Shardrail object, not a provider session:

- the goal and constraints in text entered by a human;
- completion criteria;
- references to `SessionId` and `EventId` ranges;
- file paths and a short diff taken by the daemon;
- decisions marked by the human as transferable.

Transfer creates a new `Session` at the target provider and sends the bundle as the first prompt. The human sees the bundle and may strike out pieces. Hermes memory, Grok memory, CLAUDE.md, and skills are not read into the bundle automatically: they may contain extraneous context. The human may paste a quotation themselves.

A provider fork (`thread/fork`, `session fork`) is a different operation: a branch of **the same** agent. The UI calls it Fork, not Transfer.

A task queue, kanban, and several executors per task are not part of this plan. Hermes kanban and Grok subagents remain provider capabilities. Shardrail shows child activity if it arrives in the stream (`parent_tool_use_id` in Claude, subagents in a Grok session) and does not build its own scheduler.

---
