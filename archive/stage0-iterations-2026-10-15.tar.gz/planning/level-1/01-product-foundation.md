# Product Vision and Scope

> **Stage:** 0 / Architecture Sandbox  \
> **Status:** DRAFT — NOT APPROVED  \
> **Source:** `planning/source/MASTER_PLAN.original.ru.md`, sections 1, 2  \
> **Scope:** Purpose, supported workflows, and explicit boundaries.  \
> **Language status:** English translation (Claude, 2026-10-15, record: planning/translation/records/2026-10-15-claude-en-r01.md). The Russian original in planning/source/MASTER_PLAN.original.ru.md remains authoritative for what the drafting agent wrote.

---

## 1. Executive Summary

Shardrail is a standalone Fork Horizon console for multiple coding agents. It launches and observes sessions, passes instructions, shows tool operations, handles approvals, lets users read the file tree and Git diff, and transfers **explicit** task context between agents. It is a separate product. Ready-made agent-management shells are studied only as a source of constraints, not as a foundation.

Recommended system shape: **one daemon on the machine where the files and agent processes reside**, and thin clients. The daemon is written in Rust. The macOS client is a Tauri 2 window using the system WKWebView. The same web interface opens in a browser. In the first delivery Android is an observer and command sender, with no local agent launch. Continuous agent operation is the job of a daemon on Linux to which clients connect.

Agents are controlled through official protocols:

| Agent | Channel we adopt | What we deliberately do not adopt |
| --- | --- | --- |
| Grok Build 1.0.52 | `grok agent stdio`, ACP v1 | headless `-p` as an interactive channel; parsing `~/.grok/sessions` as an API |
| Hermes Agent 0.21.6 | `hermes acp` / `hermes-acp`, ACP v1 | gateway, cron, kanban, our own Hermes desktop |
| Codex CLI 0.160.0 | `codex app-server` over stdio | WebSocket app-server as a production transport; `codex exec` as a UI session |
| Claude Code | ACP process adapter `claude-agent-acp` on top of the Agent SDK | `claude -p` as the only interactive channel; capturing a live TUI |

The internal session model is our own. ACP is the common language for Grok and Hermes and a candidate for Claude. Codex stays on its own app-server because that protocol is richer than ACP and is explicitly described as a way to embed Codex in your own product. Common capabilities are projected into one model. Provider-specific capabilities are preserved and are not flattened downward.

Task transfer is a handoff bundle: goal, constraints, criteria, file references, a diff summary, and decisions the user has allowed to be included. Hidden reasoning, provider memory, and secrets are not copied.

The "Go daemon + Rust shell" option is rejected for v1. It adds a second systems language at a boundary that the architecture deliberately keeps thin. Go remains a fallback path if the cost of Rust derails a phase: then the daemon is rewritten in Go and the shell becomes a thin WKWebView without Tauri. The two languages do not live together at once.

No live JSON-RPC sessions were run in this pass. Version compatibility, sandbox isolation within a single process, and real WKWebView latency are closed by short Phase 0 spikes before any product code.

---

## 2. Vision, Scenarios, and Boundaries

### 2.1. Who It Is For

One person or a small Fork Horizon team runs several agents on their own Mac and on an always-on Linux machine. The agents are already installed and authorized by their own means. Shardrail does not replace them and does not package them inside the installer.

### 2.2. Main Scenarios

1. Open a workspace, see the installed agents and versions, and start a session with an explicit cwd, model, and sandbox/approval policy.
2. Observe the stream: text, reasoning, tool calls, diffs, commands, and usage if the provider reports it.
3. Respond to an approval: allow once, allow for the session, deny. A timeout means denial.
4. Queue the next instruction while a turn is still running, and cancel the current turn.
5. Read the file tree and Git diff of **the** directory in which the session actually sits, including a worktree.
6. After a network drop, a process kill, or a machine reboot, see the session as recoverable or as interrupted, without an invented "success".
7. Assemble a handoff and open the continuation in another agent.
8. From a phone, view the turn, respond to an approval, and send a short instruction. The phone does not execute tools.

### 2.3. In the Product

- A local daemon and a macOS window.
- A browser client for the same daemon.
- A daemon on Linux without UI, running as a systemd user service.
- An Android observation and command client.
- Four adapters: Grok, Hermes, Codex, Claude.
- Event log, instruction queue, approvals, read-only files and Git.
- Handoff bundle between agents.
- Recovery after a daemon crash and after a provider process crash, within the limits of official resume.

### 2.4. Outside the Product

- Its own model, a proxy to provider APIs, and token billing, other than displaying what the provider has already counted.
- Packaging or auto-updating Codex, Claude Code, Grok, and Hermes. The user updates them. Shardrail checks the version and refuses to work with an unverified one.
- Capturing an already-open TUI, an IDE extension, or another vendor's desktop application. For each provider this is **Unsupported** until a spike proves an official attach.
- Screen scraping, Accessibility API, sending keystrokes to another terminal.
- Hermes messaging gateway, cron, kanban, pets, wake word, computer use.
- Codex Cloud as an execution environment in the MVP. The local app-server may later show a cloud task only if the method is stable.
- Editing files from the UI in the MVP. Two writers on one tree — the agent and the editor — cause races. Viewing and diff are included. Human editing is a separate decision after the MVP.
- An MCP bus between agents. MCP remains the "agent → tools" mechanism. Shardrail shows the MCP calls the agent has already made.
- Microservices, a message broker, CRDT, a separate search engine, Kubernetes.
- Running agents on Android and in Termux.
- Multi-tenancy and team ACL. The first version has a single machine owner.

### 2.5. Lessons from Other Shells That We Do Not Accept as a Product

Other agent managers confirm three constraints already visible in the official protocols:

- The common subprotocol covers turn, stream, and permission. Sandbox, worktree, fork, and cost remain provider-specific.
- An attempt to control an agent through its TUI breaks on the first interface change.
- A "unified context" between agents is a document the user sees, not a shared model memory.

Shardrail is written from scratch. The code of other shells is not vendored.

---
