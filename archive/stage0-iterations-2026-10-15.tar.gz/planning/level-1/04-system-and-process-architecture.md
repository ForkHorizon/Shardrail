# System and Process Architecture

> **Stage:** 0 / Architecture Sandbox  \
> **Status:** DRAFT — NOT APPROVED  \
> **Source:** `planning/source/MASTER_PLAN.original.ru.md`, sections 5, 6  \
> **Scope:** Component responsibilities, daemon ownership, local and remote processes, and session lifecycle.  \
> **Language status:** English translation (Claude, 2026-10-15, record: planning/translation/records/2026-10-15-claude-en-r01.md). The Russian original in planning/source/MASTER_PLAN.original.ru.md remains authoritative for what the drafting agent wrote.

---

## 5. System Boundaries and Responsibilities

```mermaid
flowchart LR
  subgraph clients [Clients]
    Mac[macOS shell + Web UI]
    Web[Browser]
    Phone[Android]
  end
  subgraph host [Workspace machine]
    Daemon[shardraild]
    DB[(SQLite WAL)]
    Sock[unix socket 0600]
    subgraph providers [Provider processes]
      Grok[grok agent stdio]
      Hermes[hermes acp]
      Codex[codex app-server stdio]
      Claude[claude-agent-acp]
    end
  end
  Mac --> Sock
  Web --> Sock
  Phone -->|SSH forward phase 2+| Sock
  Sock --> Daemon
  Daemon --> DB
  Daemon --> Grok
  Daemon --> Hermes
  Daemon --> Codex
  Daemon --> Claude
```

The daemon is the only writer of the journal and the only owner of the agent child processes. A client does not launch `codex`, `grok`, `hermes`, or `claude` itself.

| Component | Does | Does not do |
| --- | --- | --- |
| `shardraild` | supervisor, journal, projections, approvals, trust policy, socket | does not call models directly |
| Provider adapter | lifecycle of one protocol, translation into the common model, capability flags | does not render UI and does not store secrets |
| Session service | instruction queue, one active turn, cursor, states | does not schedule distributed workflows |
| Workspace service | cwd, trust, read-only tree, git diff on a filesystem event | does not write files in the MVP |
| Approval broker | card built from the protocol's structured fields, timeout = deny | does not consider a command "safe" based on the model's text |
| Handoff | assembling and showing the bundle | does not transfer provider memory |
| Shell | window, daemon autostart on macOS, keychain for its own token | contains no domain logic |
| Web UI | projection and input | is not the source of truth |

Provider processes are a trust boundary. Their stdout is treated as untrusted input. Their environment variables are not printed into the journal. One provider's environment is not passed to another.

### 5.1. Future Level 2 Modules

Names for the following documents, without tasks:

1. Daemon core and socket.
2. Journal and projections.
3. ACP client (Grok, Hermes, then Claude).
4. Codex app-server adapter.
5. Approval broker and workspace trust.
6. Files and Git, read-only.
7. Handoff.
8. Web UI and tokens.
9. macOS shell.
10. Linux service and SSH attach.
11. Android client.

Each Level 2 is written when the phase has grown to that module. Not all eleven at once.

---

## 6. Processes: Local and Remote

### 6.1. Local Mac, MVP

The daemon is a child process of the application. This way it inherits the application's TCC identity, and no second privileged agent appears. While the window is alive, the daemon is alive. Closing the window stops the daemon and asks the providers to finish the turn by the channel's official method: `session/cancel` for ACP, `interrupt()` for the Agent SDK. The `claude -p` signal policy (SIGINT ends the turn, SIGTERM leaves the turn unclosed and exits with code 143) applies only if S4 selects the CLI itself. It is not carried over to the Claude ACP adapter until a spike confirms it.

Continuous operation with the window closed on Mac is not the MVP. It requires a user LaunchAgent, a separate TCC, and an orphan policy. This is phase 2 and only through an explicit switch.

One provider process per provider per daemon, with several sessions inside it, **if** a spike confirms that session sandboxes are not mixed. Otherwise — one process per session. The Grok document says directly: a nonzero sandbox profile refuses leader mode so that the tools stay in-process. So a shared process and a strict sandbox may be incompatible. Until S2, the safe default applies: **one process per session**. A shared process is enabled only after a spike and only for the profiles the spike allowed. This is more expensive in memory and simpler in isolation. Budget B2 measures the daemon, not this process.

Codex: the local 0.160.0 reference marks `app-server` as experimental, and the OpenAI guide describes it as the protocol for rich clients and recommends it when the agent becomes part of a product. WebSocket in the same guide is experimental and not supported for production. Consequence: stdio only, the CLI version pinned. The command `codex app-server generate-json-schema` is in the local reference and is also marked experimental; the schema is taken from the pinned binary and placed in the repository as the reference for a drift test. On the wire Codex omits the `"jsonrpc":"2.0"` header. An ACP parser that requires this header is not used for Codex.

The same reference shows `codex app-server daemon` and `codex app-server proxy` (proxying stdio to an already running control socket). The MVP does not call them. Shardrail spawns a separate child `codex app-server --listen stdio://` and does not connect to the shared daemon that the user's TUI may be using. The flag `--analytics-default-enabled` is not passed: the reference says that for app-server analytics is off until the user enables it themselves in config.toml. Whether a separate process shares the `~/.codex` lock with an already open TUI is checked by S1. Until that result, the shared daemon remains Unsupported.

### 6.2. Remote Linux

The same `shardraild` under a systemd **user** service, not root. Agents run as the same unix user that owns the checkout. A separate unix user per provider is a phase 2 hardening, not an MVP blocker: a shared user means a compromised agent can read neighboring credential files in `$HOME`. This is risk R3, accepted for a personal Mac and explicitly shown in the remote machine settings.

The client does not open the daemon port. The connection is `ssh -L` to the unix socket or to the loopback bridge. An SSH drop moves the remote sessions into `disconnected` in the client's view. The processes on the server themselves continue. Catch-up is from the journal cursor.

Machine reboot: systemd brings up the daemon. The daemon does not resume turns by itself. It marks sessions `degraded` and shows resume if the capability is alive. Auto-continuing a turn after a reboot can easily execute an unsolicited command. This is forbidden.

### 6.3. Android and Browser

Both are clients. A browser on the same machine goes to the loopback bridge. A phone goes through the phase 2+ tunnel. Neither receives the provider's credential store files.

### 6.4. Session Lifecycle

`starting → ready → running → waiting_approval → running → idle`

Side states: `degraded` (the process died or the protocol is out of sync), `disconnected` (the client does not see the daemon; on the daemon the session may remain `running`), `closed`.

One active turn per session. A second instruction waits in the Shardrail queue of depth 1. If a provider officially supports its own queue (Codex has a `queue` command; its semantics relative to app-server are **not verified**), the adapter may hand the queue to the provider after a spike. Until then the queue belongs to Shardrail.

---
