# Global Delivery Roadmap

> **Stage:** 0 / Architecture Sandbox  \
> **Status:** DRAFT — NOT APPROVED  \
> **Source:** `planning/source/MASTER_PLAN.original.ru.md`, sections 16  \
> **Scope:** Phase 0 spikes and Phases 1–4, major outputs, and phase gates.  \
> **Language status:** English translation (Claude, 2026-10-15, record: planning/translation/records/2026-10-15-claude-en-r01.md). The Russian original in planning/source/MASTER_PLAN.original.ru.md remains authoritative for what the drafting agent wrote.

---

## 16. Roadmap

The phases are sequential. The next one does not start until the gates of the current one are closed or deliberately narrowed by an entry in the decision log.

### Phase 0 — Spikes, No Product

Short programs that can be thrown away. They do not become the daemon's skeleton.

| ID | Question | Done when |
| --- | --- | --- |
| S1 | A separate `codex app-server --listen stdio://`: thread start, turn, approval, drop, resume after killing the process. Take the JSON Schema from 0.160.0. Check whether the process grabs the shared control socket and whether it blocks an already open TUI | a note: events on the wire; `thread/shellCommand` stays forbidden in the UI; a decision on whether two Codex sessions can sit next to the user's TUI |
| S2 | One `grok agent stdio`, two sessions, different sandboxes. Whether permission reaches the client in `auto` mode | a decision "one process per session" or a list of profiles that may share a process |
| S3 | `hermes acp`: prompt, approval deny on timeout, resume after a process restart. Whether `session/load` can open a session created by the CLI | capability `load_foreign_session` yes or no |
| S4 | `claude-agent-acp` against the direct SDK: approval, cancel, resume, start in an untrusted folder | a single Claude channel is chosen |
| S5 | A transcript mockup in Tauri WKWebView: B3, B4, B5, 5,000 events. Next to it the same mockup in a bare WKWebView, if Tauri fails the budget | D2 confirmed or the fallback Swift shell is enabled |
| S6 | A negative test: no adapter can honestly intercept an already open interactive TUI | the document stays at Unsupported, or a narrow official attach appears |

Each spike takes days, not weeks. Live models are acceptable here and only here, on a test repository without live secrets.

### Phase 1 — Local Mac

Included: daemon, journal, shell, UI from the primitives of section 12, Grok and Hermes through ACP, Codex through app-server, Claude through the channel chosen by S4, approvals, queue of depth 1, read-only files and diff, workspace trust, kill -9 recovery.

Not included: Linux service, phone, handoff, file editor, a shared provider process if S2 did not allow it.

Gates: F1–F10 and F12–F13 on fixtures; one live smoke test of each provider on a test repository; budgets B1–B7 and B9; B8 at least once; no open Severity 1 items from section 17.

### Phase 2 — Linux and Continuous Operation

Included: user systemd, SSH forward, the same UI in a browser from another machine through the tunnel, sessions survive closing the Mac window because they live on the server. Optional: a LaunchAgent on Mac, off by default. Optional: a separate unix user per provider.

Gates: an SSH drop does not kill a turn; after a VPS reboot a turn does not continue on its own; B1 on Linux; the socket does not listen on an external interface (`ss` / an equivalent in the test).

### Phase 3 — Android

Only after U4 is chosen. Observation, approval, a short instruction. No local agents. Gates: the stolen-phone scenario (token revocation stops admitting), an approval from the phone arrives no later than 1 second after the tap with a live tunnel, not counting the model's network.

### Phase 4 — Handoff and a Clear Worktree

Included: Task, a bundle with preview, provider Fork as a separate command if the capability exists. Gates: F11; a secret from the denylist does not pass into the bundle; the UI does not show the diff of the wrong cwd.

### Stop Condition for the Whole Line

If S4 and the fallback Claude SDK channel both fail to give two-way approval, Claude stays in the matrix as "observation through stream-json without an approval guarantee" and is not part of Phase 1. The product is more honest with three controllable agents than with a fourth for which a command cannot be safely denied.

---
