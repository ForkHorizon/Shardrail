# Provisional Engineering Backlog — Program → Phase → Epic → Candidate Task

> **Status:** PROPOSED — NOT AUTHORIZED. Every item is planning-level. No task may start until (1) the owner approves the relevant Level 1 decisions, (2) the owner authorizes the phase, and (3) for Level 3, a reviewed task description exists. Complexity uses relative classes S < M < L < XL; there are **no calendar estimates**.
> Based on candidate v0.2 (`../../candidates/claude-stage0-v0.2/`) and module index (`../../level-2/proposed/00-MODULE-INDEX.md`).

## 1. Program

**Shardrail v1:** a local + remote multi-agent workspace for Codex, Claude Code, Grok and Hermes with safe approvals, durable history, and a polished web-technology UI on macOS and browsers; Android after Phase 3 decision.

## 2. Phases

| Phase | Objective | Major deliverables | Depends on | Architectural prerequisites | Validation gate | Risk | Complexity |
| --- | --- | --- | --- | --- | --- | --- | --- |
| P0 Feasibility | Replace assumptions with evidence | Spike notes S1–S8, X-01…X-07 data, terms answer U9 | Stage 0 exit; owner authorization | D6, D8, D16, D20, D23 framed as hypotheses | each spike's "done when" (d13 §1) | medium | M |
| P1a Foundation | End-to-end vertical slice with fake agents + one ACP provider | contracts, fake agents, daemon core, journal, gateway+relay, minimal UI, approvals, trust, safe Git | P0 S2/S3/S5/S7/S8 | D1–D5, D11, D16–D23, D26, D27, D30 approved | d13 §2 1a gate | high | XL |
| P1b Codex | Codex adapter | app-server adapter, compatibility policy | P1a, S1 | D24 | Codex fixtures + live smoke | medium | L |
| P1c 2nd ACP | Second ACP provider | config + mapping | P1a | — | fixtures + smoke | low | M |
| P1d Claude | Claude per S4 + terms | Claude channel | P1a, S4, U9 | D29 | fixtures + smoke + recorded terms decision | high (non-technical) | M–L |
| P1 close | Phase 1 gate | history import, budgets report | P1a–d | — | baseline Phase 1 gate + B11, B13, B14 | — | M |
| P2 Remote | Linux + continuous operation | systemd unit, bridge, host mgmt, federation, inbox, optional launch agent | P1 close | D25, U6, U11, U15 | baseline P2 gate + 72 h soak | medium | L |
| P3 Mobile | Observe/approve/instruct from phone | per D28 | P2, U4/D28 | D21 scopes | baseline P3 gate + notification path | high | L |
| P4 Handoff | Explicit task transfer, worktree clarity | Task, bundle preview, provider fork | P1 close | D10 | F11 + baseline P4 gate | low | M |

## 3. Epics

| ID | Phase | Objective | Module | Depends on | Acceptance outcome | Security | Performance validation | Major uncertainties |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| E0.1 | P0 | Codex app-server feasibility (S1 + X-03/04/05) | M07 | — | written spike note answering all S1 questions | test repo, no prod secrets | delta rate capture | concurrent turns; approval wait limit |
| E0.2 | P0 | Grok ACP feasibility (S2 + X-01/02) | M06 | — | note + topology decision | sandbox reachability per profile | — | `auto` mode semantics |
| E0.3 | P0 | Hermes ACP feasibility (S3) | M06 | — | note + `load_foreign_session` answer | toolset exposure | replay volume | — |
| E0.4 | P0 | Claude channel + terms (S4, U9) | M08 | — | channel chosen **and** owner/legal terms decision recorded | auth mode | Node/CLI footprint | policy interpretation |
| E0.5 | P0 | UI pipeline (S5) | M13–M15 | — | D2/D3 confirmed or fallback triggered; framework chosen | D22 prototype rules | B3 (new method), B4, B5, B13 | WKWebView footprint |
| E0.6 | P0 | Control-plane isolation (S7) | M05, M10 | E0.1–E0.4 setups | residual-risk table per provider profile | primary | — | peer-ancestry feasibility |
| E0.7 | P0 | Safe Git (S8) | M11 | — | library choice; malicious-repo test passes | primary | B16 | worktree coverage |
| E0.8 | P0 | Negative TUI-attach test (S6) | — | — | Unsupported confirmed or narrow official attach found | — | — | — |
| E1.1 | P1a | Contracts & codegen | M02 | P0 | schemas for wire, durable events, normalized events; generated Rust/TS types | validation at boundaries | — | schema tooling choice |
| E1.2 | P1a | Fake agents & fixtures | M18 | E1.1 | scripted ACP and app-server simulators incl. crash, replay, storms | no real secrets | can generate B-budget loads | fidelity vs real providers |
| E1.3 | P1a | Daemon core & supervisor | M01, M05 | E1.1 | lifecycle, lock, spawn/reap, env sanitization | D20 env rules | B1, B6, B7, B9, B11 | — |
| E1.4 | P1a | Journal store | M04 | E1.1 | WAL single writer, versioning, retention, salvage, backup | `0600`, purge | B7, B10, B15 | checkpoint policy |
| E1.5 | P1a | Session & event engine | M03 | E1.3, E1.4 | state dimensions, tiers, projections, command router | redaction pass | B4 share, B13 | coalescing interval |
| E1.6 | P1a | ACP client adapter (first provider) | M06 | E1.2, E1.5 | first provider passes fixtures + live smoke | D7 | delta handling | provider choice |
| E1.7 | P1a | Approval broker & trust | M09 | E1.5 | D19 lifecycle, trust states, policy gating | invariants tested | B14 | U10 default |
| E1.8 | P1a | Client gateway & relay | M10, M13 | E1.1, E1.5 | UDS + relay, pairing, scopes, backpressure | D20, D21 | B12 | relay flow control |
| E1.9 | P1a | Workspace service (read-only) | M11 | E0.7, E1.3 | tree, safe Git, scoped watchers | D23 | B16 | — |
| E1.10 | P1a | UI system & rendering pipeline | M15 | E0.5 | tokens, primitives, incremental Markdown, virtualization, D22 | D22 | B4, B5 | framework |
| E1.11 | P1a | Web UI application (inbox, session view) | M14 | E1.8, E1.10 | F14 (local), F3–F5, F8 flows | — | B4, B5 | — |
| E1.12 | P1a | Desktop shell | M13 | E1.8 | window/menu-bar/notifications/keychain/relay; D11 behavior | keychain ACL | B3, B6 | — |
| E1.13 | P1b | Codex adapter | M07 | E1.6 framework, E0.1 | fixtures + smoke; schema reference check | no `shellCommand`, no experimental API | — | schema churn |
| E1.14 | P1c | Second ACP provider | M06 | E1.6 | fixtures + smoke | — | — | — |
| E1.15 | P1d | Claude channel | M08 | E0.4, E1.6 | fixtures + smoke; terms decision honored | auth mode | footprint column | U9 |
| E1.16 | P1 close | History import (F15) | M06, M03 | E1.13–E1.15 | read-only import for providers with APIs | imported content untrusted | B13 | per-provider APIs |
| E1.17 | P1 close | Budget & soak report | M18 | all P1 | stored traces for every closed budget | — | B1–B16 | reference machine (U1) |
| E2.1 | P2 | Linux service & bridge | M16 | P1 | systemd unit; `bridge`; reboot rules | no network listener | B1 Linux | U11 design |
| E2.2 | P2 | Host management & federation | M13, M14 | E2.1 | F16; cross-host inbox F14 | SSH config respected | — | U15 |
| E2.3 | P2 | Optional macOS launch agent | M01, M13 | P1 | opt-in continuous local mode | approval UX | B11 | U6 |
| E2.4 | P2 | 72 h soak & stability | M18 | E2.1 | B8 extension met | — | WAL, WebView | — |
| E3.1 | P3 | Mobile transport + notifications decision | M17 | P2 | D28 decided with X-07 evidence | scoped creds | ≤ 1 s approval | U4 |
| E3.2 | P3 | Mobile client | M17 | E3.1 | baseline P3 gate | revocation | — | platform |
| E4.1 | P4 | Task and handoff bundle | M12 | P1 | F11; denylist test | redaction | — | — |
| E4.2 | P4 | Provider fork & worktree clarity | M06, M11 | P1 | UI never shows wrong cwd diff | — | — | worktree signals |

## 4. Candidate tasks (only where architecture is clear enough)

All tasks: **status PROPOSED, not authorized**. Research/planning tasks are marked (R).

| ID | Epic | Task | Verifiable outcome | Requirements | Depends on |
| --- | --- | --- | --- | --- | --- |
| T0.1.1 (R) | E0.1 | Write S1 protocol script plan (questions, observations to record, safety limits) | reviewed plan document | S1, X-03–X-05 | owner authorizes P0 |
| T0.1.2 | E0.1 | Execute S1 on test repo; record wire logs (redacted) | spike note with answers | S1 | T0.1.1 |
| T0.4.1 (R) | E0.4 | Obtain policy/legal answer for U9 | recorded owner decision | D29 | — (can run now, owner action) |
| T0.5.1 (R) | E0.5 | Define S5 measurement protocol (footprint tree, clocks, workloads) | reviewed protocol | B3, B4, B5, B13 | — |
| T0.6.1 (R) | E0.6 | Define X-01 test matrix (provider × sandbox profile × access type) | reviewed matrix | N10 | — |
| T0.7.1 (R) | E0.7 | Compare Git library options against status/diff/worktree needs (desk research) | comparison note | D23 | — |
| T1.1.1 | E1.1 | Draft wire-protocol schema v0 (handshake, command, event, resync) | schema + review | D16, D27 | P1a authorized |
| T1.1.2 | E1.1 | Draft durable-event schema v0 with `schema_version` | schema + review | D26 | T1.1.1 |
| T1.2.1 | E1.2 | Fake ACP agent with scenario scripts (normal turn, crash mid-tool, replay on load, parallel approvals) | scenarios runnable in CI | F3–F7, F9–F10 | T1.1.2 |
| T1.2.2 | E1.2 | Fake app-server agent (items, deltas, approvals, `serverRequest/resolved`) | scenarios runnable in CI | same | T1.1.2 |
| T1.4.1 | E1.4 | Journal write path with batching + crash test (kill -9 between commits) | F9, B7 test passes | F9 | T1.1.2 |
| T1.4.2 | E1.4 | Salvage path for corrupt DB | corruption fixture handled per d07 | D26 | T1.4.1 |
| T1.5.1 | E1.5 | Command router: `command_id`, preconditions, `delivery_unknown` | S-7/S-9 tests pass | D30, F18 | T1.4.1 |
| T1.5.2 | E1.5 | Delta coalescing + per-item buffers | B4 engine share measured | D17 | T1.2.1 |
| T1.7.1 | E1.7 | Approval record CAS + expiry policies | concurrent-responder and disconnect tests pass | D19, F5 | T1.5.1 |
| T1.8.1 | E1.8 | Pairing + scopes + revocation | scope enforcement tests | D21 | T1.1.1 |
| T1.8.2 | E1.8 | Per-client queue bound + resync | stalled-client test stays ≤ B12 | D17, B12 | T1.5.2 |
| T1.9.1 | E1.9 | Malicious `core.fsmonitor` fixture never executes | test passes | D23, F8 | E0.7 |
| T1.10.1 | E1.10 | Rendering fixtures: bidi/zero-width command, remote image Markdown | N11 tests pass | D22 | E0.5 |

Uncertain areas (Claude channel, mobile, launch agent, separate agent user) intentionally have only research tasks.

## 5. Dependency graph

```mermaid
flowchart TD
  G0{{Owner: approve L1 candidate items + authorize P0}} --> P0
  subgraph P0 [Phase 0 spikes]
    E01[E0.1 Codex] ; E02[E0.2 Grok] ; E03[E0.3 Hermes] ; E04[E0.4 Claude+terms] ; E05[E0.5 UI] ; E06[E0.6 Isolation] ; E07[E0.7 Git] ; E08[E0.8 TUI]
  end
  E01 & E02 & E03 & E04 --> E06
  P0 --> G1{{Owner: authorize P1a}}
  G1 --> E11[E1.1 Contracts]
  E11 --> E12[E1.2 Fake agents] & E13[E1.3 Core] & E14[E1.4 Journal] & E18[E1.8 Gateway]
  E13 & E14 --> E15[E1.5 Engine]
  E12 & E15 --> E16[E1.6 ACP adapter]
  E15 --> E17[E1.7 Approvals]
  E15 --> E18
  E07 & E13 --> E19[E1.9 Workspace]
  E05 --> E110[E1.10 UI system]
  E18 & E110 --> E111[E1.11 Web UI]
  E18 --> E112[E1.12 Shell]
  E16 --> E113[E1.13 Codex] & E114[E1.14 2nd ACP] & E115[E1.15 Claude]
  E04 --> E115
  E113 & E114 & E115 --> E116[E1.16 History import] --> E117[E1.17 Budget report]
  E117 --> G2{{Owner: close P1 / authorize P2}} --> E21[E2.1 Linux bridge] --> E22[E2.2 Federation] & E24[E2.4 Soak]
  G2 --> E23[E2.3 Launch agent]
  E22 --> G3{{Owner: decide U4/D28}} --> E31[E3.1] --> E32[E3.2]
  E117 --> E41[E4.1 Handoff] --> E42[E4.2 Fork/worktree]
```

### Critical path
G0 → P0 (E0.5, E0.6 are the longest-uncertainty spikes) → E1.1 → E1.4 → E1.5 → E1.6 → E1.13/E1.15 → E1.17 → G2.

### Parallelizable (with isolation)
- P0 spikes are independent except E0.6 (needs provider setups).
- In P1a after E1.1: E1.2 (fake agents), E1.3 (core), E1.4 (journal), E1.10 (UI system) touch disjoint modules.
- E1.13 / E1.14 / E1.15 are separate adapters on a shared framework — parallel only after the framework (E1.6) is stable; they must not modify framework code concurrently.

### Bottlenecks and integration boundaries
- **E1.1 contracts** gate everything; schema churn propagates everywhere.
- **E1.5 engine** is the integration hub (adapters, approvals, gateway).
- Integration boundaries: M06↔M03 (normalized events), M03↔M10 (subscriptions/commands), M10↔M13 (relay), M09↔M10 (scopes).

### High-risk prerequisites
E0.4/U9 (terms), E0.6 (control-plane isolation), E0.5 (WebView footprint), E0.1 (Codex schema stability).

### Approval gates
G0 (Stage 0 exit + P0 authorization), G1 (P1a authorization after spikes), G2 (P1 close/P2), G3 (mobile decision). Plus per-epic Level 2 approval before detailed tasks.
