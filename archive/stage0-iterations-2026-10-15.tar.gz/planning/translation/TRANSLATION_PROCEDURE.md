# Controlled English Normalization — One Domain at a Time

## Why this exists

The initial Grok-generated source is Russian. The project owner requires English-only technical documentation to make later multi-agent workflows efficient. Changing language and reorganizing files simultaneously can accidentally change technical meaning, so this split preserves the original first.

## Per-domain conversion procedure

1. Select **one** Level 1 document (`planning/level-1/NN-*.md`). Do not load the entire original Master Plan.
2. Translate the complete source content into **precise technical English**. Preserve every ID, version, threshold, source URL, limitation, table row, and code/diagram block.
3. Keep the current document's English metadata header. Replace only the extracted Russian section bodies in that document (do not rewrite architecture during translation).
4. Retain original § numbers in headings and link to the immutable source for auditability.
5. If a statement is ambiguous, flag `TRANSLATION_QUESTION` rather than silently interpreting it.
6. Check the English document against the original content for omissions and changed modalities (`must`, `may`, `unsupported`, `requires`).
7. Save a conversion record: original source hash, reviewer, and open translation questions.
8. Only after translation checking, use the English text for independent architectural reviews.

**Scope lock:** No architectural critique, gap-filling, new requirements, or implementation during translation. This is a language normalization task, not a design pass.

## Ready-to-send per-document instruction

> Translate the attached Shardrail Stage 0 domain document into technical English while preserving 100% of its technical meaning and traceability. Translate only this file. Preserve original section numbers, stable identifiers (F/N/B/D/R/U/S), code fences, Mermaid, citations, versions, constraints, and all table rows. Do not correct or improve architecture, invent facts, or implement anything. Keep uncertainty and statuses intact. Report uncertain translations separately. Output only the complete English document and a short translation-verification checklist.
