# Proposed Module Index (Level 2 candidates)

> **Status:** PROPOSED — provisional planning only. Level 1 is **not approved**; every dependency below is provisional. Nothing here authorizes implementation. Governance note: `REVIEW_PROTOCOL.md` says "No Level 2 during Stage 0"; these outlines exist because the Stage 0 assignment allowed labeled drafts (inventory INV-02). The owner may reject them.
> Based on candidate v0.2 (`../../candidates/claude-stage0-v0.2/`). Supersedes the name list in baseline §5.1 only as a proposal.

## 1. Modules

| ID | Module | Purpose | Responsibilities | Explicit exclusions | Depends on | Security boundary | Perf / reliability notes | L1 refs | Outline |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| M01 | Daemon core & lifecycle | Host process for all daemon modules | startup/shutdown, single-instance lock, data dir, config, health, diagnostics ring, signals | provider protocols, client auth | M02 | process owner; data dir `0700` | B1, B6, B7, B9, B11 | 04, d04 | [L2-01](L2-01-daemon-core-and-supervision.md) |
| M02 | Contracts & schemas | Language-neutral definitions | wire protocol, durable events, normalized provider events, codegen | runtime logic | — | schema validation at every boundary | — | D27 | in L2-05 / L2-02 |
| M03 | Session & event engine | Sessions, turns, items, state, commands | state dimensions, delta coalescing, projections, replay reconciliation, command router | storage I/O details, process spawning | M02, M04, M06 | trusts only normalized adapter events | B4, B12, B13 | 06, 07, d06, d07 | [L2-02](L2-02-session-event-engine.md) |
| M04 | Journal store | Durable persistence | SQLite WAL, single writer, versioning, retention, purge, backup, salvage | business rules | M02 | file `0600`; sensitive store | B7, B10, B15, WAL limits | D5, D26 | in L2-02 |
| M05 | Provider supervisor | Own provider processes | spawn per topology, env sanitization, process groups, stdio, crash/orphan detection, version detection | protocol semantics | M01 | B-1 (untrusted output), D20 env rules | provider footprint reported separately | 04, d04 | in L2-01 |
| M06 | Adapter framework + ACP client | Normalize providers | capability negotiation, compatibility classes, replay mode, ACP v1 client for Grok/Hermes/Claude-ACP | UI, secrets | M02, M05 | never declare client fs/terminal (D7) | delta rates (X-03) | 05, d05 | [L2-03](L2-03-provider-adapter-framework.md) |
| M07 | Codex app-server adapter | Codex integration | thread/turn/item mapping, approvals, schema reference, no experimental API | `thread/shellCommand` in normal UI | M06 | B-1 | — | 05, d05 | in L2-03 |
| M08 | Claude channel | Claude integration per S4 + D29 | adapter or SDK supervisor | until U9 resolved for product builds | M06 | terms gate | Node/CLI footprint | 05, D29 | in L2-03 (stub) |
| M09 | Approval broker & policy | Human-in-the-loop safety | approval records, CAS, expiry policy, trust policy hooks, allow-all gating, notifications fan-out | judging commands by text | M03, M10 | primary safety invariant | B14 | 08, d08 | [L2-04](L2-04-approval-and-control-plane-security.md) |
| M10 | Client gateway & wire protocol | All client traffic | transports (UDS, WS, stdio bridge), pairing, credentials, scopes, fan-out, backpressure, resync | domain logic | M02, M03 | B-3 | B12 | 04, 08, d04 | [L2-05](L2-05-client-gateway-and-wire-protocol.md) |
| M11 | Workspace service | Read-only workspace view | trust state, tree, safe Git, scoped watchers, cwd/worktree mapping | file writes | M01 | B-4 (D23) | B16 | 08, 09, D13, D23 | future |
| M12 | Handoff | Explicit task transfer | bundle assembly, preview, redaction | provider memory transfer | M03, M04 | redaction | — | 06 | future (Phase 4) |
| M13 | Desktop shell | macOS host app | window, menu-bar presence, notifications, keychain, deep links, frame relay, SSH bridge launcher | domain logic, parsing | M10 | relay only; keychain ACL | B3, B6 | 03, d04 | future |
| M14 | Web UI application | Product UI | inbox, session view, workspace pane, palette, host federation | source of truth | M10, M15 | D22 | B4, B5, B13 | 10, d10 | future |
| M15 | UI system & rendering | Visual system and rendering pipeline | tokens, primitives, accessibility, incremental Markdown, virtualization, safe rendering | product flows | — | D22 implementation | B4, B5, R24 | 10, d10 | future |
| M16 | Remote host & bridge | Linux operation | systemd user unit, `bridge` subcommand, host registry, reboot behavior | network listeners | M01, M10 | B-5 (SSH) | B1 on Linux | 04, d13 | future (Phase 2) |
| M17 | Mobile client | Phase 3 | per D28 | everything until U4 | M10, M14 | scoped credential | approval ≤ 1 s | 13 | deferred |
| M18 | Verification harness | Make everything testable | fake ACP/app-server agents, fixtures, contract tests, fault injection, perf/soak harness | product features | M02 | fixtures contain no real secrets | measures all B-budgets | 11, d-minor | future (Phase 1a, first) |

## 2. Dependency sketch

```mermaid
flowchart TD
  M02[M02 Contracts] --> M03 & M04 & M06 & M10 & M18
  M01[M01 Core] --> M05[M05 Supervisor] --> M06[M06 Adapters+ACP]
  M06 --> M07[M07 Codex] & M08[M08 Claude]
  M04[M04 Journal] --> M03[M03 Session engine]
  M06 --> M03
  M03 --> M09[M09 Approvals]
  M03 --> M10[M10 Gateway]
  M09 --> M10
  M10 --> M13[M13 Shell] & M14[M14 Web UI] & M16[M16 Remote bridge]
  M15[M15 UI system] --> M14
  M01 --> M11[M11 Workspace] --> M10
  M03 --> M12[M12 Handoff]
  M14 --> M17[M17 Mobile]
```

## 3. Prerequisites before any detailed Level 2

1. Owner decisions on Level 1 candidate items that the module depends on (listed per outline).
2. Relevant Phase 0 spike results (authorization required to run them).
3. Independent review of the outline (handoff packet).
