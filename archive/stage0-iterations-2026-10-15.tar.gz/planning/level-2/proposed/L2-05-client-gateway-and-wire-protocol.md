# L2-05 — Client Gateway and Wire Protocol (outline)

> **Status:** PROPOSED OUTLINE — not approved. Modules M10 (+ M02 wire contract), interfaces to M13 shell relay and M16 bridge.
> **Provisional L1 dependencies:** baseline 03 §4.6, 04, 08; candidate d04, d08; D4, D16, D17, D21, D25, D27, D30.

## 1. Purpose
Give every client — desktop, browser, remote desktop over SSH, future mobile — one authenticated, scoped, backpressured protocol to every host.

## 2. Scope / exclusions
- In: transports (Unix socket, opt-in loopback WebSocket, stdio via `shardraild bridge`), framing, handshake and version negotiation, pairing and credentials, scopes, request/response with `command_id`, server push by cursor, per-client bounded queues, resync, presence.
- Out: domain semantics (L2-02, L2-04), UI federation logic (M14), SSH itself (system OpenSSH).

## 3. Protocol shape (conceptual)
- **Handshake:** client hello (protocol version range, client id, credential proof) → server hello (host id, protocol version, granted scopes, current cursor).
- **Requests:** `{command_id, kind, preconditions?, payload}` → `{command_id, outcome | error(type, current_state?)}`.
- **Subscriptions:** per session or host-wide; server pushes durable events with `event_id` and coalesced ephemeral updates without IDs; on gap → `resync_required` with snapshot.
- **Encoding:** JSON, schema-defined (D27); binary encoding only if measured necessary.

## 4. Transports
| Transport | Use | Auth |
| --- | --- | --- |
| Unix socket | desktop shell relay; local CLI tools | peer UID + paired credential + peer-ancestry rejection (D20) |
| stdio bridge (`ssh host shardraild bridge`) | remote hosts from desktop | SSH auth + paired credential |
| loopback WebSocket (opt-in) | browser on same host or through user tunnel | paired credential (no ambient cookie auth without CSRF defense), Origin + Host allowlist |
| Phase 3 transport | mobile | per D28 |

## 5. Pairing and scopes (D21)
One-time code displayed in an already-authorized client; credential per device stored in OS keychain where available; scopes `observe`, `prompt`, `respond_approval`, `control_policy`; `control_policy` only for local desktop clients; revocation immediate (open connections closed).

## 6. Backpressure (D17)
Per-client outbound queue bound (B12 ≤ 8 MiB PROPOSED). Policy on overflow: drop pending ephemeral updates first; if durable backlog still exceeds bound → disconnect subscription with `resync_required`. The engine never blocks on a slow client.

## 7. Invariants
- No unauthenticated request reaches domain modules.
- A client's scope is enforced in the gateway, re-checked in the approval broker for approval/policy operations.
- No credential in URLs, process arguments, or logs.

## 8. Failure modes
Relay stalls in shell; SSH drops mid-request (client retries with same `command_id`); daemon upgraded with protocol change (version negotiation; old client gets explicit "update required"); clock-skewed clients (server timestamps only).

## 9. Open questions
- Browser credential storage (WebCrypto non-extractable key vs short-lived session cookie minted by desktop pairing).
- Whether local CLI tooling (`shardrail` CLI) is in scope for Phase 1.
- Multiplexing several sessions on one connection vs one connection per host (recommend one per host).

## 10. Prerequisites
Owner decisions D4, D16, D21, D25; S5 relay latency; M02 contract draft.
