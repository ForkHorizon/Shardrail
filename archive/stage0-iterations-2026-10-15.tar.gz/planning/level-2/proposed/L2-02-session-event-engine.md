# L2-02 — Session and Event Engine with Journal Store (outline)

> **Status:** PROPOSED OUTLINE — not approved. Modules M03, M04 (closely coupled; may split at detailed planning).
> **Provisional L1 dependencies:** baseline 06, 07; candidate d06, d07; D5, D17, D18, D26, D27, D30.

## 1. Purpose
Turn normalized provider events and client commands into a consistent, durable, replayable session history with clear state, while keeping memory and disk bounded.

## 2. Scope / exclusions
- In: session/turn/item model; state dimensions; ephemeral delta buffers and coalescing; durable event writes; projections and paging; command router (idempotency, preconditions, intent journaling); replay reconciliation; retention/purge; schema versioning; backup/salvage.
- Out: provider wire formats (L2-03), client transport (L2-05), approval policy decisions (L2-04; engine only stores approval records).

## 3. Conceptual model
- **Entities:** Host → Workspace → Session → Turn → Item (message, thought, tool call, plan, diff, notice) ; Command ; ApprovalRecord (owned by L2-04, persisted here).
- **Write path:** adapter event → validate → update in-memory session state → if ephemeral: append to item buffer, schedule coalesced flush to gateway; if durable: enqueue to single writer → commit (batched per short interval) → publish with `event_id`.
- **Read path:** catch-up by cursor (raw durable events) or projection pages (items) for history views.
- **Checkpoints:** in-progress item content persisted periodically (PROPOSED 2 s / 64 KiB), compacted on completion.

## 4. Invariants
1. Single writer per host; `event_id` strictly increasing.
2. Published durable events are committed (no publish-before-commit).
3. A command with a seen `command_id` never re-executes; its stored outcome is returned.
4. Side-effecting commands journal `command_accepted` before dispatch.
5. Replay from `session/load` never produces duplicate items.
6. Readers hold short transactions; checkpoints are never starved.
7. Every durable event has `schema_version`; readers support all versions ever written (upcasting).

## 5. Failure modes
Crash between accept and dispatch (→ `delivery_unknown`); crash mid-item (→ checkpointed text + `outcome_unknown`); provider replay interleaving with live events; client cursor older than retention (→ snapshot); disk full (→ sessions pause new turns, notice; never drop durable events silently); corruption (→ salvage path).

## 6. Performance (proposed budgets)
B4 (p95 ≤ 50 ms event→frame, engine share target ≤ 5 ms — REQUIRES FUTURE EXPERIMENT), B7, B10, B12 (via gateway), B13 (first page ≤ 300 ms on 50 000 events), B15 (journal growth). Memory per idle session projection: B2 ≤ 15 MB retained as budget.

## 7. Security
Journal is a sensitive store: `0600`, redaction pass before persist (best effort), purge (F17). No provider credential material by construction (adapters never read credential stores).

## 8. Open questions
- Exact checkpoint interval and its interaction with B15 (needs X-03 delta-rate data).
- Projection snapshot persistence vs recompute on start (B7 trade-off).
- Whether FTS is needed (baseline: not until measured — retained).
- Retention defaults (owner preference).

## 9. Prerequisites
Owner decisions D5, D17, D18, D26, D30; X-02/X-03 spike data; contract schema draft (M02).
