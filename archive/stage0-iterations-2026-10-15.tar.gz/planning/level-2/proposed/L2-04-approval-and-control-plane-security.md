# L2-04 — Approval Broker and Control-Plane Security (outline)

> **Status:** PROPOSED OUTLINE — not approved. Module M09 plus cross-cutting control-plane rules shared with M05/M10.
> **Provisional L1 dependencies:** baseline 08, F5, F13, D12, D14; candidate d08; D19, D20, D21, D22.

## 1. Purpose
Guarantee that no supervised agent action requiring approval proceeds without an explicit decision by an authorized human, across any number of clients and hosts, and that the agents cannot influence that decision through Shardrail itself.

## 2. Scope / exclusions
- In: approval records and lifecycle, CAS resolution, expiry policies, notification fan-out (via gateway), approval-card data contract (structured fields only), allow-all/trust/sandbox-weakening gating (`control_policy` scope), workspace trust state machine (`unknown`/`restricted`/`trusted`), control-plane isolation rules (D20).
- Out: client authentication mechanics (L2-05), rendering implementation (M15, but D22 contract defined here), provider-internal auto-approvals (invisible; documented residual).

## 3. Approval lifecycle (conceptual)
```mermaid
stateDiagram-v2
  [*] --> pending: permission_requested
  pending --> allowed: authorized client allow (CAS)
  pending --> denied: authorized client deny (CAS)
  pending --> expired: policy timer (maps to provider deny)
  pending --> withdrawn: provider cleared request / turn ended / process exited
  allowed --> [*]
  denied --> [*]
  expired --> [*]
  withdrawn --> [*]
```
- Resolution message to provider sent once; acknowledgement journaled.
- Disconnect of any client: no transition.
- Late response: typed rejection containing final state.
- Expiry policy: per workspace, default `deny_after(min(180 s, provider limit))`, opt-in `hold_until_provider_limit` (U10).

## 4. Approval-card data contract
Built only from structured `permission_requested` fields: provider, session, tool kind, exact command/argv or file path(s), cwd, sandbox mode + approval policy (both axes, baseline §7.4), provider-native options with real scope labels, diff summary where provided. Text rendering obeys D22 (control/bidi visible, raw view).

## 5. Control-plane isolation (D20) — rules for M05/M10
Env sanitization; credentials outside agent-readable storage; peer-ancestry rejection; socket outside workspaces; sandbox deny paths where provider supports them; documented residual risk per sandbox profile from S7.

## 6. Invariants
1. Allow requires an authorized human action through a client holding `respond_approval`.
2. Expiry, error, replay, restart, disconnect → never allow.
3. Exactly one resolution per approval.
4. Allow-all / trust / sandbox-weakening require `control_policy` from a local desktop client and leave a persistent indicator.

## 7. Failure modes
Daemon restart with pending approvals (providers are stdio children, so they lose their channel when the daemon dies → all pending approvals become `withdrawn` with reason `daemon_restart`; never re-sent — see consistency report C-04); provider times out before the human answers (→ `withdrawn` with reason); two clients answer at once; phone answers after desktop; approval storm (many parallel tool calls) → batch UI with per-item decisions, no "approve all" default.

## 8. Performance
B14 approval round trip ≤ 100 ms local (PROPOSED). Notification fan-out via gateway without blocking the engine.

## 9. Open questions
U10 default expiry; whether "approve similar for session" is offered when the provider lacks a native session scope (recommend: no — only provider-native scopes); per-provider maximum wait (X-05).

## 10. Prerequisites
Owner decisions D19, D20, D21, D22; S7; X-05.
