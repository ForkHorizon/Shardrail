# L2-03 — Provider Adapter Framework (outline)

> **Status:** PROPOSED OUTLINE — not approved. Modules M06 (framework + ACP client), M07 (Codex), M08 (Claude, stub pending S4/D29).
> **Provisional L1 dependencies:** baseline 05; candidate d05; D6, D7, D8, D24, D29.

## 1. Purpose
Translate each provider's official protocol into Shardrail's normalized events and commands without flattening provider-specific capabilities, and survive provider upgrades.

## 2. Scope / exclusions
- In: capability negotiation, compatibility classes, normalized event mapping, `provider_ext` passthrough, approval request/response mapping, cancel/steer/resume/load/fork mapping, replay mode, history listing/reading (F15), schema validation (strict for `tested`, shadow for `untested-newer`).
- Out: process spawning (L2-01), persistence (L2-02), approval policy (L2-04), UI.

## 3. Adapter contract (conceptual)
- **Lifecycle:** `initialize(capabilities_out) → capability set` ; `open_session(params)` ; `prompt` ; `cancel` ; `respond_approval(approval_ref, decision)` ; optional `steer`, `resume`, `load`, `fork`, `list_history`, `read_history`.
- **Outputs:** normalized events (baseline list retained: `session_started`, `turn_started`, `text`, `thought`, `tool_started`, `tool_updated`, `permission_requested`, `permission_resolved`, `plan`, `usage`, `turn_finished`, `session_degraded`, `notice`) + tier tag (ephemeral/durable) + provider refs.
- **Decision mapping:** provider-native options preserved with their real scope (e.g., Hermes `allow_always` = permanent provider rule; Codex `acceptForSession`).
- **Never declared:** ACP client `fs/*`, `terminal/*` (D7).

## 4. Per-protocol notes
- **ACP client (Grok, Hermes, Claude-ACP):** prefer `session/resume` when advertised; `session/load` → replay mode; vendor extensions (`x.ai/*`) discovered, not hardcoded.
- **Codex app-server:** stdio, no `experimentalApi`; items keyed by item IDs; `item/completed` authoritative; approval methods `item/commandExecution/requestApproval`, `item/fileChange/requestApproval`; `serverRequest/resolved` → approval `withdrawn`; `thread/shellCommand` not exposed in normal UI; schema reference compared on version change.
- **Claude:** S4 chooses adapter vs SDK supervisor; D29 terms gate; API-key-only in product builds until U9.

## 5. Invariants
- No method is called unless capability says so (baseline).
- A missing, malformed, or timed-out approval exchange never maps to allow.
- Unknown messages produce `notice`, never panics or silent drops.

## 6. Failure modes
Version upgrade mid-session (binary replaced on disk; running process unaffected until restart); schema divergence; provider stuck awaiting approval response after Shardrail restart; replay interleaving; partial JSON lines / oversized lines (cap and desync handling).

## 7. Performance
Parsing cost negligible vs provider rate (INFERRED); main concern is delta volume → tier tagging at source. Provider process footprint measured per topology.

## 8. Security
All provider output untrusted (B-1). Adapter never reads provider credential stores; "not logged in" detected from protocol errors (baseline retained).

## 9. Open questions
- Normalized model for multi-agent/subagent activity (Claude `parent_tool_use_id`, Grok subagents) — display-only as baseline says, but event shape needed.
- Cost/usage normalization ("no data" ≠ 0, retained).
- Whether `x.ai/session/fork` etc. become first-class capabilities.

## 10. Prerequisites
S1–S4 (+ X-02, X-03, X-04, X-05); D24 approval; U9 for M08.
