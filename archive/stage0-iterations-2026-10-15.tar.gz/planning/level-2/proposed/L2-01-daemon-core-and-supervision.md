# L2-01 — Daemon Core, Lifecycle and Provider Supervision (outline)

> **Status:** PROPOSED OUTLINE — not a specification; not approved. Modules M01, M05.
> **Provisional L1 dependencies:** baseline 04 §5–§6; candidate d04; D1, D8, D11, D20, D27.

## 1. Purpose
Host every daemon module in one process per host; own provider processes from spawn to reap; make startup, shutdown, and crash behavior predictable on macOS and Linux.

## 2. Scope / exclusions
- In: process start/stop, single-instance lock on the data dir, configuration loading, data-dir layout, health and diagnostics ring, provider discovery (path + version), spawn per topology, environment sanitization, process groups, stdio plumbing, exit/crash detection, orphan reporting.
- Out: protocol translation (L2-03), client auth (L2-05), approvals (L2-04), storage format (L2-02).

## 3. Responsibilities (conceptual)
1. **Startup order:** lock → open journal (salvage path if corrupt) → mark recovered sessions (process=`exited`, `delivery_unknown`, `outcome_unknown`) → start gateway listener(s) → ready. Target: B6/B7.
2. **Shutdown modes:** (a) app quit with "cancel": protocol cancel to each running turn → grace period → terminate process group → reap; (b) "keep running" only when a launch agent exists (Phase 2); (c) Linux: systemd stop = (a).
3. **Supervision:** one supervision record per provider process: pid/pgid, binary path, version, compatibility class, sessions hosted, start time, footprint sample (on demand, not periodic beyond B9).
4. **Crash handling:** EOF or exit → notify session engine; never auto-restart (baseline retained); restart only by human command.
5. **Environment:** allowlist inherited variables; strip Shardrail variables; per-provider extras only from documented flags (e.g., Grok auto-update suppression).
6. **Discovery:** resolve binaries from PATH plus user-configured paths; show full path and version (baseline R-binary substitution note retained).

## 4. Invariants
- Exactly one daemon per data dir.
- Every spawned process belongs to a process group the daemon can signal.
- No provider ever receives Shardrail credentials, socket paths, or another provider's environment.
- No periodic timer more frequent than B9 allows when idle.

## 5. Failure modes to design for
Daemon kill -9 mid-write; provider exits with children still running; provider hangs on stdin backpressure; binary replaced while running (auto-update); disk full; data dir on network filesystem (refuse or warn — SQLite locking).

## 6. Security notes
Runs as the user (never root). On Linux remote, optional separate agent user (U11) means the supervisor spawns providers via a privilege boundary — this is a significant design fork that must be decided before detailed planning.

## 7. Performance and reliability expectations (proposed)
B1 ≤ 40 MB idle; B6 ≤ 1.5 s cold start (with shell); B7 ≤ 1 s session list after kill -9; B11 idle wakeups; provider footprint reported per process, never folded into B1.

## 8. Open questions
- U11 separate agent user: same daemon spawning across users (needs helper) or per-user daemons?
- Exact grace periods for cancel → terminate per provider (S1–S4).
- Launch-agent mode (Phase 2) — reuse same binary with `--background` semantics?

## 9. Prerequisites for detailed planning
Owner decisions on D1, D11, D20; S1–S4 results on cancel/exit behavior; S7 results.
