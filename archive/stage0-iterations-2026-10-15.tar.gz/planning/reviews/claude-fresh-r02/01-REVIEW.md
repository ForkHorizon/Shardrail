# 01 — Fresh Independent Re-Review of Shardrail Stage 0 (round r02)

> **Reviewer:** Claude (Opus 5.5), fresh context, adversarial to prior work · **Date:** 2026-10-15
> **Stage:** 0 — planning only. Nothing here is owner-approved; nothing authorizes implementation. No existing file was edited.
> **Scope:** whole plan — Grok baseline (layer 1), Claude r01 critique (layer 2), candidate v0.2 (layer 3), consistency report / registers (layer 4), proposed Level 2 outlines and backlog (layer 5).
> **Files read in full:** `MASTER_PLAN.md`; `level-1/01…15`; `reviews/claude-stage0-r01/01-INDEPENDENT-REVIEW.md`, `02-STRESS-TEST.md`; `candidates/claude-stage0-v0.2/` (all 14 files); `level-2/proposed/` (all 6); `backlog/proposed/BACKLOG.md`; `handoffs/claude-stage0/` (handoff, checkpoint, final summary, packets P1–P6); `governance/REVIEW_PROTOCOL.md`. Spot-checked `source/MASTER_PLAN.original.ru.md` (§4.6 bridge wording, §10.2).
> **Labels:** VERIFIED (primary source read today, URL given) · INFERRED · UNVERIFIED · CONTRADICTED · REQUIRES FUTURE EXPERIMENT. No measurement was taken; no provider was run.

## 1. Summary verdict

The baseline direction holds, and most of v0.2 is a real improvement: the approval record (D19), two event tiers (D17), intent journaling (D30) and safe Git (D23) are the right changes. But v0.2 has **three blocking gaps of its own**, all in places where it says a problem is solved:

1. **Control-plane isolation (D20) protects secrets only.** It does not protect the *integrity* of Shardrail's own state (pairing verifiers, trust state, policy, binaries) or check the *identity of the daemon* the client talks to. A same-UID agent that can write to `~/Library/Application Support/Shardrail/` doesn't need to steal anything (R2-01).
2. **Safe Git (D23) is incomplete.** The hardened CLI flags don't turn off Git **filter drivers**. The leading Rust library candidate (gix) *supports* external filter programs. An agent writing `.git/config` inside a *trusted* workspace can turn Shardrail's own Git view into an escape from the agent's sandbox (R2-02).
3. **Recovery assumes provider processes die with the daemon.** On macOS nothing guarantees this. Orphaned providers can keep running approved tools while the restarted daemon marks them `exited` and may start a second process on the same provider session (R2-03).

Other material problems: approval scopes that weaken policy can be granted from a phone (R2-08); unknown provider *server requests* would hang turns (R2-07, VERIFIED new Codex request types); D18 lacks transitions (R2-05); ACP replay deduplication by ID is impossible because IDs are optional (R2-06); the backlog puts the Claude legal question on the critical path of the whole of Phase 1 (R2-13). There are also ID/traceability defects (R2-14, R2-15). For a solo developer, v0.2's P1a is still too large (R2-23).

**Recommendation:** ACCEPT WITH CHANGES for v0.2 direction; **REWORK** D20, D23, and the supervisor/recovery model (C-04) before any Level 2 detail on L2-01/L2-04.

## 2. Evidence gathered this round (access date 2026-10-15)

| ID | Source | Finding | Label |
| --- | --- | --- | --- |
| E2-01 | <https://agentclientprotocol.com/protocol/tool-calls> | Permission outcomes: `cancelled` / `selected{optionId}`; option kinds `allow_once`, `allow_always`, `reject_once`, `reject_always`; the agent is **not** required to offer a reject option; when the prompt turn is cancelled the client MUST answer pending requests with `cancelled`. | VERIFIED |
| E2-02 | <https://agentclientprotocol.com/protocol/session-setup> | `session/load` MUST replay the whole conversation; `sessionCapabilities.resume` → `session/resume` MUST NOT replay; listed among stable lifecycle requests; `messageId` on chunks is conditional ("If the Agent provides message IDs…"). | VERIFIED |
| E2-03 | <https://learn.chatgpt.com/docs/app-server> (redirect from developers.openai.com/codex/app-server) | Server requests include `item/permissions/requestApproval` (grants network/filesystem permissions; `scope: "session"` persists across turns), `mcpServer/elicitation/request`, `item/tool/requestUserInput` (with `autoResolutionMs`). Command decisions also include `acceptWithExecpolicyAmendment`. `serverRequest/resolved` "confirms that the pending request has been answered or cleared"; explicit cleanup on turn start/complete/interrupt is stated for `requestUserInput`. **No approval timeout or disconnect behavior documented.** Generated schema "specific to the Codex version you ran". Per-turn `cwd`/sandbox override confirmed. `thread/shellCommand` runs outside the sandbox. | VERIFIED |
| E2-04 | <https://code.claude.com/docs/en/agent-sdk/overview> | Note: "Unless previously approved, Anthropic does not allow third party developers to offer claude.ai login or rate limits for their products…" and directs to API-key auth; SDK governed by Commercial Terms; branding may not use "Claude Code". | VERIFIED |
| E2-05 | <https://code.claude.com/docs/en/agent-sdk/claude-code-features> | Omitting `settingSources` equals `["user","project","local"]`: project `settings.json` **hooks**, CLAUDE.md and skills load by default; `settingSources: []` disables them; `~/.claude.json`, managed policy, **auto memory**, and claude.ai MCP connectors (with claude.ai login) are read regardless. | VERIFIED |
| E2-06 | <https://github.com/agentclientprotocol/claude-agent-acp> | License Apache-2.0; owner `agentclientprotocol` org; npm `@agentclientprotocol/claude-agent-acp`; README is silent on the auth mode and on `settingSources`. | VERIFIED (resolves r01 E-10 UNVERIFIED for the license) |
| E2-07 | <https://git-scm.com/docs/gitattributes> | Filter drivers (`filter.<driver>.clean/smudge/process`) are defined in config, including `.git/config`, and assigned by `.gitattributes`; `process` filters run for a whole Git command. Whether `git status` invokes clean filters is not stated on this page. That it does for stat-dirty files is INFERRED. | VERIFIED (definition) / INFERRED (status path) |
| E2-08 | <https://docs.rs/gix-filter/latest/gix_filter/> | gix-filter: `driver` module "use filter programs to perform any kind of conversion"; `Pipeline` has "support for external filters". | VERIFIED |

## 3. Findings

Severity: BLOCKING (resolve before Level 2 detail of the affected module) · IMPORTANT · MINOR · QUESTION.

### R2-01 — D20 protects secrecy, not integrity or daemon identity (BLOCKING · security)
- **Location:** `candidates/…/02-DECISION-REGISTER.md` D20; `d08-security.md` §2 row R15; `level-2/proposed/L2-04` §5; `L2-05` §3–§5; register N10; consistency C-06.
- **Problem:** D20 keeps agents away from *credentials* (env scrubbing, keychain, ancestry check). An agent with the same UID and write access to the user's home can do more:
  - **(a)** Edit the daemon's SQLite DB and config (data dir is `0700` but owned by that same user). It can add its own paired-credential *verifier*, flip workspace trust to `trusted`, or change expiry policy. Then it connects with credentials it minted itself.
  - **(b)** Replace provider binaries on PATH (baseline §10.1 treats PATH substitution as hardening only).
  - **(c)** Bind the socket path while the daemon is down and pose as the daemon. No client authenticates the server, and L2-05 §3 "credential proof" may be a bearer token that would then be captured.
  
  So v0.2's "real control is credential secrecy" (C-06) is not the real control. The only real boundary is the **provider sandbox's write/connect denial** for Shardrail's data dir and socket dir, or a separate UID.
- **Evidence:** POSIX same-UID semantics (INFERRED). Whether each sandbox profile blocks these paths: REQUIRES FUTURE EXPERIMENT (X-01 covers reads/connect but not **writes** to the data dir).
- **Recommended change:**
  - Restate D20: the approval guarantee holds only for sessions whose sandbox denies write to the Shardrail data dir, binaries and socket dir, and denies connect to the socket. Every other session shows a persistent "approvals not protected from this agent" label.
  - Extend X-01/S7 to cover write and bind as well as read and connect.
  - Use challenge-response (not bearer) credential proof, plus server authentication (a daemon key pinned at pairing).
  - Treat security-relevant rows (verifiers, trust, policy) as integrity-protected: MAC with a key in the keychain on macOS. On Linux this is impossible on a shared UID, which supports making U11 the default for remote hosts.
- **Affected:** D20, D21, N10, d08 §1–2, L2-04 §5, L2-05 §3–5, 03-RISK R15, C-06, d13 S7.

### R2-02 — D23 safe-Git rule misses filter drivers; agent-writable `.git/config` becomes a sandbox escape (BLOCKING · security)
- **Location:** D23; `d08` threat row R18; `d13` S8; backlog T0.7.1, T1.9.1.
- **Problem:** D23's CLI hardening (`core.fsmonitor=false`, `core.hooksPath=/dev/null`, `--no-ext-diff`, `--no-textconv`) does not disable `filter.<name>.clean`/`process` drivers. Those are configurable in `.git/config` under arbitrary names, so they cannot be overridden by name with `-c`. The library route is not safe by default: gix-filter supports external driver programs (E2-08).

  More serious: D23 frames the threat around `unknown` workspaces. But in a **trusted** workspace, an agent with `workspace-write` can usually edit `.git/config`. Whether each provider protects `.git` is UNVERIFIED. Shardrail then runs the configured program **outside the agent's sandbox**, which is a privilege escalation from sandboxed agent to user.
- **Evidence:** E2-07 VERIFIED (drivers defined in `.git/config`), E2-08 VERIFIED; `git status` invoking clean filters INFERRED.
- **Recommended change:**
  - D23 applies in **all** trust states.
  - The rule becomes: "Shardrail never executes any program named by repository-local configuration or attributes."
  - Library choice must explicitly disable driver filters and external diff/textconv. For worktree-vs-index comparison of filtered files, show "content check skipped (filter)" instead of running the filter.
  - Drop the hardened-CLI fallback, or run it only with an empty, controlled config environment.
  - S8 fixture set: fsmonitor, `filter.*.clean`, `filter.*.process`, `diff.*.textconv`, `diff.external`, `core.hooksPath`, an agent modifying `.git/config` mid-session.
- **Affected:** D13/D23, F8, R18, d08, d13 S8, BACKLOG E0.7/T1.9.1, M11.

### R2-03 — Recovery assumes providers die with the daemon; orphans can keep executing (BLOCKING · logic)
- **Location:** consistency C-04 ("providers are stdio children and lose their channel"); `d07` §3 row kill -9; `L2-01` §3.1, §4, §5; `L2-04` §7.
- **Problem:** after `kill -9` or a crash of `shardraild` on macOS:
  - No mechanism kills the provider process groups. There is no `PR_SET_PDEATHSIG` on macOS, and L2-01's "process group the daemon can signal" needs a live daemon.
  - A provider blocked writing to stdout may die of SIGPIPE, but one running a long tool (a build, `rm`, `git push`) keeps going.
  - On restart the daemon marks `process=exited`. Its own resume may then start a **second** provider on the same provider session, with two processes writing the same `~/.codex`/`~/.claude` session state.
  - On Linux, a systemd `KillMode=control-group` unit cleans up only if configured, and not in D11 app-child mode.
- **Evidence:** INFERRED (POSIX/macOS process semantics); per-provider stdin-EOF behavior is REQUIRES FUTURE EXPERIMENT.
- **Recommended change:**
  - Record pid, pgid and start-time durably at spawn (`provider_spawned` event).
  - On startup, enumerate surviving recorded groups and show "orphaned provider still running" with kill/adopt-not-possible choices. Never resume a session whose old process is alive.
  - Linux: `PR_SET_PDEATHSIG` via a pre-exec hook, plus cgroup kill in the systemd unit.
  - macOS: a tiny supervisor shim per provider group that kills the group when its parent pipe reaches EOF.
  - Add the case to S1–S4 ("kill daemon, observe provider").
- **Affected:** C-04, d07 §3, L2-01, L2-04 §7, d13 S1–S4, BACKLOG E1.3.

### R2-04 — App crash leaves an orphan daemon that blocks relaunch (IMPORTANT · logic)
- **Location:** D11 (modified) and `d04` §2; baseline §9.2 ("second instance exits with a clear error"); `L2-01` §3.1.
- **Problem:** with lifetime = app and the daemon as a separate child, a crash of the shell leaves the daemon running. On relaunch the new daemon hits the single-instance lock and exits, so the app is unusable until the user kills a process. There is no attach-to-existing path, and no rule for whether an orphaned daemon keeps turns running without any UI (approvals unseen).
- **Recommended change:** the shell always tries to *connect* first (authenticating the server, R2-01) and spawns only if nothing is there. Define orphan-daemon policy: keep running and post OS notifications, or cancel turns after N minutes without a UI client.
- **Affected:** D11, d04 §2, L2-01 §3, C-03.

### R2-05 — D18 state model lacks transitions and turn outcomes (IMPORTANT · logic)
- **Location:** `d04` §3 diagram; D18; L2-02 §3.
- **Problem:** the turn machine has no transition when the process exits during `running`/`cancelling`/`stalled`, and no terminal outcome (completed / cancelled / failed / interrupted). Other gaps:
  - `cancelling` has no timeout or escalation path (protocol cancel ignored → terminate group, baseline §7.4);
  - `stalled → cancelling` is missing;
  - `link=desynced` has no recovery;
  - `delivery=unknown` has no resolution transitions (user resends, discards, or confirms);
  - there is no `resuming`/`loading` state while `session/load` replays;
  - `process=exited` is only representable as terminal, though a resume respawns the process.
- **Recommended change:** before L2-02 detail, write one transition table per dimension with every event × state cell (including "impossible" cells). Add a `turn_outcome` field and a `resuming` link state.
- **Affected:** D18, d04 §3, d07 §3, L2-02, d10 badge precedence.

### R2-06 — ACP replay reconciliation by ID is not achievable; a simpler rule exists (IMPORTANT · logic/evidence)
- **Location:** `d05` §1 replay mode; L2-02 §4 invariant 5 ("Replay … never produces duplicate items"); D17 durable "item completed (full content)"; R22.
- **Problem:** ACP message chunks carry `messageId` only optionally (E2-02). There is also no ACP "item completed" event for message text: completion has to be inferred from a change of update type or from the `session/prompt` response. So ID-based reconciliation is heuristic, and invariant 5 can't be guaranteed. D17's "item completed (full content)" doesn't exist for ACP and has to be synthesized.
- **Simpler alternative:** when the Shardrail journal is complete for a session, which is the normal case, **discard the replay stream** during `session/load` (use it only to restore provider state) and journal one `provider_reloaded` marker. Only when the journal has a known gap (crash loss), present the replay as a separate, clearly labelled "provider history" view instead of merging it.
- **Affected:** d05 §1, d06 §2, L2-02 §4, L2-03 §4, R22.

### R2-07 — Unknown provider *server requests* would hang turns; Codex already has request types v0.2 doesn't model (IMPORTANT · security/logic)
- **Location:** D24 / `d05` §1 ("Unmapped messages → `notice`"); `L2-03` §5; `d05` §2 matrix (approval decisions row).
- **Problem:** the notice rule is fine for notifications but wrong for **requests**, which expect a response. Left unanswered, a turn blocks indefinitely, and C-02 exempts pending approvals from stall detection. Codex today has `item/permissions/requestApproval` (grants network/filesystem permissions, `scope: "session"` persists), `mcpServer/elicitation/request` and `item/tool/requestUserInput` (E2-03). None of these are in the matrix, the L2-04 card contract, or the fake agent scenarios. `item/permissions/requestApproval` with session scope is a policy-*widening* request.
- **Recommended change:**
  - Adapter invariant: every unknown server request gets an immediate refusing response (decline/empty grant/JSON-RPC error), plus a `notice`.
  - Add permission-grant and elicitation to the approval-card contract.
  - Treat session-scoped grants as policy weakening (R2-08).
  - Add these to T1.2.2.
- **Affected:** D24, d05, L2-03 §5, L2-04 §4, BACKLOG T1.2.2.

### R2-08 — Provider-native persistent/session scopes bypass D21's `control_policy` rule (IMPORTANT · security/contradiction)
- **Location:** D21 ("`control_policy` … only from a local desktop client"); D19; `d05` §3 (Hermes `allow_always`, Codex `acceptForSession`, `acceptWithExecpolicyAmendment`); `L2-04` §6 invariant 4.
- **Problem:** any client with `respond_approval` (including a phone) can pick `allow_always`, which writes a permanent Hermes allowlist entry. The same applies to ACP `allow_always`, Codex `acceptForSession`/execpolicy amendments, and session-scoped permission grants. Each one weakens policy beyond a single action, which is exactly what `control_policy` is meant to gate.
- **Recommended change:** classify decision options as `once` vs `widening`. `widening` requires `control_policy` (local desktop). Remote clients see only once/deny. Put this in the L2-04 card contract.
- **Affected:** D19, D21, d05 §3, L2-04 §4/§6, L2-05 §5, R8.

### R2-09 — Provider-side expiry is invisible for ACP; cards can show a dead request as pending (IMPORTANT · logic)
- **Location:** D19 default `min(180 s, provider limit)`; `d05` §3 Hermes rule; `L2-04` §7.
- **Problem:** the "provider limit" is not knowable. Hermes `approvals.timeout` is user-configurable in `~/.hermes/config.yaml`, which Shardrail does not read. Codex documents no approval timeout (E2-03). If the provider expires first and the turn continues, nothing tells Shardrail. The card stays `pending`, the user taps Allow, and the CAS says `allowed`, but the provider ignores it. This reproduces the "user believes they allowed" failure (S-4a) that D19 set out to remove.
- **Recommended change:** treat as withdrawal (a) any later update that terminates the same tool call, (b) the turn ending, (c) a JSON-RPC error on the response. Show "sent, not acknowledged" rather than "allowed" until the provider's next event for that tool call. Measure per-provider limits in X-05 before setting a default.
- **Affected:** D19, L2-04 §3/§7, d08 §3, X-05.

### R2-10 — "Expired → provider deny" is undefined when ACP offers no reject option (IMPORTANT · logic/evidence)
- **Location:** `L2-04` §3 (`expired: … maps to provider deny`); D12/D19.
- **Problem:** ACP does not require a reject option, and `cancelled` is specified for cancelled turns (E2-01). If an agent offers only allow options, Shardrail cannot deny the request without cancelling the turn.
- **Recommended change:** mapping rule: expiry → select a `reject_once` option if offered, else `session/cancel` the turn and answer `cancelled`. Fixture for "no reject option". Same rule for user deny.
- **Affected:** L2-04 §3, L2-03 §3, D19.

### R2-11 — Claude trust gating (F13) via the SDK/adapter needs `settingSources`, not `--bare`; some inputs ignore it (IMPORTANT · security/evidence)
- **Location:** baseline §7.3 (`--bare` as viewing mode), F13, R7; `d05` §3; d13 S4.
- **Problem:** `--bare` is a CLI flag. The chosen channels are SDK-based, and the SDK **loads project hooks, CLAUDE.md and skills by default** (E2-05). Even with `settingSources: []`, auto memory, `~/.claude.json` and claude.ai MCP connectors still load. Auto memory is a prompt-injection *persistence* path: an untrusted repo's session can write memory that loads into the next session. Whether `claude-agent-acp` exposes `settingSources` is not documented (E2-06).
- **Recommended change:**
  - In `unknown`/`restricted`, require `settingSources: []` and `CLAUDE_CODE_DISABLE_AUTO_MEMORY=1`, and (with claude.ai login) disable connectors.
  - S4 must verify the adapter can pass these through, or the direct SDK route wins.
  - Rewrite F13 acceptance for Claude in these terms.
- **Affected:** F13, R7, d05 §3, d13 S4, L2-03 §4, CR-20.

### R2-12 — D29/U9: evidence correct, but the "personal builds unaffected" carve-out is unsupported (IMPORTANT · product/evidence)
- **Location:** D29; `d08` §5; d13 §6.
- **Problem:**
  - The Agent SDK note does not distinguish personal from distributed builds. It says to use API-key auth (E2-04). A Fork Horizon build given to anyone is a third-party product.
  - The branding rule ("Claude Code" not permitted) affects UI labels: the provider row should read "Claude Agent" or similar.
  - The adapter license is now verified as Apache-2.0 (E2-06), which partly resolves C-09. The usage-terms question remains.
- **Recommended change:** drop the carve-out, or limit it to "the owner's own machine, never distributed". Add a UI naming rule. Update C-09/E-10.
- **Affected:** D29, d08 §5, d13 §6, C-09, R16.

### R2-13 — Backlog puts the Claude legal question on the critical path of all of Phase 1 (IMPORTANT · roadmap)
- **Location:** `backlog/proposed/BACKLOG.md` §5 graph (`E04 --> E06`; `E113 & E114 & E115 --> E116 --> E117 --> G2`), §2 P1a "Depends on P0 S2/S3/S5/S7/S8"; d13 §6 stop rule.
- **Problem:** the dependency chain makes everything wait on Claude:
  - E0.4 acceptance includes the owner/legal U9 answer.
  - E0.6 (S7) depends on E0.4, and P1a depends on S7, so P1a waits for a legal answer.
  - Phase 1 close needs E1.16, which waits for E1.15 (Claude), so Phase 2 and Phase 4 wait too.
  
  This contradicts d13 §6 and baseline §16 ("Claude may drop out… without affecting other adapters").
- **Recommended change:** S7 depends only on the providers in P1a. E1.16 is per-provider. The P1-close gate reads "Claude included **or** formally excluded by recorded decision".
- **Affected:** BACKLOG §2, §3, §5 (critical path text), d13 §2/§6.

### R2-14 — ID traceability: candidate-D numbers in r01 don't match the register; several ID namespaces collide (IMPORTANT · traceability)
- **Location:** `reviews/claude-stage0-r01/01-INDEPENDENT-REVIEW.md` CR-03, CR-04, CR-13, CR-14, CR-17; `02-STRESS-TEST.md` S-6; `02-DECISION-REGISTER.md`; `d08` §1; `03-RISK` §2; packets.
- **Problem:**
  - **Off-by-one candidate numbers.** r01 cites "candidate D21" (rendering, now D22), "D22" (Git, now D23), "D23" (compatibility, now D24), "D24" (multi-host, now D25), "D20" (client identity, now D21) and "D25" (versioning, now D26). No crosswalk exists, and r01 is frozen, so readers following CR → D land on the wrong decision.
  - **Namespace collisions:**
    - trust boundaries `B-1…B-6` (d08) vs budgets `B1…B16`;
    - stress scenarios `S-1…S-12` vs spikes `S1…S8`;
    - evidence `E-01…` vs epics `E0.1…`;
    - packets `P1…P6` vs phases `P0…P4`/`P1a`.
    
    The handoff's ID list (F, N, B, D, R, U, S, CR, C, E, X) is therefore ambiguous for B, S, E and P.
- **Recommended change:** add a crosswalk file (CR → final D). Rename to `TB-n` (trust boundaries), `ST-n` (stress), `EV-n` (evidence), `PK-n` (packets) in the next revision.
- **Affected:** r01 (via crosswalk only), 02-DECISION-REGISTER, d08, packets, BACKLOG.

### R2-15 — Module dependency cycles and table/graph disagreement (MINOR · traceability)
- **Location:** `level-2/proposed/00-MODULE-INDEX.md` §1 table vs §2 graph.
- **Problem:**
  - M09 "Depends on M03, M10" (table) while the graph has `M09 --> M10` (M10 depends on M09): a cycle.
  - M03 persists approval records owned by M09 while M09 depends on M03: a second cycle.
  - M01's startup opens the journal (L2-01 §3.1) but M01 is listed as depending only on M02.
  - `M11 --> M10` in the graph is not in M10's table row.
- **Recommended change:** define ports (approval store interface, notification sink) to break the cycles; make the table authoritative and regenerate the graph from it.
- **Affected:** 00-MODULE-INDEX, L2-01, L2-02, L2-04.

### R2-16 — Purge (F17) contradicts online backups (D26) and SQLite page reuse (IMPORTANT · security/contradiction)
- **Location:** register F17 ("Purged session leaves no rows"); D26 (periodic online backup to the data dir); `d07` §4.
- **Problem:** purged sensitive content survives in backup files, in free pages, and in the WAL until checkpoint. "No rows" is the wrong acceptance test. Not listed in the C-list.
- **Recommended change:**
  - Purge = delete + `secure_delete`/VACUUM + checkpoint + purge or rotate backups.
  - Alternatively, no automatic backups of the journal by default; export only.
- **Affected:** F17, D26, d07 §4, R19, L2-02 §7.

### R2-17 — History import (F15) contradicts baseline §9.1 and is not low-risk (IMPORTANT · contradiction/scope)
- **Location:** register F15; `d13` §2 (Phase 1 close) and §5 ("read-only and low risk"); C-10/C-11; baseline `level-1/07` §9.1 ("The daemon does not copy the providers' home directories into its database").
- **Problem:** importing transcripts into the journal copies provider data, including secrets and untrusted text, into Shardrail's store. That is the exact thing §9.1 forbids, and it is not recorded as a contradiction.
  - Claude history import needs the SDK (Node), so it falls under U9.
  - Hermes CLI sessions are only Plausible.
  - It adds a fourth provider-specific surface to Phase 1 close.
- **Recommended change:** on-demand, read-through viewing via official APIs without journaling (cache only in memory), and "continue as new session" through official resume. Move it to Phase 2 or Phase 4. Record the §9.1 contradiction.
- **Affected:** F15, d13, C-list, d05 §1, BACKLOG E1.16.

### R2-18 — D24 runtime schema generation contradicts baseline §7.3 (IMPORTANT · contradiction)
- **Location:** D24 ("on version change, compare generated schema (Codex) … before first session"); baseline `level-1/05` §7.3 ("the reference is the saved file, not 'generate on the fly on the user's machine'").
- **Problem:** this is an unrecorded reversal of a baseline decision. The generator is experimental, and running it means executing the provider binary outside a session. Version-specific output is confirmed (E2-03), so the comparison would be meaningful, but it is still a new runtime dependency on an experimental command.
- **Recommended change:** record it as C-15. Make generation optional and diagnostic-only; tolerant parsing plus capability negotiation are the primary guard.
- **Affected:** D24, d05, C-list.

### R2-19 — `untested-newer` warn-and-run should run with the strictest policy (IMPORTANT · security)
- **Location:** D24, F1 (modified), owner question "D24 warn-and-run".
- **Problem:** shadow schema validation cannot detect *semantic* approval changes, such as a new default auto-approve or a new widening option. Warn-and-run on an untested version is then a silent weakening risk.
- **Recommended change:** `untested-newer` forces the strictest supported sandbox, hides `widening` options (R2-08), and disables allow-all until the version is marked `tested`. This is cheap and keeps the CR-10 maintainability benefit.
- **Affected:** D24, F1, R20, L2-03 §3.

### R2-20 — Cursor validity breaks after DB salvage, restore, or re-creation (IMPORTANT · logic)
- **Location:** `d06` §1 (`EventId` per-host monotonic; `HostId` random in data dir); D26 salvage/new DB; `d07` §3.
- **Problem:** a new or restored DB restarts or rewinds `event_id`. Clients holding cursor 50 000 will get nothing or miss events silently. A copied data dir duplicates `HostId`.
- **Recommended change:** add a `journal_epoch` (random per DB creation) to the handshake and cursors. On mismatch, force a full resync.
- **Affected:** d06 §1, L2-05 §3, L2-02 §4.

### R2-21 — Pairing has no bootstrap; SSH-bridge pairing is redundant (IMPORTANT · logic/complexity)
- **Location:** D21 ("pairing via a one-time code shown in an already-authenticated client"); `L2-05` §4–§5; N4 (modified).
- **Problem:**
  - The first client cannot be paired this way.
  - On remote hosts, SSH already authenticates the same UID, which can read or modify the daemon's verifier store anyway (R2-01). A second credential there adds friction without security.
- **Recommended change:**
  - Bootstrap: the local desktop client is admitted by peer UID plus a code-signing check of the peer (macOS), then gets a keychain credential.
  - SSH bridge: SSH auth suffices.
  - Pairing applies only to loopback/browser and mobile.
- **Affected:** D21, N4, L2-05 §4–5.

### R2-22 — Multiple write-capable agents on one worktree are unguarded (IMPORTANT · product/logic)
- **Location:** baseline `level-1/01` §2.4 (UI editing rejected because "two writers on one tree cause races"); §8.1 `WorkspaceId`; d10 workspace pane; Phase 4 "worktree clarity".
- **Problem:** the plan rejects human+agent concurrent writes but allows two agent sessions with `workspace-write` on the same checkout, which is the same race. The workspace diff also cannot attribute changes to a session. This is central to a multi-agent product and is absent from v0.2.
- **Recommended change:** default rule: one write-capable session per worktree. A second session starts read-only or the user is offered a provider-native worktree (Grok `x.ai/git/worktree/*`, Codex/Claude per spike). The UI shows which session holds the write lease.
- **Affected:** 01 §2.4, 02 (new F), d04, d10, Phase 1 scope.

### R2-23 — v0.2 P1a is still too large for one developer (IMPORTANT · complexity)
- **Location:** `d13` §2 slice 1a; BACKLOG P1a (XL); consistency §3 "minimal viable cut".
- **Problem:** P1a contains:
  - schema codegen (D27) and two fake protocols;
  - daemon, two-tier journal, gateway, relay;
  - pairing with four scopes, approvals (CAS), trust, safe Git;
  - inbox and session UI;
  - plus gates on five budgets.
  
  The self-review's cut (two scopes, defer federation) is not reflected in d13 or the backlog. Several mechanisms exist only for multi-client or remote use, which P1a doesn't have: per-client bounded queues, presence, the scope matrix, upcasting for every schema version forever.
- **Recommended change:**
  - P1a = one local client and one transport;
  - no scopes beyond local-full;
  - no browser listener;
  - JSON Schema for the journal only, with hand-written wire types until a second client exists;
  - one fake ACP agent;
  - gates B1, B4, B7 only.
  
  Also evaluate the simplest alternative explicitly: Phase 1 as daemon plus browser UI served on loopback, with no Tauri. This defers D11, D16 and M13 entirely; the trade-off is a TCP surface (QUESTION for owner).
- **Affected:** d13 §2, BACKLOG §2–§4, D21, D27, D26.

### R2-24 — B11 contradicts B9/N2 (MINOR · contradiction)
- **Location:** register B11 (≤ 1 wakeup/s idle); baseline N2/B9 (no periodic timer more often than 15 s at rest); C-01.
- **Problem:** two idle targets an order of magnitude apart, with no scope distinction. Heartbeats needed for presence and SSH keepalive aren't addressed.
- **Recommended change:** B9 covers Shardrail timers only (daemon and UI code); B11 covers measured total wakeups including WebKit. State presence as event-driven or heartbeat ≥ 15 s.
- **Affected:** 03-RISK §2, 09, C-01.

### R2-25 — CR-02 is overstated as BLOCKING; D16 vs loopback is a trade-off, not a fix (IMPORTANT · evidence/complexity)
- **Location:** r01 CR-02; D16; Russian source §4.6 (line 193: loopback bridge raised "only together with the window") and §10.2 (line 472: bridge secret passed to the shell).
- **Problem:** the baseline already implies that the window uses the loopback bridge with a secret passed to the shell. The design is under-specified, not impossible. D16's relay does not remove TCP from the product, since the browser path keeps it. In both designs the WebView JS must hold or receive a credential, so XSS in the WebView (D22) equals credential theft, which neither r01 nor D16 states.
- **Recommended change:** downgrade to a decision record. Choose relay or loopback on S5 latency and code size. In either case, specify credential delivery to the WebView and make D22 a prerequisite.
- **Affected:** D16, D2, D4, L2-05, d08.

### R2-26 — `hold_until_provider_limit` is unbounded for Codex (IMPORTANT · logic)
- **Location:** D19 opt-in policy; C-02 (pending approvals exempt from stall); `90-CONSISTENCY` §3 (stale approvals "not designed yet").
- **Problem:** Codex documents no approval limit (E2-03), so "hold until provider limit" can mean forever. The turn can't stall, and an allow given hours later executes in a changed workspace.
- **Recommended change:** a mandatory upper bound (owner-set, e.g. hours). Re-confirmation is required beyond a staleness threshold or if the workspace HEAD/diff changed since the request.
- **Affected:** D19, U10, C-02, L2-04.

### R2-27 — r01 E-03 overstates Codex request clearing (MINOR · evidence)
- **Location:** r01 E-03 ("pending requests cleared when a turn starts/completes/is interrupted"); `d05` §2 row "Pending approval on turn end … VERIFIED".
- **Problem:** the docs state the turn-boundary cleanup explicitly for `item/tool/requestUserInput`. For approvals they only say the notification "confirms … answered or cleared" (E2-03).
- **Recommended change:** relabel as INFERRED / REQUIRES FUTURE EXPERIMENT (add to S1).
- **Affected:** d05 §2, L2-03 §4, S1.

### R2-28 — Delta/durable ordering across tiers is unspecified (MINOR · logic)
- **Location:** D17; L2-02 §3–§4 (invariant 2: publish-after-commit).
- **Problem:** ephemeral deltas are published immediately, while `item_started` waits for a batched commit. Clients can receive deltas for an item they don't know yet.
- **Recommended change:** deltas carry enough item metadata to create a provisional item, or `item_started` is committed synchronously before the first delta is published.
- **Affected:** D17, L2-02, L2-05 §3.

### R2-29 — Checkpoint scheme can make durable writes quadratic (MINOR · performance)
- **Location:** `d06` §2 (checkpoints every 2 s / 64 KiB, compacted on completion); B15.
- **Problem:** if each checkpoint stores the full in-progress content, a long item writes O(n²) bytes before compaction.
- **Recommended change:** append-only incremental checkpoint chunks. B15 should measure bytes written, not only bytes retained.
- **Affected:** d06 §2, B15, L2-02 §8.

### R2-30 — P1a gate and content mismatch (MINOR · roadmap)
- **Location:** `d13` §2 slice 1a.
- **Problem:** the content includes the safe Git view and crash scenarios, but the gate omits F8 and F10.
- **Recommended change:** add F8 and F10 to the 1a gate, or move their content out.
- **Affected:** d13 §2.

### R2-31 — Handoff deferred to Phase 4 while riskier history import moves earlier (QUESTION · product)
- **Location:** `d13` §5; baseline §16 Phase 4; `01` §1 (handoff as headline capability).
- **Problem:** a minimal handoff (user-edited text bundle → first prompt of a new session) needs only existing pieces and is a differentiator. F15 is riskier (R2-17) yet scheduled earlier.
- **Recommended change:** owner decides; suggest a manual handoff MVP at Phase 1 close and F15 later.
- **Affected:** d13, BACKLOG E4.1, E1.16.

### R2-32 — Journal upcasting "for all versions ever written" is a permanent tax (MINOR · complexity)
- **Location:** D26; L2-02 §4 invariant 7.
- **Problem:** combining upcasting with "migrations never rewrite history" doubles the mechanisms a solo maintainer carries forever.
- **Recommended change:** forward-migrate the stored rows after a mandatory backup, keeping `schema_version` for detection; or upcast only within a supported window.
- **Affected:** D26, L2-02.

## 4. Agreement / disagreement with previous review and v0.2

### 4.1 r01 findings checked

| ID | Verdict | Reason |
| --- | --- | --- |
| CR-01 (BLOCKING) | **PARTIAL** | The threat is real (same UID, readable `0600` files; read-everywhere sandboxes). BLOCKING is justified. But r01/v0.2 frame it as *credential secrecy*. The larger exposure is the integrity of daemon state and daemon impersonation, and the true boundary is the sandbox write/connect denial or a separate UID (R2-01). |
| CR-02 (BLOCKING) | **DISAGREE on severity** | The baseline implies a loopback bridge for the window (RU §4.6, §10.2). It is under-specified, not impossible. The decision is a trade-off (R2-25). |
| CR-03 (BLOCKING) | **AGREE** | Standard but real risk classes; approval-card integrity (bidi/zero-width) justifies BLOCKING for the UI/approval L2. Add: WebView XSS = credential theft under either transport (R2-25). |
| CR-04 (BLOCKING) | **AGREE, understated** | Correct threat. The fix misses filter drivers and agent-modified `.git/config` in trusted workspaces (R2-02). |
| CR-11 (BLOCKING commercial) | **AGREE on evidence (re-VERIFIED E2-04); PARTIAL on D29** | The note directs third-party products to API keys. The personal-build carve-out is unsupported; there is a branding impact; the adapter license is now verified (R2-12). |
| CR-05 | PARTIAL | Correct problem. The ID-based fix is not achievable for ACP; the simpler discard-replay rule is better (R2-06). |
| CR-06 | AGREE | Tiers are needed. Ordering and checkpoint details are missing (R2-28, R2-29). |
| CR-07 | PARTIAL | CAS, disconnect ≠ resolution: right. The short timeout is a productivity issue, not a safety one. Provider-side expiry is invisible (R2-09); hold is unbounded (R2-26). |
| CR-08 | AGREE | Plus a crash/orphan path (R2-04). |
| CR-09 | AGREE | D18 is incomplete (R2-05). |
| CR-10 | AGREE | Needs a strict-policy guard (R2-19) and conflicts with baseline §7.3 (R2-18). |
| CR-12 | AGREE | Spike-gated table is sensible. |
| CR-13 | AGREE | SSH stdio bridge is the right default; remote `shardraild` PATH friction is acknowledged. |
| CR-14 | PARTIAL | Scopes are useful for mobile. Bootstrap is missing; redundant over SSH; four scopes too many for P1a (R2-21, R2-23). |
| CR-16 | AGREE | — |
| CR-17 | PARTIAL | Versioning yes; perpetual upcasting is heavy (R2-32). |
| CR-19 | AGREE | Purge/backup contradiction added (R2-16). |
| CR-20 | AGREE | Claude mechanism corrected (R2-11). |
| CR-24 | AGREE | v0.2 slicing still too large (R2-23). |
| CR-25 | PARTIAL | Read-only view is useful; journaling the import contradicts §9.1 (R2-17). |

### 4.2 New decisions D16–D30

| ID | Verdict | Reason |
| --- | --- | --- |
| D16 one protocol + relay | PARTIAL | One protocol: agree. Relay vs loopback is unresolved; credential exposure to the WebView is unaddressed (R2-25). |
| D17 tiers | AGREE (with changes) | R2-06 (no ACP completion event), R2-28, R2-29. |
| D18 orthogonal state | PARTIAL | Right idea; transition tables missing (R2-05). |
| D19 approval record | PARTIAL | Core is sound. Fix R2-08, R2-09, R2-10, R2-26. |
| D20 control-plane isolation | **DISAGREE as stated** | Misidentifies the control; needs integrity, server auth, sandbox write-deny (R2-01). |
| D21 identity/scopes | PARTIAL | R2-08 bypass, R2-21 bootstrap; too much for P1a. |
| D22 rendering | AGREE | Make it a prerequisite of D16 (R2-25). |
| D23 safe Git | **DISAGREE as stated** | Incomplete; library not safe by default; must apply in all trust states (R2-02). |
| D24 compatibility | PARTIAL | R2-07, R2-18, R2-19. |
| D25 SSH bridge + federation | AGREE | Phase 2 placement is right. |
| D26 versioning/retention | PARTIAL | R2-16, R2-20, R2-32. |
| D27 schema-first | PARTIAL | Journal schema yes; wire codegen deferable for a solo P1a (R2-23). |
| D28 mobile defer | AGREE | — |
| D29 Claude terms | PARTIAL | R2-12. |
| D30 intent journaling | AGREE | Note: retention of `command_id` for non-session commands (pairing, create-session) unspecified (MINOR). |

### 4.3 Where the previous review or v0.2 was wrong or overstated
1. CR-02 severity (R2-25).
2. C-06's claim that credential secrecy is "the real control" (R2-01).
3. C-04's assumption that providers die with the daemon (R2-03).
4. D23 adequacy (R2-02).
5. E-03 wording on approval clearing (R2-27).
6. "F15 is read-only and low risk" (R2-17).
7. D29 personal-build carve-out (R2-12).
8. The candidate-D cross-references in r01 (R2-14).

## 5. What this review did not check
- xAI/Grok primary docs (Grok facts remain as the baseline's local manual: UNVERIFIED); Hermes docs not re-read (E-06 relied on).
- Tauri 2.12.3 / Tauri 3 alpha status; Rust crate licenses; Android Web Push (X-07).
- macOS keychain ACL behavior against same-user `security` CLI access; Seatbelt behavior for Unix-socket connect/write per Codex/Grok profile (all REQUIRES FUTURE EXPERIMENT, see R2-01).
- Whether `git status` invokes clean filters in practice (INFERRED, R2-02).
- All performance budgets (none measurable at Stage 0); the WKWebView footprint claims.
- Bilingual fidelity of the translation beyond §4.6/§10.2 spot checks.
- Legal interpretation of the Anthropic note (owner/legal matter).
- `governance/REVIEW_ROUTES.md`, `SOURCE_MAP.md`, translation record, r01 inventory (skimmed or not read).
