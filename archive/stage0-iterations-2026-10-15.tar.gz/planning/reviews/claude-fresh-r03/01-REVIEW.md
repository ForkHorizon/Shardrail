# 01 — Fresh Adversarial Review of Candidate v0.3 (round r03)

> **Reviewer:** Claude (Opus 5.5), fresh context, adversarial to v0.3 and to r02 · **Date:** 2026-10-15
> **Stage:** 0 — planning only. Nothing here is owner-approved. No existing file was edited; no code, build, provider or experiment was run.
> **Scope:** v0.3 focus areas D20 (approval-integrity boundary), D23 (safe Git), D32 (provider lifetime containment) and `04-STATE-TRANSITIONS.md`. Secondary: other v0.3 logic and traceability, and whether `01-R2-DISPOSITION.md` reflects r02 faithfully.
> **Files read in full:** `candidates/claude-stage0-v0.3/` (all 8 files); `reviews/claude-fresh-r02/01-REVIEW.md`; `handoffs/claude-stage0/REVIEWER-HANDOFF.md`; `candidates/claude-stage0-v0.2/02-DECISION-REGISTER.md`, `d04-system-and-process.md`, `d08-security.md`.
> **Files read in part (grep or targeted):** `level-1/03`, `04`, `05`, `07`, `08`, `12`, `13`, `14`; `level-2/proposed/L2-01`, `L2-04`, `L2-05`, `00-MODULE-INDEX`; `candidates/claude-stage0-v0.2/d05`.
> **Labels:** VERIFIED (primary source read today, URL given) · INFERRED · UNVERIFIED · CONTRADICTED · REQUIRES FUTURE EXPERIMENT. I did not measure anything.
> **ID prefix:** `R3-xx`. Evidence: `EV3-xx`. These are local to this review and should be renumbered into the `EV-` namespace if adopted (see `06-ID-CROSSWALK-AND-ERRATA.md` §3).

## 1. Summary verdict

| Focus | Verdict | One-line reason |
| --- | --- | --- |
| **D20** approval-integrity boundary | **REWORK** | Protection is a property of the host and UID, not of a session. The boundary leaves out provider-side approval configuration inside the workspace, which the provider loads itself. It also leaves out inherited capabilities: the SSH agent, TCC grants, and deep links into the signed shell. The server-authentication design does not say where the daemon key lives and uses the SSH host key for the wrong job. |
| **D23** safe Git | **ACCEPT WITH CHANGES** | The direction is right. "Repository-local" is too narrow: it misses user config, include targets, inherited `GIT_*` environment, `core.worktree`/gitdir redirection and symlink reads. The rule should be enforced structurally (no exec allowed in the Git worker), not only by library configuration. LFS needs a built-in path. |
| **D32** provider lifetime containment | **REWORK** (macOS) / ACCEPT WITH CHANGES (Linux) | Process groups and PDEATHSIG do not contain descendants that call `setsid` or that sit below a wrapper process. Those descendants are exactly the long-running tools R2-03 was about. The Linux details (thread-scoped PDEATHSIG, setuid reset, the systemd stop scope) and the interaction with U11 are unaddressed. |
| **04** transition tables | **ACCEPT WITH CHANGES** | The structure is good. One cell family is wrong: `responded_unacked → withdrawn` erases a delivered allow. Several cells let `turn=idle` coexist with live execution. The badge precedence hides all state for unprotected sessions, and the "impossible → notice" rule misclassifies legitimate events. Corrected cells are in §4. |

Counts: **4 BLOCKING · 21 IMPORTANT · 8 MINOR · 1 QUESTION** (34 findings).

**Wrong, not just incomplete:**
- The per-session "approvals not protected" label (R3-01).
- `responded_unacked → withdrawn` on restart, cancel or turn end (R3-20).
- The badge precedence (R3-23).
- The SSH host key as "server authentication" for the remote daemon (R3-06).
- SSH admission ⇒ `full` scope (R3-05).
- The order of the D26 purge procedure (R3-30, VERIFIED against SQLite docs).
- `turn=idle + unknown_after_restart` while the process is `orphan_alive` (R3-21).
- The stated rationale for deferring the MAC (R3-07).

## 2. Evidence gathered this round (access date 2026-10-15)

| ID | Source | Finding | Label |
| --- | --- | --- | --- |
| EV3-01 | <https://man7.org/linux/man-pages/man2/PR_SET_PDEATHSIG.2const.html> | The parent is "the thread that created this process", not the process. The setting is cleared for the child of `fork`, cleared when executing a set-user-ID/set-group-ID binary or a binary with capabilities, and cleared on changes to effective or filesystem UID/GID. If the parent has already terminated before the `prctl`, no signal is sent. | VERIFIED |
| EV3-02 | <https://man7.org/linux/man-pages/man5/systemd.kill.5.html> | Default `KillMode=control-group`. Remaining processes in the unit's cgroup are killed **on unit stop**. `none` leaves them. | VERIFIED |
| EV3-03 | <https://git-scm.com/docs/git-config> | `include.path`/`includeIf` insert other files, and examples use absolute and `~/` paths. Program-valued options in config include `core.fsmonitor` (hook command path), `core.sshCommand`, `core.pager` ("interpreted by the shell"), `core.editor`, `credential.helper` ("if preceded by `!`, shell commands"), `core.askPass`, `core.hooksPath` and `diff.external`. Only some options, such as `safe.directory` and `uploadpack.packObjectsHook`, are honored only in **protected configuration** (system/global/command). `safe.directory` concerns repositories owned by **another** user. `config.worktree` is read when `extensions.worktreeConfig` is set. | VERIFIED |
| EV3-04 | <https://git-scm.com/docs/git> | `GIT_CEILING_DIRECTORIES` limits upward discovery but does not exclude cwd or an explicit `GIT_DIR`. `GIT_DIR`, `GIT_EXTERNAL_DIFF`, `GIT_PAGER`, `GIT_SSH_COMMAND` and `GIT_ASKPASS` each name a path or program to use. `GIT_CONFIG_GLOBAL`/`GIT_CONFIG_SYSTEM` can be `/dev/null`. | VERIFIED |
| EV3-05 | <https://docs.rs/gix/latest/gix/open/permissions/struct.Config.html> | "Configuration inside the repository is always loaded." Separate toggles exist for `system`, `git`, `user`, `env`, `includes` (follow `include`/`includeIf`) and `git_binary` (may execute the git binary; default false). | VERIFIED |
| EV3-06 | <https://docs.rs/gix-filter/latest/gix_filter/pipeline/struct.Options.html> | `drivers: Vec<Driver>` = "Available (external) driver programs to invoke if attributes for path configure them". No separate off switch is documented. An empty list is the only visible control. | VERIFIED (field) / INFERRED (empty list ⇒ no exec) |
| EV3-07 | <https://www.sqlite.org/pragma.html> | `secure_delete`: "enable the secure_delete pragma **prior to** performing the delete … or else run VACUUM". `incremental_vacuum` "has no effect if the database is not in auto_vacuum=incremental mode". Changing from `none` requires VACUUM. | VERIFIED |
| EV3-08 | <https://agentclientprotocol.com/protocol/prompt-turn> | The client MUST answer all pending `session/request_permission` with `cancelled` when it cancels. The client should accept tool-call updates after `session/cancel`. The agent sends remaining updates **before** responding to `session/prompt` with stop reason `cancelled`. Stop reasons: `end_turn`, `max_tokens`, `max_turn_requests`, `refusal`, `cancelled`. | VERIFIED |
| EV3-09 | <https://learn.chatgpt.com/docs/app-server> | `thread/backgroundTerminals/list` returns `osPid`, `command`, `cwd`, and `thread/backgroundTerminals/terminate` exists, so long-lived processes outlive tool calls. Multiple threads can be loaded in one app-server process (`thread/loaded/list`). | VERIFIED (existence) / INFERRED (they outlive turns and use separate process groups) |
| EV3-10 | <https://learn.chatgpt.com/docs/llms-full.txt> (redirect from developers.openai.com/codex/llms-full.txt) | In `workspace-write`: "`<writable_root>/.git` is protected as read-only whether it appears as a directory or file". "`<writable_root>/.codex` is protected as read-only **when it exists as a directory**" (same for `.agents`). "Project-local rules under `<repo>/.codex/rules/` load only when the project `.codex/` layer is trusted." | VERIFIED |

## 3. Findings

Severity: BLOCKING (resolve before Level 2 detail of the affected module) · IMPORTANT · MINOR · QUESTION.

### D20 — approval-integrity boundary

#### R3-01 — Protection is a host/UID property; a per-session label is wrong (BLOCKING · security/logic)
- **Location:** `02-DECISION-REGISTER-v0.3.md` D20 ("approval guarantee holds for a session only if…", "Sessions that do not meet the boundary show…"); `03-REGISTER-UPDATES.md` N10 ("stated per session"); `04-STATE-TRANSITIONS.md` §6 badge; `90-CONSISTENCY-v0.3.md` C-22.
- **Problem:** the asset D20 protects is shared. There is one data directory, one socket, one set of binaries and one approval engine per host and UID. An agent that breaks the boundary in **any** session can tamper with the state of **every** session. So "protected" cannot be a per-session property.
- **Failure sequence:**
  1. Session A (Codex, `workspace-write`, boundary holds) shows no warning.
  2. The user starts session B (Hermes, no OS sandbox), sees "approvals not protected", and acknowledges.
  3. B's agent writes to `~/Library/Application Support/Shardrail/` and flips trust or policy rows for A's workspace. Or it plants a LaunchAgent that does so later.
  4. A's approvals are no longer trustworthy, but A still shows no warning.

  The same happens when the user's own unsandboxed agent runs in a terminal outside Shardrail, or when the user approves one out-of-sandbox command (R3-04).
- **Second problem:** the label is computed by the daemon from state that, once the boundary has been breached anywhere, is itself tamperable. The indicator cannot vouch for itself.
- **Evidence:** INFERRED from POSIX same-UID semantics and D20's own asset list.
- **Recommended change:**
  - Restate D20 as a **host-level protection state**: `protected` only while every live Shardrail-launched process on that host and UID runs under a boundary-satisfying profile, and none has been granted an out-of-sandbox action since the state was last established.
  - Once lost, the state stays lost (sticky) until an explicit user "re-establish" action, which at minimum restarts the daemon and verifies binaries and data-directory integrity. A MAC can help here (R3-07).
  - Say in UI and docs that processes outside Shardrail (the user's own terminals, IDEs, other agents) are outside the claim.
  - Keep the per-session marker only as the *cause* ("this session makes the host unprotected").
- **Affected:** D20, N10, R15, R31, C-22, `04` §6, L2-04 §5.

#### R3-02 — The boundary omits provider-side approval configuration, which bypasses Shardrail entirely (BLOCKING · security)
- **Location:** D20 items (a)–(c); `03` F13 (Claude gating applies only in `unknown`/`restricted`); baseline `level-1/05` (Hermes `allow_always` writes a permanent allowlist); `level-1/03` line 84 (Hermes installed as a git checkout in `~/.hermes/hermes-agent`).
- **Problem:** D20 guards Shardrail's state. But approval requests originate in the **provider**. A provider configured to auto-approve never asks, so Shardrail sees no request and its guarantee holds vacuously. Paths that change provider approval behavior and that a "protected" `workspace-write` agent can plausibly reach:
  - **Codex project layer.** `.codex/` is protected only **when it exists as a directory** (EV3-10, VERIFIED). In a trusted project without `.codex/`, the agent can create `.codex/rules/*` (INFERRED from EV3-10). Project rules load only when the project layer is trusted, and trusted workspaces are where this matters.
  - **Claude project settings.** `.claude/settings.json` / `settings.local.json` inside the workspace (permission allow rules, hooks) are loaded in trusted workspaces (r02 EV-15). Whether Claude's sandbox write-protects them is UNVERIFIED.
  - **User-level config** (`~/.codex/config.toml`, `~/.claude/settings.json`, `~/.hermes/config.yaml` allowlist and `approvals` mode, Grok config). This is outside the workspace and so denied by a strict sandbox, but writable by any unsandboxed session (which leads back to R3-01).
  - **Provider install trees.** D20(b) says "binaries", but Hermes is Python source plus a venv under `~/.hermes` (baseline). Codex is an npm wrapper (Node script) that launches a native binary. Homebrew prefixes on Apple Silicon are user-owned. "Modify binaries" must mean "modify any file the provider's interpreter loads". Code-signing identity does not exist for most of these.
- **Failure sequence:**
  1. A trusted Codex workspace has no `.codex/`.
  2. During turn 1 the agent writes `.codex/rules/allow.rules`, which is allowed because the path does not exist as a protected directory.
  3. In turn 2 or the next session, Codex loads the project rules and runs commands without raising `requestApproval`.
  4. Shardrail shows "protected" with no pending approvals.
- **Evidence:** EV3-10 VERIFIED (protection condition and rules loading). Rule-file effect on approvals: INFERRED. Claude settings protection: UNVERIFIED.
- **Recommended change:**
  - Add (d): *the agent cannot write any file the provider reads to decide whether to ask for approval or what to run*, at user and project level. List these per provider in S7.
  - Shardrail should **pin approval-relevant settings at launch** through documented command-line or SDK overrides (Codex `-c` overrides for approval policy and sandbox; Claude `settingSources`/permission mode in **all** trust states for approval-relevant keys; Hermes per S7).
  - Snapshot and change-flag the provider's approval-relevant files at session start and end.
  - Treat a provider whose approval config cannot be pinned as making the host unprotected.
  - Pre-create a protected `.codex/` directory? That writes into the workspace, so it is an owner question.
  - Extend D20(b) to "provider install tree and interpreter".
- **Affected:** D20, F13, R15, R31, S7, L2-03 §3, L2-04 §5.

#### R3-03 — Deferred-execution (persistence) paths are not covered (IMPORTANT · security)
- **Location:** D20 (a)–(c).
- **Problem:** (a)–(c) are necessary but not sufficient. Any write that causes **later unsandboxed execution as the user** lets the agent reach (a)–(c) afterwards: `~/Library/LaunchAgents/*.plist`, shell rc files and `PATH` directories, `~/.ssh/config` (`ProxyCommand`/`LocalCommand`/`Match exec`, which run on the desktop when the shell launches `ssh … bridge`), `~/.gitconfig`, crontab, `/Applications/Shardrail.app` when drag-installed (user-owned), Tauri/WebKit storage (`~/Library/WebKit/<bundle-id>`, preferences plist), editor/IDE task files. Inside the workspace, `.git/hooks` (Codex protects `.git`, EV3-10), `.envrc`, `.vscode/tasks.json` and `package.json` scripts run when the *user* later works unsandboxed. Shardrail cannot prevent the workspace cases, but it must not claim more than it can.
- **Evidence:** INFERRED.
- **Recommended change:** state the boundary as "no writes outside the session's writable roots and temp, and no writes to the provider-config paths of R3-02". Add a sentence on time scope: the guarantee covers Shardrail's approval decisions while the host state is `protected`. It does not cover code the user later runs from the workspace. S7 must test LaunchAgents, rc files, `~/.ssh/config` and the app bundle as well as the data directory.
- **Affected:** D20, S7, R31, d08 TB table.

#### R3-04 — Approved out-of-sandbox actions silently break the boundary (IMPORTANT · security)
- **Location:** D19 card contract; D20; `03` R31.
- **Problem:** Codex can ask to run a command with escalated or no sandbox. `thread/shellCommand` runs outside the sandbox (r02 EV-13). Hermes may have no OS sandbox. An *approved* escalated command can do everything in R3-01 to R3-03, and the card does not tell the user that approving it ends approval protection for the host.
- **Evidence:** r02 EV-13 VERIFIED for `thread/shellCommand`. Escalation request fields per provider: REQUIRES FUTURE EXPERIMENT (S1).
- **Recommended change:** classify approvals that run outside the session's sandbox as a third option class, `boundary-breaking`: `full` scope only, an explicit consequence line on the card, and the host state moves to `unprotected` (sticky, R3-01). `untested-newer` hides them, as it does `widening`.
- **Affected:** D19.1, D20, D24.2, L2-04 §4.

#### R3-05 — Inherited capabilities: SSH agent, TCC grants, deep links, keychain prompts, debugging (IMPORTANT · security)
- **Location:** D20 defense-in-depth list; D21 ("SSH-bridged desktop admitted by SSH authentication"; local admission by code-signing identity); D11/R23 (TCC attributed to Shardrail.app); v0.2 D2 (shell owns deep links).
- **Problem:** five paths are not covered by (a)–(c).
  1. **SSH agent.** Environment scrubbing removes `SHARDRAIL_*` but not `SSH_AUTH_SOCK`. A local agent can `ssh remote shardraild bridge` with the user's agent keys and becomes a `full` client of the remote daemon (D21 SSH = full). It can then send `widening` approvals on remote sessions. *Sequence:* local Hermes session (acknowledged unprotected) → `ssh build-box shardraild bridge` → speaks the wire protocol → answers a pending remote approval with `acceptForSession`.
  2. **TCC.** Providers are descendants of Shardrail.app, so TCC attributes their requests to the app (R23). If the user ever grants Shardrail Accessibility or Automation (an agent can trigger the prompt), every agent inherits the ability to drive the approval UI with synthetic AX events, and Screen Recording exposes pairing codes.
  3. **Deep links.** The signed shell is a confused deputy. `open 'shardrail://…'` from an agent reaches a `full`-scope client. The code-signing peer check in D21 is satisfied by the real shell.
  4. **Keychain prompts.** Same-user access to keychain items produces user-facing prompts an agent can trigger to phish an "Always Allow".
  5. **Debugging and signals.** On Linux, `ptrace` of the daemon depends on Yama `ptrace_scope` and the sandbox. On macOS, the hardened runtime blocks `task_for_pid` without an entitlement. Same-UID `kill` can stop the daemon or the D32 helper.
- **Evidence:** INFERRED throughout. TCC attribution is already INFERRED in v0.2 R23. All of it REQUIRES FUTURE EXPERIMENT in S7.
- **Recommended change:**
  - Scrub `SSH_AUTH_SOCK` (and GPG agent sockets) from provider environments by default, with an explicit per-session opt-in that marks the host unprotected.
  - Do not let SSH admission grant `widening` or policy actions without a second factor held by the desktop shell (keychain key), so SSH alone gives at most `limited`. Alternatively, accept and document that any holder of the user's SSH keys can approve.
  - Deep links must never carry approval, policy or pairing actions.
  - Investigate spawning providers so they are not attributed to Shardrail.app for TCC (launchd job or "responsible process" disclaim; REQUIRES FUTURE EXPERIMENT). Until then, document that granting Shardrail Accessibility, Automation or Screen Recording voids the boundary.
  - Ship with hardened runtime and no `get-task-allow`. Check `ptrace_scope` on Linux and show it.
- **Affected:** D20, D21, D11, R23, S7, L2-05 §4.

#### R3-06 — Server authentication and challenge-response are under-specified and partly misplaced (IMPORTANT · security)
- **Location:** D20 defense in depth ("client verifies daemon key pinned at first admission; SSH host key for remote"); D21 ("Proof is challenge-response"); N4.
- **Problem:**
  - D20 denies agents **write** to the data directory, not **read**. If the daemon's private key or a symmetric challenge-response secret lives there, a "protected" agent can read it. With a symmetric scheme, reading the verifier is enough to answer challenges.
  - "SSH host key for remote" authenticates the **host**, not the daemon behind the remote socket. A remote same-UID process that binds the socket while the daemon is down is reached through a perfectly authenticated SSH channel.
  - Bare challenge-response without channel binding can be relayed by an impostor that sits on the socket path.
- **Evidence:** INFERRED.
- **Recommended change:**
  - Asymmetric client proof: the daemon stores public keys only.
  - Keep the daemon's identity key in the macOS keychain. On Linux, accept that it is readable by the same UID, which reinforces U11.
  - The remote daemon key is pinned end to end through the bridge, in addition to SSH.
  - Use a mutually authenticated handshake bound to the transcript (e.g., a Noise-pattern handshake) rather than ad hoc challenge-response.
  - Add "read of the data directory" to S7 so the claim is explicit.
- **Affected:** D20, D21, N4, L2-05 §3–§5.

#### R3-07 — MAC deferral: acceptable, but for a different reason than stated (MINOR · evidence/logic)
- **Location:** `01-R2-DISPOSITION.md` R2-01; D20 "Deferred to Phase 2".
- **Problem:** the stated reason ("does not close the same-UID gap on Linux") undersells the MAC on macOS. A hardened-runtime daemon plus a keychain item bound to the app's designated requirement is the **only** proposed control that still protects state rows against an *unsandboxed* same-UID agent on macOS, which is the likely common case if S7 is negative (C-22). Deferral is still justified, because R3-02 lets an agent bypass approvals without touching Shardrail rows, so the MAC would not restore the guarantee. A MAC also does not stop rollback (copying an older DB back), unless it includes a monotonic counter stored in the keychain.
- **Recommended change:** restate the rationale. Keep the Phase 2 deferral. Specify a counter for rollback when it is built. Consider the MAC as the mechanism for "re-establish protection" in R3-01.
- **Affected:** D20, `01` R2-01 row.

#### R3-08 — Acknowledgement as the product response risks habituation; the decision rule is not pre-registered (IMPORTANT · product)
- **Location:** D20 ("start only after an explicit acknowledgement"); C-22 ("owner must accept the claim scope after S7").
- **Problem:** if S7 shows most profiles are unprotected (and Hermes likely always is), almost every session start needs an acknowledgement. Users click through it, and the label carries no information, the same failure as allow-all prompts. C-22 leaves the decision for after S7 without criteria, which invites rationalizing whatever S7 shows.
- **Recommended change:** pre-register the decision before S7:
  - If fewer than N of the P1a providers can reach `protected`, the product does **not** market protected approvals. The label becomes a host-level banner with a one-time acknowledgement per host and provider, not per session.
  - U11 (separate UID) becomes the recommended path on macOS too, if feasible.
  - Record this as an owner question.
- **Affected:** D20, C-22, U11, S7.

### D23 — safe Git

#### R3-09 — "Repository-local" is too narrow; config, environment and discovery need isolation (IMPORTANT · security)
- **Location:** D23 rule; S8 fixture list; `05` E1.9.
- **Problem:** programs can be named by:
  - user-level config (`~/.gitconfig`, `$XDG_CONFIG_HOME/git/config`), which is writable by any unsandboxed agent (R3-01) and not "repository-local";
  - files pulled in by `include`/`includeIf` from repository config, which can point anywhere (EV3-03);
  - `config.worktree` (EV3-03);
  - the daemon's **inherited environment** (`GIT_DIR`, `GIT_EXTERNAL_DIFF`, `GIT_CONFIG_PARAMETERS`, `GIT_SSH_COMMAND`, `GIT_PAGER`, `GIT_ASKPASS`; EV3-04), for example when the daemon is started from a developer's terminal or from systemd `environment.d`.

  Separately, repository **discovery** can escape the workspace: upward discovery into a parent repository (`GIT_CEILING_DIRECTORIES` does not exclude cwd or explicit `GIT_DIR`, EV3-04); a `.git` *file* (`gitdir:`) or `core.worktree` pointing outside the workspace; submodules whose `.git` files point elsewhere. Symlinks in the worktree pointing to `~/.ssh/id_ed25519` would be read and shown in the tree or diff view, possibly to a `limited` remote client. Hardlinks cannot be detected by path at all. gix always loads repository config (EV3-05), so it is Shardrail's job to make sure nothing in that config is acted on.
- **Evidence:** EV3-03, EV3-04, EV3-05 VERIFIED. Exposure paths INFERRED.
- **Recommended change:** restate the rule as: *Shardrail executes no program named by any Git configuration scope, attribute, or environment variable, and performs only local read operations (no fetch, push, commit, credential or editor paths).* Then specify:
  - open with gix permissions `system=false, git=false, user=false, env=false, includes=false, git_binary=false`;
  - strip `GIT_*` from the daemon's own environment at startup;
  - bound discovery to the workspace root, with no upward discovery;
  - reject or flag a gitdir or `core.worktree` outside the workspace;
  - do not follow symlinks out of the workspace in tree and diff views (show the link target as text);
  - flag `nlink > 1` files;
  - do not recurse into submodules in P1.
- **Affected:** D23, F8, R18, S8, M11, L2 workspace.

#### R3-10 — "Content check skipped (filter)" is wrong UX for Git LFS and must never become "modified" (IMPORTANT · product/logic)
- **Location:** D23 ("Files whose comparison would require a filter show 'content check skipped (filter)'").
- **Problem:** LFS is the most common filter (`filter=lfs` in `.gitattributes`). In an LFS repository, every large asset (very common in game and media repositories) would show "skipped", or, if the implementation compares unfiltered bytes, show as **modified**. That is a false diff that drives wrong decisions, such as discarding work or blaming an agent. Racy-clean index entries and stat-dirty-only files have the same issue.
- **Evidence:** INFERRED. gix filter behavior with an empty driver list: INFERRED (EV3-06).
- **Recommended change:**
  - Implement the LFS *clean* direction natively. It is a pure function: SHA-256 and size into a pointer file, with no program executed. Use it to compare LFS paths.
  - For other filters, fall back to stat-only status and mark the entry "unverified". Never report "modified" from an unfiltered comparison.
  - Built-in conversions (eol, `ident`, `working-tree-encoding`) are handled natively by gix and are not "programs".
  - Add an LFS fixture to S8.
- **Affected:** D23, S8, F8.

#### R3-11 — Enforce "no exec" structurally; the library alone is a moving target (IMPORTANT · security)
- **Location:** D23 ("Library-based … with fsmonitor, hooks, filter drivers … disabled"; "No hardened-CLI fallback").
- **Problem:** gix exposes external drivers as configuration (EV3-06) and grows features over time. A future gix release or an overlooked call path (`git_binary`, an fsmonitor implementation, a credential path) could spawn a process. D23 currently relies on reviewing the library configuration.
- **Recommended change:**
  - Run Git computations in a **worker process with exec denied by the OS**: Seatbelt `(deny process-exec)` on macOS, and seccomp denying `execve`/`execveat` or Landlock on Linux. It should be read-only to the workspace and have no network.
  - Add a CI test that runs the S8 fixtures and fails if any `execve` occurs.
  - This also limits the damage of a parser bug in the library.
  - Library realism: gix status, diff and worktree coverage is still REQUIRES FUTURE EXPERIMENT (S8). Worktree creation for D31 is not needed if provider-native worktrees are used.
- **Affected:** D23, S8, M11, B-budgets (one extra process; measure).

### D32 — provider lifetime containment

#### R3-12 — Process groups do not contain the processes that matter; the macOS mechanism cannot meet the requirement as stated (BLOCKING · logic)
- **Location:** D32 ("enumerate recorded groups"; macOS "helper … terminates the group"; Linux "parent-death signal … plus cgroup-based kill"); `03` F20; `05` T1.3.1.
- **Problem:** R2-03 was about long-running tools (a build, `rm`, `git push`) that outlive the daemon. Those are exactly the processes most likely **not** to be in the provider's process group:
  - shells and tool runners commonly `setsid`/`setpgid` for job control;
  - Codex has persistent **background terminals** with their own OS pids (EV3-09);
  - dev servers, `nohup`, `tmux`, `docker` all detach.

  `killpg` misses all of them. PDEATHSIG reaches only the **direct** child. Codex's npm wrapper (Node → native binary) and the Claude ACP adapter (Node → `claude` CLI) are multi-level, so the real agent is a grandchild.

  On macOS there is no unprivileged equivalent of a cgroup. Descendant tracking by polling is racy, and Endpoint Security needs an entitlement. So "survivors become `orphan_alive`" will report "no survivors" while a detached build keeps running.
- **Failure sequence (macOS):**
  1. The agent starts `npm run build` through a tool that `setsid`s.
  2. The daemon crashes.
  3. The helper sees EOF and kills the recorded pgid (the provider dies).
  4. The build continues in its own session.
  5. On restart, the daemon enumerates the recorded group, finds it empty, and marks the session `exited`, with no `orphan_alive`.
  6. The D31 write lease is released (R3-17) and a second session starts writing while the build still writes.
- **Evidence:** EV3-01 VERIFIED (direct child only, by construction of `prctl`). EV3-09 VERIFIED (background terminals exist). `setsid` behavior of each provider's tool runner: REQUIRES FUTURE EXPERIMENT.
- **Recommended change:**
  - Fix the requirement's **unit of containment** as "all descendants, including those that changed session or group". State per OS what can be guaranteed:
    - **Linux:** one cgroup per provider (systemd transient scope via `systemd-run --user --scope`, or a delegated subtree), killed with `cgroup.kill`. This is a real guarantee.
    - **macOS:** best effort. The helper tracks descendants (kqueue `EVFILT_PROC` on known pids, periodic `proc_listchildpids` sweep at B9-compatible intervals) and records every pid with its start time. Residual risk is stated in the UI.
  - Ask the providers through their protocol to terminate background processes on cancel (Codex `thread/backgroundTerminals/terminate`).
  - S1–S4 must include "tool that detaches", not only "kill daemon, observe provider".
- **Affected:** D32, F20, R26, S1–S4, T1.3.1, L2-01, C-23.

#### R3-13 — PR_SET_PDEATHSIG semantics are mis-assumed (IMPORTANT · logic)
- **Location:** D32 Linux ("parent-death signal set before exec").
- **Problem (EV3-01, VERIFIED):**
  1. The "parent" is the **thread** that forked. A Rust daemon that spawns from a Tokio worker or `spawn_blocking` thread will have healthy providers killed when the runtime retires that thread.
  2. The setting is cleared on exec of setuid/setgid/capability binaries and on credential changes, so `sudo -u agent …` (U11) silently drops it.
  3. If the parent died before `prctl`, no signal is ever sent. The child must check `getppid()` after `prctl`.
- **Recommended change:** spawn all providers from one dedicated, never-exiting spawner thread (or a spawner process). Re-check the parent after `prctl`. Do not rely on PDEATHSIG under U11. Make the cgroup (R3-12) the primary mechanism and PDEATHSIG secondary.
- **Affected:** D32, L2-01 §3.

#### R3-14 — systemd cleanup scope, linger, and selective termination (IMPORTANT · logic)
- **Location:** D32 ("cgroup-based kill in the systemd unit"); baseline §6.2 (systemd user service); D25 bridge.
- **Problem:**
  - `KillMode=control-group` kills remaining processes **on unit stop** (EV3-02). With `Restart=`, this happens between crash and restart (INFERRED), so on Linux `orphan_alive` will normally never be observed. Outcomes must then be recorded as `killed_by_restart`, not `unknown`.
  - A daemon started outside the unit (developer run; a `bridge` that auto-starts a daemon) has no such cleanup.
  - A user manager without `loginctl enable-linger` stops at logout and kills all sessions, which conflicts with Phase 2 "sessions survive" on remote hosts.
  - One unit-wide cgroup cannot terminate **one** provider (cancel escalation, `04` §1) without per-provider sub-cgroups (`Delegate=yes`).
- **Recommended change:**
  - Per-provider sub-cgroups.
  - The daemon refuses to start providers when it is not in a cgroup it controls, or it marks containment `best effort`.
  - Linger check and a warning in remote host setup.
  - Add a turn outcome for "killed by daemon restart".
- **Affected:** D32, D11, M16, `04` §1/§3.

#### R3-15 — pid/start-time identity, TOCTOU and the spawn-before-journal window (IMPORTANT · logic)
- **Location:** D32 ("Durable `provider_spawned` event: pid, pgid, process start time"); `04` §1.
- **Problem:**
  1. Linux start time in `/proc/<pid>/stat` counts clock ticks since boot, so the record also needs a **boot id** (`/proc/sys/kernel/random/boot_id`; macOS `kern.boottime`). Otherwise a post-reboot pid can match.
  2. Check-then-`kill` is racy. Linux has `pidfd_open` and `pidfd_send_signal`; macOS has no pidfd, so the window can only be narrowed.
  3. After the leader exits, a pgid can persist with other members. Verifying their identity needs per-member records, not just the leader's start time.
  4. `provider_spawned` is journaled **after** spawn. A crash between `fork/exec` and the commit leaves an untracked process.
- **Recommended change:**
  - Record `boot_id`.
  - Use pidfds on Linux.
  - Journal `provider_spawn_intent` before spawn.
  - On macOS, start the helper first so that an unrecorded provider still dies with the helper's pipe.
  - Record descendant pids as the helper observes them.
- **Affected:** D32, L2-01, `04` §1.

#### R3-16 — D32 and U11 (separate agent UID) are mutually unspecified (IMPORTANT · logic)
- **Location:** D32; `03` U11 (now "default yes on remote hosts"); D20.
- **Problem:** a daemon or helper running as the user cannot signal processes owned by the agent UID (`EPERM`). The `04` §1 escalation (SIGTERM, then SIGKILL to the group) fails. PDEATHSIG is cleared by the setuid exec (R3-13). Shardrail's Git view may hit "dubious ownership" semantics if repositories are owned by the agent user (EV3-03; gix applies reduced trust). Adding `safe.directory` globally would change the user's own Git behavior.
- **Recommended change:** before U11 becomes a default, specify the mechanism. One option is a small privileged helper, or a system-level systemd unit for the agent user, that spawns, contains (cgroup) and kills on the daemon's behalf, and authenticates the daemon. Repository ownership and the Git trust interaction must be specified too. Until then, U11 is "recommended, mechanism TBD".
- **Affected:** U11, D32, D23, D20, M16.

#### R3-17 — "Terminate" mid-operation, and the write lease after restart (IMPORTANT · logic)
- **Location:** D32 ("UI offers 'terminate'"); D31 ("lease is released at session close or by explicit transfer"); `04` §1 escalation.
- **Problem:**
  - SIGKILL mid-tool leaves partial writes, `.git/index.lock`, half-applied migrations and completed **remote** side effects (a push, deployment or API call). Nothing records that a tool was killed mid-flight or tells the user the workspace may be inconsistent.
  - D31's lease is not defined as durable. After a daemon restart (sessions idle, `unknown_after_restart`), nothing prevents a new session from taking the lease while an `orphan_alive` process, or an uncontained descendant (R3-12), still writes.
  - Codex background terminals (EV3-09) keep running after the turn ends and after lease transfer.
- **Recommended change:**
  - Make the lease a journaled record.
  - The lease holder is released only when the process dimension is `exited` **and** no tracked descendant is alive.
  - `orphan_alive` holds the lease.
  - Termination of a turn with open tool calls yields `outcome=killed_mid_tool`, a workspace notice (lock files present, diff since turn start), and no automatic cleanup.
  - Lease transfer requires terminating or confirming background processes.
- **Affected:** D31, D32, F19, F20, `04` §1/§3.

#### R3-18 — macOS helper failure modes (MINOR · logic)
- **Location:** D32 macOS; C-23.
- **Problem:** the helper's own failure modes are not considered:
  - The helper can crash, be OOM-killed, or be killed by the same-UID agent, and then there is no containment. Containment is crash safety, not an adversarial control, and should say so.
  - Is the helper the provider's parent? If so, the recorded pid and pgid are the helper's, and stdio passes through it or is handed off.
  - Version skew after an app update with an orphan daemon still running.
  - Does the helper kill immediately on EOF, or apply `T_grace`?
- **Recommended change:** specify topology (helper as parent, stdio passthrough or fd handoff), the kill policy on EOF (immediate SIGTERM to all tracked descendants, then SIGKILL after 5 s), and the helper's behavior when the provider exits first (exit and report). State the non-adversarial scope.
- **Affected:** D32, C-23, L2-01.

#### R3-19 — U18 orphan-daemon cancellation contradicts the approval table (MINOR · consistency)
- **Location:** D11/U18 ("cancel turns (pending approvals expire per D19 and are never allowed)"); `04` §4 ("turn cancelled → `withdrawn`").
- **Problem:** under U18, cancellation produces `withdrawn`, not `expired`. Also, after an app update, a new shell connecting to an old orphan daemon needs a version-skew rule.
- **Recommended change:** pick one name (prefer `withdrawn(orphan_timeout)`). Add "shell/daemon version mismatch → offer restart (with D32 termination semantics)".
- **Affected:** D11, U18, `04` §4.

### Transition tables (`04-STATE-TRANSITIONS.md`)

#### R3-20 — `responded_unacked → withdrawn` erases a delivered allow (BLOCKING · logic/security)
- **Location:** `04` §4 row `responded_unacked`, columns "provider withdraws (… turn end …)", "turn cancelled", "daemon restart"; D19.2.
- **Problem:** once Shardrail has written the response to the provider, the decision **has been delivered**. Withdrawal semantics belong to `pending` only.
- **Failure sequence:**
  1. The user taps Allow for `git push --force`. The CAS succeeds and the record is `responded_unacked`.
  2. The daemon writes the response.
  3. The daemon crashes before the next provider event.
  4. The provider (an orphan, R3-12) executes the push.
  5. On restart, the record becomes `withdrawn(daemon_restart)` and the transcript shows the approval as withdrawn.

  The user believes nothing ran. This is the R29 failure ("user believes … took effect / did not") in reverse.
- **Second failure:** a **deny** answered to an ACP agent that emits no further `tool_call_update` for that call, followed by a normal turn end, becomes `withdrawn` instead of `denied`.
- **Evidence:** INFERRED from the table. ACP update behavior after deny: REQUIRES FUTURE EXPERIMENT (S2/S3).
- **Recommended change:**
  - From `responded_unacked`, the events turn end, turn cancelled, process exit and daemon restart → `delivered_unconfirmed(<allow|deny>)` (terminal). Show it as "Allowed, outcome not confirmed".
  - Only a JSON-RPC error on the response → `withdrawn`.
  - Provider acknowledgement → `allowed`/`denied`.
  - Define acknowledgement per provider: Codex `serverRequest/resolved`; ACP a `tool_call_update` for the same `toolCallId`, or the next `session/prompt` response.
- **Affected:** `04` §4, D19.2, R29, L2-04 §3/§7.

#### R3-21 — `turn=idle` can coexist with live execution (IMPORTANT · logic)
- **Location:** `04` §3 "On daemon restart every non-`idle` turn becomes `idle` + `unknown_after_restart`"; column "process exits / link `desynced`"; row `cancelling` → `idle + cancelled_by_termination`.
- **Problem:** the invariant "`idle` ⇒ nothing executing on behalf of this session" is violated in four ways:
  - restart while the process is `orphan_alive` → turn `idle`;
  - link `desynced` while the process is still alive (bad frame) → turn `idle + interrupted` while the provider keeps running approved tools;
  - `cancelling` + link `desynced` → `cancelled_by_termination` although nothing was terminated;
  - Codex background terminals after `turn finished`.
- **Recommended change:**
  - Add turn state `detached` (execution may continue, Shardrail has no channel), entered from any non-idle turn when the link desyncs with the process alive, or on restart with the process `orphan_alive`. `detached` + process `exited` → `idle` + `unknown_after_restart`/`interrupted`.
  - Link `desynced` with the process alive triggers automatic `terminate requested` after `T_grace`, or at least a top-priority badge.
  - `cancelled_by_termination` only on an actual process exit.
- **Affected:** `04` §1–§3, §6, D18.

#### R3-22 — The "impossible → notice" rule misclassifies three kinds of events (IMPORTANT · logic)
- **Location:** `04` header rule; §3 row `idle` × "any provider event"; §1 `terminating` × "terminate requested"; §3 `cancelling` × "cancel requested".
- **Problem:** unlisted cells are of three kinds.
  1. **Legitimate out-of-turn events.** ACP `session/update` such as available commands or mode changes; Codex thread-level notifications; replay during `resuming` (which D33 discards); late updates after cancel. ACP says the client "should still accept tool call updates" after cancel (EV3-08). An approval request arriving while the turn is `idle` is a contradiction that needs a rule.
  2. **Idempotent repeats** (double cancel, double terminate), which D30 `command_id` already dedupes.
  3. **True impossibilities.**

  Treating 1 and 2 as notices floods the notice stream, trains users to ignore it, and makes T1.5.3 conformance tests assert the wrong behavior.
- **Recommended change:** the table header defines three cell kinds: `→ state`, `ignore (idempotent)`, `route to session-level handler` (non-turn updates), and `impossible → notice` only for the rest. Rule for an approval request while the turn is `idle`: refuse immediately (D24 refusal) plus a notice.
- **Affected:** `04` all, `05` T1.5.3.

#### R3-23 — Badge precedence hides all state for unprotected sessions; normal exit shows as degraded (IMPORTANT · UX/logic)
- **Location:** `04` §6.
- **Problem:**
  - `approvals not protected` is a **persistent** condition placed **above** `degraded`, `delivery unknown`, `resuming`, `stalled`, `cancelling` and `running`. A single-badge precedence then means an unprotected session (possibly most sessions, C-22) **always** shows "approvals not protected" and never "running" or "delivery unknown".
  - `degraded` is defined as process `exited`, which is the normal state of an idle process-per-session session after a clean exit.
  - There is no badge for `terminating`, kill failure, `responded_unacked`/`delivered_unconfirmed`, or `detached`.
- **Recommended change:**
  - Make protection a host-level overlay (R3-01), never part of the precedence.
  - `degraded` = `exited(abnormal)` or `desynced`.
  - Precedence: `orphan/detached` > `needs approval` > `approval outcome unconfirmed` > `degraded` > `delivery unknown` > `terminating` > `resuming` > `stalled` > `cancelling` > `running` > `idle`.
- **Affected:** `04` §6, d10.

#### R3-24 — Approval events are mis-anchored and lack timers (IMPORTANT · logic)
- **Location:** `04` §4; D19.2–D19.4.
- **Problem:**
  - ACP requires answering pending permission requests with `cancelled` when the client **sends** cancel (EV3-08), so the cell must hang on turn `cancel requested`, not "turn cancelled".
  - `responded_unacked` has no timer. A provider that never emits another event for the tool call leaves the record stuck, and C-02 exempts only `pending` from stall.
  - Columns for process exit and link desync are missing (they appear only implicitly through "turn end").
  - `responded_unacked` × "authorized response" says "rejected (typed error, final state)", but the state is not final.
  - What "workspace changed" means and how it is detected (HEAD and diff through D23, which may skip filtered files, R3-10) is unstated.
  - Option classes other than those listed (new provider option kinds) have no classification rule (R3-31).
- **Recommended change:** see §4 corrected cells. Add `T_ack` (PROPOSED 60 s; on expiry → `delivered_unconfirmed` plus a notice). Workspace change = HEAD moved or tracked diff hash changed, computed by D23 with "unverified" entries counting as changed.
- **Affected:** `04` §4, D19.

#### R3-25 — Process table gaps: lost pids, kill failure, leader-vs-group, overlapping columns, shared processes (IMPORTANT · logic)
- **Location:** `04` §1; D8 (shared per-provider topology); escalation note.
- **Problem:**
  1. There is no event "daemon restart finds recorded pid **dead**", which should give `exited(lost)`.
  2. Columns "terminate requested" and "orphan exits / user terminates" both apply to `orphan_alive` with different targets.
  3. Escalation for an orphan starts with "protocol cancel", but no link exists.
  4. `terminating` has no exit if SIGKILL fails (`EPERM` under U11, an uninterruptible process, a stuck zombie), so add `T_kill`.
  5. "exit / stdio EOF" for the leader is treated as the process's exit while group members or descendants remain (R3-12).
  6. With D8 shared processes (one Codex app-server hosting several threads, EV3-09), the `cancelling` + `T_cancel` → terminate escalation kills **other sessions'** turns.
- **Recommended change:**
  - Add `exited(lost)`.
  - Merge the overlapping columns.
  - Orphan escalation skips the protocol step.
  - Add `T_kill` (PROPOSED 10 s) → `kill_failed` (sticky, notice, badge).
  - Split `exited` into `leader_exited` (descendants alive) and `exited`.
  - Escalating to process termination on a shared process requires user confirmation listing the affected sessions. Otherwise the turn stays `cancelling` with a notice.
- **Affected:** `04` §1, §3; D8; D32.

#### R3-26 — Link table: no resume timeout, no dispatch guard, unspecified restart state (IMPORTANT · logic)
- **Location:** `04` §2, §3.
- **Problem:**
  - `resuming` has no `T_resume`. A `session/load` that hangs leaves the session "resuming" forever.
  - Turn `idle` + "prompt dispatched" → `running` is not guarded on link `ready` and process `alive` (cross-dimension invariant missing).
  - The link state after daemon restart is unstated (it should be `none`).
  - "unknown response id → `desynced`" turns a late response after a local request timeout into a full desync.
- **Recommended change:**
  - Add `T_resume` → `desynced`.
  - State the invariant "prompt dispatch requires link=`ready` ∧ process=`alive` ∧ no `orphan_alive` ∧ write lease if write-capable".
  - On restart, link = `none`.
  - Keep a short tombstone set of timed-out request ids so a late response becomes a notice, not a desync.
- **Affected:** `04` §2–§3.

#### R3-27 — Delivery table: missing failure and in-flight-loss events; unsafe resend (IMPORTANT · logic)
- **Location:** `04` §5; D30.
- **Problem:**
  - There is no event for the provider **rejecting** a command (JSON-RPC error, `expectedTurnId` mismatch) or for process exit or link desync while `dispatched`. Only daemon restart reaches `unknown`.
  - "user: resend" is allowed while the old process is `orphan_alive`, which could deliver a prompt twice.
  - An approval response is itself a mutating command, so delivery and approval acknowledgement track the same thing twice with no stated relationship.
- **Recommended change:**
  - Add `dispatched` + provider error → `failed(reason)`.
  - `dispatched` + process exit or link desync → `unknown`.
  - Resend requires process `exited` and no tracked descendants.
  - State that approval responses use §4 acknowledgement and are excluded from §5.
- **Affected:** `04` §5, D30.

#### R3-28 — Timer coherence (MINOR · consistency)
- **Location:** `04` (T_grace 10 s, T_cancel 30 s, T_stall 15 min); D19.4 (staleness 15 min); U17 (hold 2 h); U18 (10 min); v0.2 D19 default `deny_after(min(180 s, provider limit))`.
- **Problem:**
  - v0.3 does not say whether the 180 s default still applies, or how it relates to U17's 2 h bound.
  - The escalation re-sends a protocol cancel after `T_cancel` (redundant step).
  - U18's 10 min is shorter than `T_stall`, so a no-client host never shows "stalled" before cancellation (acceptable, but undocumented).
  - Staleness and `T_stall` share 15 min with no rationale.
- **Recommended change:** add a timer table to `04`: name, default, owner question, which state it applies in, what fires. Make the `deny_after` default explicit.
- **Affected:** `04`, D19, U17, U18.

#### R3-29 — Smaller cell inconsistencies (MINOR · consistency)
- **Location:** `04` §3.
- **Problem:**
  - `stalled` + process exit omits "open tools → `outcome_unknown`", which `running` has.
  - `cancelling` + "turn finished (provider)" always yields `cancelled`, even if the provider reports `end_turn` (a race where the turn completed before cancel took effect). ACP returns `cancelled` only when cancel took effect (EV3-08).
- **Recommended change:** mirror the `running` row; take the outcome from the provider's stop reason.
- **Affected:** `04` §3.

### Secondary findings

#### R3-30 — The D26 purge procedure is in the wrong order and relies on a no-op pragma (IMPORTANT · security/evidence)
- **Location:** `02` D26 ("delete rows → `secure_delete` on → WAL checkpoint (truncate) → incremental VACUUM"); `03` F17.
- **Problem:**
  - SQLite says to enable `secure_delete` **before** the delete, or run VACUUM (EV3-07). Enabling it afterwards does not zero pages already freed.
  - `incremental_vacuum` "has no effect" unless `auto_vacuum=incremental`, which must be set before tables exist or applied with a full VACUUM (EV3-07).
  - The final vacuum writes to the WAL again, so a checkpoint must come **after** it.
  - Time Machine and APFS local snapshots of `~/Library/Application Support` hold copies outside "Shardrail-managed backups".
  - The "temporary pre-migration copy" in D26 is an automatic copy that purge must also reach.
- **Recommended change:** `PRAGMA secure_delete=ON` permanently (connection open), then delete, then a full `VACUUM` (or create the DB with `auto_vacuum=INCREMENTAL` from the start), then `wal_checkpoint(TRUNCATE)`. Exclude the data directory from Time Machine, or warn. Purge also deletes any pre-migration copy.
- **Affected:** D26, F17, R32, L2-02 §7.

#### R3-31 — Unknown approval option kinds need a fail-closed class (MINOR · security)
- **Location:** D19.1.
- **Problem / change:** D19.1 lists only known widening options. A new provider option kind should default to `widening` (hidden from `limited`, hidden under `untested-newer`), and ideally to `boundary-breaking` (R3-04) if it mentions sandbox or permissions.
- **Affected:** D19, D24.

#### R3-32 — Disposition fidelity (MINOR · traceability)
- **Location:** `01-R2-DISPOSITION.md`.
- **Assessment:** largely faithful. Three slips:
  - R2-05 asked for every state × event cell enumerated, "including impossible", and v0.3 substitutes a blanket rule (R3-22).
  - R2-09's "measure per-provider limits in X-05 before setting a default" was dropped from `05` §1.
  - R2-11's concrete `CLAUDE_CODE_DISABLE_AUTO_MEMORY=1` is generalized to "confirm in S4" without carrying the candidate switch into the S4 checklist.

  R2-16 is marked ACCEPT, but D26's pre-migration copy re-introduces an automatic copy (R3-30). "Rejected: none" is accurate. The R2-01 modification is disclosed, but its rationale is weak (R3-07).
- **Recommended change:** add the three omissions to `05` §1 and fix the R2-05 mark to ACCEPT-MOD.

#### R3-33 — C-24 developer-mode flag "outside agent-writable paths" does not exist on a shared UID (MINOR · logic)
- **Location:** `90` C-24.
- **Problem / change:** for an unprotected host every same-UID path is agent-writable. Store the flag in the keychain or make it a build-time constant of developer builds, and mark developer builds as "approvals not protected".

#### R3-34 — Is the D31 lease meaningful for providers without an OS sandbox? (QUESTION · product)
- **Location:** D31 ("lease governs which sandbox profile Shardrail selects").
- **Question:** for Hermes (likely no OS sandbox) and any `danger-full-access` session, the lease cannot be enforced. Should a read-only second session on such a provider be refused, rather than labelled read-only? Recommendation: refuse, or label it "read-only by request only".

## 4. Proposed corrected and added cells for `04-STATE-TRANSITIONS.md`

**Header rule (replace):** every cell is one of `→ state [+ action]`, `ignore (idempotent)`, `route (session-level)`, or `impossible → notice`. T1.5.3 tests all four kinds.

**New timers:** `T_ack` 60 s · `T_resume` 120 s · `T_kill` 10 s (all PROPOSED). Add a timer table (R3-28).

### §1 Process
| From | Event | v0.3 | Proposed |
| --- | --- | --- | --- |
| *(restart)* | recorded pid not alive / start-time or boot-id mismatch | missing | `exited(lost)` |
| *(restart, Linux cgroup)* | cgroup was killed by unit stop | missing | `exited(killed_by_restart)` |
| `spawning` | (before spawn) | — | journal `provider_spawn_intent` first (R3-15) |
| `alive` | leader exit, tracked descendants alive | `exited(code)` | `leader_exited` (counts as running for lease/badge) |
| `leader_exited` | last tracked descendant exits | — | `exited(code)` |
| `terminating` | `T_kill` elapsed after SIGKILL | missing | `kill_failed` (sticky, notice, badge) |
| `terminating` / `exited` | terminate requested | impossible | ignore (idempotent) |
| `orphan_alive` | terminate requested | `terminating` | `terminating` **without** protocol-cancel step |
| `orphan_alive` | orphan exits (kqueue/pidfd) | merged column | `exited(orphan)`; remove "user terminates" from this column |
| `orphan_alive`, `leader_exited`, `kill_failed` | spawn requested | refused | refused (all three) |
| any shared process | `T_cancel` escalation from one session | `terminating` | requires confirmation listing affected sessions; else stay `cancelling` + notice |

### §2 Link
| From | Event | v0.3 | Proposed |
| --- | --- | --- | --- |
| any | daemon restart | unstated | `none` |
| `resuming` | `T_resume` elapsed | missing | `desynced` |
| `ready`/`resuming` | response with tombstoned (timed-out) id | `desynced` | ignore + notice |
| `desynced` | (process still alive) | — | auto `terminate requested` after `T_grace` (or user-confirmed; owner choice) |

### §3 Turn
| From | Event | v0.3 | Proposed |
| --- | --- | --- | --- |
| `idle` | prompt dispatched | `running` | guard: link `ready` ∧ process `alive` ∧ no orphan/leader_exited ∧ lease if write-capable; else command rejected |
| `idle` | non-turn provider update | impossible | route (session-level) |
| `idle` | approval request | impossible | refuse (D24) + notice |
| `running`/`stalled`/`cancelling` | link `desynced`, process alive | `idle`+… | `detached` |
| `detached` | process `exited` | — | `idle` + `interrupted`; open tools → `outcome_unknown` |
| any non-idle | daemon restart, process `orphan_alive` | `idle`+`unknown_after_restart` | `detached` |
| `stalled` | process exits | `idle`+`interrupted` | + open tools → `outcome_unknown` |
| `cancelling` | cancel requested | impossible | ignore (idempotent) |
| `cancelling` | turn finished | `idle`+`cancelled` | `idle` + provider stop reason |
| `cancelling` | process exits after termination with open tools | `cancelled_by_termination` | `killed_mid_tool` if tool calls open, plus workspace notice (R3-17) |

### §4 Approval
| From | Event | v0.3 | Proposed |
| --- | --- | --- | --- |
| `pending` | turn **cancel requested** | (on "turn cancelled") | `withdrawn` + answer `cancelled` (EV3-08) |
| `pending` | process exit / link desync | implicit | `withdrawn(process_lost)` |
| `responded_unacked` | turn end / cancel / process exit / daemon restart | `withdrawn` | `delivered_unconfirmed(allow\|deny)` (terminal) |
| `responded_unacked` | `T_ack` elapsed | missing | `delivered_unconfirmed` + notice |
| `responded_unacked` | JSON-RPC error on response | `withdrawn` | `withdrawn` (unchanged) |
| `responded_unacked` | second authorized response | "rejected (final state)" | rejected: "already responded" (non-final wording) |
| `pending` | option kind unclassified | — | treated as `widening` (R3-31) |
| `pending` | boundary-breaking option chosen | — | `full` only; host protection → `unprotected` (R3-04) |

### §5 Delivery
| From | Event | v0.3 | Proposed |
| --- | --- | --- | --- |
| `dispatched` | provider error / precondition mismatch | missing | `failed(reason)` |
| `dispatched` | process exit / link desync | missing | `unknown` |
| `unknown` | user: resend | `resolved_resent` | allowed only if process `exited` and no tracked descendants |
| (scope) | approval responses | in §5 | excluded; tracked by §4 ack |

### §6 Badge
Protection becomes a host-level overlay, outside the precedence. Precedence: `orphan/detached/kill_failed` > `needs approval` > `approval outcome unconfirmed` > `degraded` (`exited(abnormal)`, `exited(lost)`, `desynced`) > `delivery unknown` > `terminating` > `resuming` > `stalled` > `cancelling` > `running` > `idle`.

## 5. What I did not check
- I did not read in full: baseline `level-1/` (only targeted lines), `source/MASTER_PLAN.original.ru.md`, v0.2 `d05`, `d06`, `d07`, `d10`, `d13`, `d-minor`, `01`, `03`, `04`, `90`, the r01 review, the backlog, all Level 2 outlines except grep hits, governance files, and packets.
- `05-ROADMAP-BACKLOG-MODULE-DELTA.md` and `06-ID-CROSSWALK-AND-ERRATA.md` were read but checked only lightly. I did not verify each crosswalk row against r01.
- Provider behaviors are not tested: whether tool runners `setsid`; Claude's protection of `.claude/` settings; Hermes sandboxing; Grok anything (xAI docs not read); ACP agents' `tool_call_update` after a deny; Codex escalation request fields; and whether Codex `.codex/rules` actually change approval decisions (INFERRED).
- macOS behavior is unverified: TCC attribution of descendants, `responsibility` disclaim, Seatbelt Unix-socket rules, keychain ACL prompts against the `security` CLI, the hardened-runtime effect on same-UID debugging, kqueue/`proc_listchildpids` suitability for the helper.
- gix: whether any current code path can spawn a process with all permissions off and empty drivers; status/diff/worktree coverage; behavior on stat-dirty filtered files.
- systemd behavior with `Restart=` on main-process crash (INFERRED from EV3-02, not read in `systemd.service`).
- I did not open the full `git-config` page sections beyond the variables cited, and did not check Git's own list of protected-only options exhaustively.
- Performance or budget impacts of the extra helper and Git worker processes.
- Legal or commercial questions (U9, D29).
