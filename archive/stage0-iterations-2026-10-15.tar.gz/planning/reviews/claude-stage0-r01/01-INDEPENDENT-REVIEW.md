# 01 — Independent Architecture Review of the Grok Baseline (WP-B)

> **Stage:** 0 · **Status:** FINAL FOR ROUND r01 — written and saved **before** any revision work (WP-D/E). Do not edit findings to match later proposals; add a new versioned review instead.
> **Reviewer:** Claude (Opus 5.5) · **Date:** 2026-10-15
> **Baseline:** `planning/source/MASTER_PLAN.original.ru.md` (sha256 `050f1437…f4df2`), all §1–§20 and preamble
> **Scope:** whole-system review (deviation from per-domain protocol noted in inventory INV-03); findings are indexed by domain in §6.
> **Recommendation:** **ACCEPT WITH CHANGES** at the level of direction; **REWORK** of four areas before Level 2 (approval-channel integrity, client transport, event durability model, Claude usage terms).

## 1. Method and labels

Every significant decision was examined for: proposal, evidence, alternatives, performance, security, cost, assumptions, failure scenarios, verdict, affected documents. Grok's recommendations were treated as hypotheses.

Evidence labels: **VERIFIED** (primary source read this round, URL + date), **INFERRED** (reasoned from verified facts or well-established platform behavior, not re-read this round), **UNVERIFIED** (claim not checked or only third-party sources), **CONTRADICTED** (primary source disagrees), **REQUIRES FUTURE EXPERIMENT** (only a Phase 0 spike can answer). No measurements were taken; no provider was executed.

## 2. Evidence gathered this round (access date 2026-10-15)

| ID | Source | Finding | Label |
| --- | --- | --- | --- |
| E-01 | <https://agentclientprotocol.com/protocol/session-setup> | `session/load`: Agent **MUST** replay the entire conversation as `session/update` notifications. `session/resume` (capability `sessionCapabilities.resume`) reconnects **without** replay. Clients MUST NOT call `session/load` unless `loadSession` is advertised. | VERIFIED |
| E-02 | <https://agentclientprotocol.com/protocol/overview> | Baseline agent methods `initialize`, `authenticate`, `session/new`, `session/prompt`, `session/cancel`; optional `session/load`, `session/set_mode`, `logout`; client methods `session/request_permission`, optional `fs/*`, `terminal/*`, `elicitation/*`. Path `/protocol/v1/`. | VERIFIED |
| E-03 | <https://learn.chatgpt.com/docs/app-server> (redirect target of `developers.openai.com/codex/app-server`) | stdio default (newline-delimited JSON); `--listen ws://` "experimental and unsupported"; `--listen unix://` carries WebSocket; `thread/start/resume/fork/list/read`, `thread/loaded/list`; `turn/start` accepts per-turn `sandboxPolicy`, `approvalPolicy`, model, `cwd`; `turn/interrupt`; `turn/steer` (requires `expectedTurnId`); approvals `item/commandExecution/requestApproval`, `item/fileChange/requestApproval` with `accept / acceptForSession / decline / cancel`; pending requests cleared when a turn starts/completes/is interrupted (`serverRequest/resolved`); `item/completed` is authoritative over deltas; experimental methods require `capabilities.experimentalApi=true` at `initialize`; `thread/shellCommand` runs **outside sandbox with full access**; `generate-ts` / `generate-json-schema` match the running version; `clientInfo.name` goes to OpenAI Compliance Logs. Docs do **not** state behavior on client disconnect during approval. | VERIFIED |
| E-04 | <https://code.claude.com/docs/en/agent-sdk/overview> | "Unless previously approved, Anthropic does not allow third party developers to offer claude.ai login or rate limits for their products, including agents built on the Claude Agent SDK." SDK use governed by Anthropic Commercial Terms. Branding: product may not appear to be Claude Code. | VERIFIED |
| E-05 | <https://code.claude.com/docs/en/agent-sdk/sessions> | Resume/fork by session ID; transcripts in `~/.claude/projects/<encoded-cwd>/*.jsonl`; `listSessions()` / `getSessionMessages()` (TS) and Python equivalents read sessions on disk; `getSessionInfo`, `renameSession`, `tagSession`. | VERIFIED |
| E-06 | <https://hermes-agent.nousresearch.com/docs/user-guide/features/acp> | `hermes acp`; allow once / session / always (permanent allowlist) / deny; no answer or error → deny after `approvals.timeout` (default 300 s); sessions listable/loadable/resumable/forkable after restart; explicit warning that a host that auto-answers approvals turns execution unattended; default `hermes-acp` toolset includes web/browser tools, `execute_code`, `delegate_task`; narrowing is via Hermes `config.yaml`. | VERIFIED |
| E-07 | <https://git-scm.com/docs/git-config> | `core.fsmonitor` may contain "the pathname of the 'fsmonitor' hook command" used to speed up `git status`; protected configuration = system/global/command scopes only, so `.git/config` (local) is attacker-controllable in an untrusted checkout; `core.hooksPath=/dev/null` per command disables hooks. | VERIFIED |
| E-08 | <https://v2.tauri.app/release/> | Latest `tauri` crate 2.12.3, 2026-10-10. No Tauri 3 prerelease is listed on this page (baseline cites `3.0.0-alpha.4` from release notes; not re-confirmed). | VERIFIED (2.12.3) / UNVERIFIED (3.0 alpha) |
| E-09 | <https://zed.dev/acp/agent/grok-build> and third-party pages | `grok agent stdio` is the ACP entry point; `--no-auto-update` used by third-party hosts. xAI primary docs not reached this round; baseline relied on the local Grok manual. | VERIFIED (entry point via Zed registry) / UNVERIFIED (rest) |
| E-10 | Third-party summaries of `agentclientprotocol/claude-agent-acp` | Adapter is a Node process wrapping the Claude Agent SDK; package previously `@zed-industries/claude-code-acp`. Hosted by the ACP organization, **not** an Anthropic repository. | UNVERIFIED (primary README not read) |

Platform facts used as INFERRED (well established, not re-read): WKWebView renders in separate `com.apple.WebKit.*` XPC processes; macOS `ps` RSS undercounts compressed memory (phys_footprint is the Activity-Monitor metric); Linux `SO_PEERCRED` and macOS `LOCAL_PEERCRED`/`LOCAL_PEERPID` expose peer credentials; same-UID processes can read each other's `0600` files; browsers cannot open Unix sockets; OpenSSH supports stdio subcommands and Unix-socket forwarding; `SMAppService` (macOS 13+) registers bundled launch agents/login items with user approval in System Settings.

## 3. Overall assessment

The baseline is unusually disciplined: official protocols only, explicit Unsupported list (no TUI scraping), single-writer journal, no client-side ACP `fs`/`terminal` (D7), timeout never becomes allow (D12), provider secrets never read (N3), no provider bundling (D9), explicit user-reviewed handoff (D10), budgets labeled as budgets, and spikes before product code. These should be **retained**.

Its weaknesses cluster in four places where the plan is internally consistent but under-specified against real workloads:

1. **The approval channel is not protected from the agents it governs** (CR-01) and the rendering surface that shows approval cards is not treated as an attack surface (CR-03).
2. **The client path is undefined**: a WebView cannot speak the Unix socket the plan names as the domain API (CR-02); remote and multi-host access is manual (CR-13); clients have no identity or scope (CR-14).
3. **The event model assumes small, idempotent, ID-bearing provider streams**; real streams are token-granular, replay on load, and often lack event IDs (CR-05, CR-06, CR-16, CR-17).
4. **Lifecycle choices optimize for the MVP at the cost of the stated product**: window close kills agents (CR-08), a 180 s deny timeout plus "window close = deny" makes remote/mobile approvals impractical (CR-07), and a hard version refusal will break on routine provider updates (CR-10).

A fifth, non-technical issue is product-critical: **Claude Agent SDK usage terms** (CR-11).

## 4. Findings

Severity: BLOCKING (must be resolved before Level 2 of the affected module) · IMPORTANT · MINOR · QUESTION.

### CR-01 — Agents can reach and drive the approval channel (BLOCKING)
- **IDs:** N4, D4, D12, §10.1, R3, §9.1.
- **Claim challenged:** a `0600` socket in a `0700` directory, a `0600` bridge-secret file, and peer-UID checks protect the daemon.
- **Analysis:** provider processes and every command an agent runs execute as the **same UID** as the daemon (§6.2). UID checks and file modes therefore admit them. An agent running with `danger-full-access`, Grok `off`, or simply a sandbox profile that permits Unix-socket connects and home-directory reads can connect to `shardraild` or read the bridge secret and answer its own `permission_requested` with allow, or change workspace trust. The threat table lists "another local process of the same user" as an actor but no countermeasure addresses it. (INFERRED from POSIX semantics; sandbox reachability of the socket per profile is REQUIRES FUTURE EXPERIMENT.)
- **Why it matters:** approval is the product's primary safety invariant (N9). A prompt-injected agent self-approving is the worst-case outcome the plan exists to prevent.
- **Alternatives:** (a) per-client credentials held in OS keychain with app-signature ACL on macOS, never in files readable by agents; (b) reject socket peers whose PID descends from a supervised provider process tree (`LOCAL_PEERPID` / `SO_PEERCRED` + process ancestry) — a heuristic, not a boundary; (c) place the socket/secret in paths that every Shardrail-selected sandbox profile denies; (d) on Linux, run agents as a separate Unix user (R3 hardening becomes approval-integrity hardening); (e) never pass Shardrail endpoints or secrets in provider environment variables.
- **Verdict:** MODIFY D4/§10; promote R3 hardening; add explicit residual-risk statement for unsandboxed agents.

### CR-02 — The WebView cannot use the domain API as specified (BLOCKING for client Level 2)
- **IDs:** D2, D4, §5 diagram (`Mac → Sock`), §6.3.
- **Claim:** "Domain API of the client is the daemon socket, not Tauri commands"; the browser gets a loopback WebSocket bridge "only with the window or explicit open-in-browser."
- **Analysis:** JavaScript in WKWebView (and any browser) cannot open a Unix socket. The desktop UI therefore needs either the loopback bridge (a TCP port the plan otherwise avoids) or a shell-side relay. A relay inside Tauri is permissible under D2 only if it is a byte-level pass-through with no domain logic; the plan does not say so, and §19 explicitly forbids `invoke` for sessions/approvals. The remote browser case also needs the bridge even when no window exists (Linux has no window).
- **Alternatives:** (1) single wire protocol (framed JSON over WebSocket semantics) for all clients; desktop shell relays frames via a Tauri channel or custom URI scheme to the Unix socket with no parsing (keeps no TCP port); browser uses an explicitly enabled loopback WebSocket listener; (2) loopback WebSocket for everything (simplest, adds a local TCP surface and DNS-rebinding exposure). Recommend (1) with (2) as the browser path.
- **Verdict:** MODIFY D2/D4; new decision required (candidate D16).

### CR-03 — Untrusted model/tool output is rendered in a privileged WebView (BLOCKING)
- **IDs:** §10.1, §12, F4, F5.
- **Analysis:** the threat model covers fake "I already asked permission" text but not the rendering surface. Model text, tool output, file names, diffs and MCP results are attacker-influenced (prompt injection via repository content). Risks: HTML/Markdown injection into a WebView that holds a domain-API connection; remote image/link loads in Markdown used as a data-exfiltration channel; ANSI/terminal escape sequences; Unicode bidi/invisible characters making the command shown on an approval card differ from the command executed (Trojan-Source class); extremely long lines and pathological Markdown as CPU denial of service. (INFERRED; these are well-documented classes.)
- **Alternatives:** sanitize to an allowlisted Markdown subset; no raw HTML; strict CSP with no remote origins (images only via user action); approval cards render from structured protocol fields with visible escaping of control/bidi characters and a "raw bytes" toggle; size caps and incremental parsing.
- **Verdict:** add requirement + decision (candidate D21); affects §10, §12, F4/F5.

### CR-04 — Read-only Git view can execute repository-controlled commands (BLOCKING for D13/F8)
- **IDs:** D13, F8, F13, §11 (git status via FSEvents).
- **Evidence:** E-07. `core.fsmonitor` in `.git/config` can name a command run during `git status`; local scope is not protected configuration. Diff drivers (`textconv`, external diff) configured by repository files are a related class (INFERRED).
- **Why:** the plan shows Git state for **unknown/untrusted** workspaces — exactly where F13 refuses to start agents. Shardrail itself would become the code-execution vector.
- **Alternatives:** use a library implementation (libgit2/gitoxide) that does not execute hooks/fsmonitor/filters; or invoke `git` with forced overrides (`-c core.fsmonitor=false -c core.hooksPath=/dev/null`, `--no-ext-diff`, `--no-textconv`, safe `GIT_CONFIG_*` environment) and never in `unknown` workspaces without them. Library route preferred for status/diff; CLI fallback hardened.
- **Verdict:** MODIFY D13; candidate D22.

### CR-05 — Resume replays history; dedup relies on IDs the protocols do not provide (IMPORTANT)
- **IDs:** §8.2, §9.1, §13.3, F9, F10, F12.
- **Evidence:** E-01 (ACP `session/load` MUST replay; `session/resume` does not), E-03 (Codex `item/completed` authoritative; `thread/resume`).
- **Analysis:** §13.3 dedups by (provider session, external event id) "if present"; ACP `session/update` message chunks carry no stable event ID. After a crash, `session/load` will re-stream the entire conversation into the adapter; without a replay mode the journal duplicates every message or, worse, interleaves replayed and new events. The plan does not mention `session/resume`.
- **Alternatives:** adapter-level **replay mode**: on load, treat incoming updates as a reconstruction of provider history, reconcile against the journal (by tool-call IDs, item IDs, turn boundaries) and record only a `provider_history_reconciled` marker plus gaps; prefer `session/resume` where advertised; for Codex reconcile on item IDs.
- **Verdict:** MODIFY §8.2/§13.3; affects session-engine Level 2.

### CR-06 — Event granularity, durability and backpressure are unspecified (IMPORTANT)
- **IDs:** B4, B8, B10, §8.2, D5, N2.
- **Analysis:** providers emit token-level deltas (Codex `item/agentMessage/delta`, command output deltas — E-03; ACP message chunks). A long turn can produce thousands of deltas; B10 assumes 200 events per turn. Journaling every delta as an immutable event inflates the database and write path; journaling none loses partial output on crash. The plan also has no policy for slow clients (phone on a weak link): per-client unbounded buffers break B8 under load.
- **Alternatives:** two tiers — **ephemeral deltas** (in-memory, coalesced to ≤ one flush per frame interval per item, fan-out only) and **durable events** (item started/completed, approvals, turn boundaries, periodic checkpoints of in-progress items). Per-client bounded queues; on overflow, drop deltas and send a projection snapshot + cursor (resync), never grow unbounded.
- **Verdict:** MODIFY D5/§8.2; new budgets (memory per client queue, journal bytes per turn). Candidate D17.

### CR-07 — Approval lifecycle is single-client and short-fuse (IMPORTANT)
- **IDs:** F5, D12, §9.3 row "client dropped mid-approval", §10.1 (180 s), Phase 2/3 goals.
- **Analysis:** (1) "window close = deny" (F5) is incompatible with multiple clients and with remote daemons whose sessions outlive any one client. (2) The invariant that matters is *no execution without an explicit human allow*; deny-on-short-timeout is a policy choice that, at 180 s, makes Phase 2's "continuous work" and Phase 3's "approve from phone" impractical — a user away for four minutes gets a denied tool call, and the agent may then pursue a different, unreviewed path. (3) No rule decides which response wins when desktop and phone answer concurrently, or how a stale response is rejected after timeout/cancel (Codex clears pending requests on turn end — E-03). (4) Provider timeouts differ (Hermes 300 s — E-06; Codex unspecified).
- **Alternatives:** approval as a daemon-owned record with states `pending → allowed | denied | expired | withdrawn`, resolved once by compare-and-set on `approval_id`; client disconnect never resolves it; the deny timer becomes a per-workspace policy with "hold until provider timeout" for providers that permit long waits; notify all attached clients; stale answers return a typed error.
- **Verdict:** MODIFY F5/D12 (timeout never = allow is retained). Candidate D19.

### CR-08 — Daemon lifetime bound to the window (IMPORTANT)
- **IDs:** D11, §6.1, U6, F5, §14 (browser served "with the window").
- **Analysis:** closing the window cancels all turns. On macOS, closing the last window conventionally does not quit an app; users will close the window expecting agents to keep working (Scenario 3). Binding the browser bridge to the window also makes "open in browser" disappear with it. Separately (INFERRED), because providers are descendants of the app, TCC prompts triggered by any agent are attributed to Shardrail.app, so grants accumulate on Shardrail and apply to all agents — a UX and least-privilege issue the plan treats only as a benefit.
- **Alternatives:** (a) app-lifetime daemon: window close hides; app keeps a menu-bar presence while sessions run; quit asks to cancel/keep; (b) opt-in `SMAppService` launch agent for continuous local operation (U6); (c) fully separate daemon always. Recommend (a) for Phase 1, (b) as Phase 2 opt-in.
- **Verdict:** MODIFY D11. Candidate update to D11.

### CR-09 — Session state is a single linear enum (IMPORTANT)
- **IDs:** §6.4, §9.3, §12, F7.
- **Analysis:** `starting → ready → running → waiting_approval → running → idle` conflates process health, protocol sync, turn state and pending approvals. Real cases: multiple concurrent permission requests (parallel tool calls); `cancelling` (cancel sent, turn not closed); `stalled` (used in §9.3/§12 but absent from §6.4); process alive but protocol desynced; client `disconnected` (a client-side view state, not a session state).
- **Alternative:** orthogonal dimensions — process {spawning, alive, exited(code)}, link {initialized, desynced}, turn {idle, running, cancelling, stalled}, approvals {set of pending IDs}, delivery {confirmed, unknown}; UI derives a single badge.
- **Verdict:** MODIFY §6.4. Candidate D18.

### CR-10 — Hard refusal of unknown provider versions is unmaintainable (IMPORTANT)
- **IDs:** F1, §2.4, R1, R6, D6, N6.
- **Analysis:** coding-agent CLIs ship frequently and several auto-update. Refusing to start on any unverified version converts every upstream release into a Shardrail outage for a solo maintainer. The real stability lever is narrower: avoid experimental surfaces (Codex requires explicit `experimentalApi` opt-in — E-03), tolerate unknown fields, negotiate capabilities at `initialize`, and detect drift at runtime.
- **Alternative:** compatibility policy per provider: `tested` (no warning), `untested-newer` (start with visible warning, strict schema validation in shadow mode logging divergences), `known-bad` (refuse). Runtime check: compare the user binary's generated Codex schema against the bundled reference on version change (cheap, no execution of agent turns). Keep CI drift test.
- **Verdict:** MODIFY F1. Candidate D23.

### CR-11 — Claude integration is gated by usage terms, not only by protocol fidelity (BLOCKING for commercialization; QUESTION for owner)
- **IDs:** D6, D9, R2, R10, §7.3, §15, U7.
- **Evidence:** E-04. Agent SDK use (including powering a product offered to others) is governed by Anthropic Commercial Terms; third-party products may not offer claude.ai login or rate limits unless previously approved.
- **Analysis:** both candidate channels (claude-agent-acp, direct SDK) are SDK-based. Whether a locally installed orchestrator that drives the *user's own* Claude Code with the user's own subscription login falls under that restriction is a legal/policy question this review cannot settle. The plan addresses only package licensing (bundling), not usage policy. The adapter is also not an Anthropic repository (E-10), so "official adapter" in §7.3 should read "ACP-organization adapter".
- **Alternatives:** (a) API-key authentication only for Claude in Shardrail (compliant per E-04, costs users); (b) seek Anthropic approval; (c) drive the user-installed `claude` CLI (headless stream-json) — likely the same policy question; (d) ship Claude as "bring-your-own-API-key" in commercial builds, subscription login only for personal non-distributed builds pending legal review.
- **Verdict:** OPEN QUESTION for owner + legal before Phase 1 includes Claude; S4 must add a terms checkpoint. New risk.

### CR-12 — Process-per-session applied uniformly (IMPORTANT for memory)
- **IDs:** D8, R9, B2, §6.1.
- **Evidence:** E-03: Codex `turn/start` accepts per-turn `sandboxPolicy` and `cwd`; `thread/loaded/list` implies multiple loaded threads per process (concurrent turns not confirmed). The Grok leader-mode concern is Grok-specific.
- **Analysis:** provider processes dominate memory (baseline §11 agrees). A uniform per-session rule may multiply Codex/Hermes memory without isolation benefit, while for Claude each session spawns its own CLI anyway.
- **Verdict:** MODIFY D8 into a per-provider process-topology table decided by S1–S4.

### CR-13 — Remote and multi-host access is manual and fragmented (IMPORTANT)
- **IDs:** D4, §6.2, §9.2, U4, Phase 2, product vision (unified session management).
- **Analysis:** users must run `ssh -L` themselves; the Mac shows "the remote journal" but local and remote daemons are separate and a unified view is "out of plan". The product vision makes unified management a headline feature. A unified view does not require merging journals: the client can hold N daemon connections and federate projections.
- **Alternatives:** the desktop app owns host connections by spawning system OpenSSH with a stdio subcommand (`ssh host shardraild bridge` relaying to the remote socket — the pattern used by remote-development tools; INFERRED), reusing the user's SSH config/agent/jump hosts, no forwarded ports, no daemon-to-daemon sync; client-side federation keyed by `(host_id, session_id)` with per-host cursors.
- **Verdict:** MODIFY D4/§9.2. Candidate D24.

### CR-14 — Clients have no identity, scope or revocation model (IMPORTANT)
- **IDs:** §10.1 (stolen phone), D4, Phase 3 gate.
- **Analysis:** a single bridge secret authorizes everything. The plan promises token revocation for phones without per-device credentials. A browser tab or phone should not be able to lower sandbox levels, mark a workspace trusted, or enable allow-all.
- **Alternative:** paired client credentials (per device, revocable, last-seen), scopes (`observe`, `respond_approval`, `prompt`, `control_policy`), and step-up rules: policy-weakening actions require a local desktop client.
- **Verdict:** new decision (candidate D20).

### CR-15 — Phase 3 lacks a notification path (IMPORTANT / QUESTION)
- **IDs:** U4, Phase 3, scenario 8 in §2.2.
- **Analysis:** approving from a phone requires the phone to learn that an approval is pending. Without push, the user must keep the app foregrounded with a live tunnel. Android background restrictions make persistent SSH tunnels unreliable (INFERRED).
- **Alternatives:** PWA served by the daemon over the chosen tunnel plus Web Push (VAPID; payload encrypted end-to-end to the browser push service, no own relay infrastructure — INFERRED, requires verification on Android); user-managed mesh VPN (Tailscale/WireGuard) as the transport; native shell later.
- **Verdict:** DEFER with explicit requirements; widen U4.

### CR-16 — Command delivery uncertainty and concurrent commands (IMPORTANT)
- **IDs:** §9.3 (`command_id`), F7, F12.
- **Analysis:** `command_id` prevents a second session/prompt on client retry, but (1) the daemon can crash after writing a prompt to provider stdin and before committing — the plan's "no automatic resend" is right but there is no recorded intent, so the UI cannot show "delivery unknown"; (2) the retention window for `command_id` is unspecified; (3) two clients issuing conflicting commands (cancel vs. new prompt, two approvals) have no preconditions.
- **Alternative:** write `command_accepted` (intent) before side effects and `command_dispatched` after; on recovery, intents without dispatch confirmation become `delivery_unknown` requiring a human decision; commands carry optional preconditions (`expected_turn_id`, mirroring Codex `turn/steer`'s `expectedTurnId`); `command_id` results retained per session for the session lifetime.
- **Verdict:** MODIFY §9.3.

### CR-17 — No journal schema versioning (IMPORTANT)
- **IDs:** D5, §8.2.
- **Analysis:** an append-only journal outlives many app versions; event payloads and provider mappings will change. Without per-event schema versions and read-time upcasting (or migrations), old histories become unreadable or require destructive migration.
- **Verdict:** add to D5 (candidate D25).

### CR-18 — Performance methodology gaps (IMPORTANT)
- **IDs:** B1–B10, N1, U1.
- **Analysis:** B3 "RSS of the shell" excludes WKWebView's WebContent/GPU/Networking XPC processes and macOS RSS excludes compressed memory (INFERRED) — B3 could pass while real footprint is several times higher. B4 spans two processes; clocks must be specified. Product priorities include power consumption and idle CPU; no budget covers idle CPU wakeups or energy. No budget covers journal disk growth, per-client queue memory, or WebView memory over a multi-day session.
- **Verdict:** MODIFY §11 methodology; add proposed budgets.

### CR-19 — The journal is an unclassified sensitive store (IMPORTANT)
- **IDs:** §8.2, §9.1, §10.2, N3.
- **Analysis:** prompts and tool output (up to 256 KiB each) frequently contain secrets read from `.env` files, tokens in command output, and proprietary code. Prefix denylists catch a minority of secret formats. The file sits in plaintext on Mac and on remote servers (backups, snapshots). N3 ("secrets not read into DB") is not achievable as stated; it holds only for credential stores.
- **Alternatives:** restate N3 precisely; classify the journal as sensitive; add retention and per-session purge; redaction as best effort with entropy + format detectors; optional encryption at rest deferred with a key in OS keychain (Mac) — Linux key management open.
- **Verdict:** MODIFY §10, N3.

### CR-20 — Trust policy is provider-partial (IMPORTANT, partly UNVERIFIED)
- **IDs:** F13, R7, D14.
- **Analysis:** F13 tests Claude and Grok only. Codex and Hermes also load project-scoped configuration/instructions (e.g., `AGENTS.md`, project MCP definitions) — instruction files are prompt-injection vectors even when they cannot execute code; executable project configuration (hooks, MCP server commands) is the critical class. Exact per-provider project-config execution paths are UNVERIFIED.
- **Verdict:** generalize F13 to a per-provider "project-config execution surface" table populated by S1–S4.

### CR-21 — UI/UX scope undershoots the product (IMPORTANT)
- **IDs:** §12, D3, N7, product priority #3.
- **Analysis:** §12 is principled (state visibility, approval modality, reduced motion, AA) but restricts Phase 1 to nine primitives and system styling with no cross-session overview. A multi-agent environment's core screen is an **attention model**: which session needs me now (approvals, failures, completions) across hosts. Missing: global attention inbox, OS notifications, command palette and full keyboard map, split/tiled layouts, density settings, large-diff and large-file viewing strategy, streaming Markdown/syntax-highlighting cost (re-parsing the whole message per delta is O(n²)).
- **Verdict:** MODIFY §12; visual identity remains U2.

### CR-22 — Framework choice is framed as the main performance lever (MINOR)
- **IDs:** D3, U8, S5.
- **Analysis:** SolidJS fine-grained updates vs React VDOM matter less than delta coalescing, virtualization, incremental Markdown, and avoiding layout thrash. Accessibility primitives (e.g., mature React-based ARIA libraries) may dominate N7 cost. S5 should test the full pipeline, not only the framework.
- **Verdict:** RETAIN U8 open; sharpen S5 criteria.

### CR-23 — Rust choice: retain, but the Go fallback is only cheap if the contract is schema-first (MINOR)
- **IDs:** D1, D3, D4.
- **Analysis:** Rust is defensible: Tauri already brings it, `agent-client-protocol` crate exists, no GC on a long-lived supervisor, single static binary on Linux. The solo-developer cost is compile/iteration time and async complexity. The "rewrite in Go" exit is only tractable if the client wire protocol and journal schema are language-neutral artifacts (JSON Schema → generated Rust and TS types).
- **Verdict:** RETAIN D1 with schema-first contract.

### CR-24 — Roadmap Phase 1 is too large for one developer and lacks a vertical slice (IMPORTANT)
- **IDs:** §16, Phase 1 gate.
- **Analysis:** Phase 1 contains daemon, journal, shell, UI, four adapters across three protocols, approvals, trust, recovery and budgets. The gate requires all at once. A fake-agent harness (deterministic ACP and app-server simulators) is mentioned in tests but not planned as a deliverable, though everything depends on it.
- **Alternative:** Phase 1a (fake agents + daemon + journal + one ACP provider + minimal UI), 1b (Codex), 1c (second ACP provider), 1d (Claude per S4 + terms); design daemon as location-agnostic from 1a so Phase 2 is packaging, not redesign.
- **Verdict:** MODIFY §16.

### CR-25 — Official session-history APIs are ignored (IMPORTANT, missed capability)
- **IDs:** §2.4, S6, product vision ("existing-session observation").
- **Evidence:** E-03 (`thread/list`, `thread/read`), E-05 (`listSessions`, `getSessionMessages`), E-06 (Hermes list/load/resume after restart).
- **Analysis:** live TUI attach remains correctly Unsupported, but read-only import of sessions created elsewhere, and "continue as new Shardrail session" via official resume/fork, are supported paths the plan omits.
- **Verdict:** add capability `list_external_sessions` / `import_history` (read-only); keep live attach Unsupported.

### CR-26 — Remaining minor findings
| ID | Finding | Verdict |
| --- | --- | --- |
| CR-26a | §9.3 SQLite corruption: renaming and starting empty silently drops history from the user's view; prefer read-only open + integrity check + explicit user choice; periodic online backup. | MODIFY |
| CR-26b | Long-running WAL growth: long read transactions starve checkpoints; requires short readers and explicit checkpoint policy (B8 soak should watch WAL size). | MODIFY (budget) |
| CR-26c | Linux inotify watch limits in large repositories; watch only expanded directories and Git metadata files. | MODIFY §11 |
| CR-26d | Codex app-server now offers `--listen unix://` (E-03); S1 should note it but stdio remains preferred (child ownership). Avoid `experimentalApi`. | MODIFY S1 |
| CR-26e | Hermes default ACP toolset includes web/browser tools and `execute_code` (E-06); Shardrail cannot narrow it without changing Hermes config (forbidden to do silently). UI must show the effective toolset and recommend user-side config. | MODIFY §7.3 |
| CR-26f | Distribution: a Mac App Store build is effectively incompatible with spawning user-installed CLIs (App Sandbox); Developer ID + notarization (as planned) is the only path. INFERRED. | RETAIN, document |
| CR-26g | `clientInfo.name` is reported to OpenAI Compliance Logs (E-03): disclose in privacy notes; choose a stable product name. | MINOR |
| CR-26h | §15 recommends a private repository and "all rights reserved"; this is an owner decision and must not be treated as resolved. | OPEN QUESTION (owner) |

## 5. Decision-by-decision verdicts (D1–D15)

| ID | Verdict | Key reason | Findings |
| --- | --- | --- | --- |
| D1 Rust core | RETAIN (+schema-first) | Sound; fallback needs language-neutral contracts | CR-23 |
| D2 Tauri 2 + WKWebView | RETAIN, MODIFY | Relay path undefined; footprint methodology | CR-02, CR-18 |
| D3 TS projection, no state layer | MODIFY | Needs bounded projection memory; criteria beyond framework | CR-06, CR-22 |
| D4 Unix socket, SSH forward | MODIFY | Client relay, client identity, SSH stdio bridge, agent reachability | CR-01, CR-02, CR-13, CR-14 |
| D5 SQLite WAL single writer | RETAIN, MODIFY | Tiered durability, schema versioning, retention, corruption path | CR-06, CR-17, CR-19, CR-26a/b |
| D6 Protocol per provider | RETAIN (channels); QUESTION (Claude terms) | Channel choice well evidenced | CR-10, CR-11 |
| D7 No ACP client fs/terminal | RETAIN | Correct and important | — |
| D8 Process per session | MODIFY → per-provider | Codex supports per-turn policy | CR-12 |
| D9 Providers not bundled | RETAIN | — | CR-11 |
| D10 Explicit handoff bundle | RETAIN | — | — |
| D11 Mac daemon child of app | MODIFY | Window close kills work | CR-08 |
| D12 Timeout = deny | MODIFY (invariant retained) | Multi-client, hold semantics, CAS | CR-07 |
| D13 Own read-only Git/files | MODIFY | Repo-config execution | CR-04, CR-26c |
| D14 No bypass by default | RETAIN | — | — |
| D15 Plans in `planning/` | RETAIN | — | — |

## 6. Findings indexed by Level 1 domain

| Domain file | Findings |
| --- | --- |
| 01 product | CR-13, CR-21, CR-25 |
| 02 requirements | CR-07 (F5), CR-10 (F1), CR-19 (N3), CR-20 (F13) |
| 03 technology | CR-02, CR-22, CR-23 |
| 04 system/process | CR-02, CR-08, CR-09, CR-12, CR-13 |
| 05 providers | CR-05, CR-10, CR-11, CR-12, CR-20, CR-25, CR-26d/e/g |
| 06 sessions/events | CR-05, CR-06, CR-17 |
| 07 data/recovery | CR-05, CR-16, CR-26a/b |
| 08 security | CR-01, CR-03, CR-04, CR-14, CR-19 |
| 09 performance | CR-06, CR-18, CR-26c |
| 10 UI | CR-03, CR-21, CR-22 |
| 11 quality | CR-05, CR-24 |
| 12 release/licensing | CR-11, CR-26f/h |
| 13 roadmap | CR-15, CR-24 |
| 14 decisions/risks | §5 above |

## 7. Unknowns requiring future experiment (not executed)

| ID | Question | Proposed experiment (future Phase 0, requires authorization) |
| --- | --- | --- |
| X-01 | Can each provider's sandbox profile reach the daemon socket / secret paths? | Per profile, run a scripted agent tool call attempting `connect()` and `open()`; record outcome |
| X-02 | ACP `session/resume` support per agent; replay volume of `session/load` | S2/S3 extension: capture both on a 500-event session |
| X-03 | Delta rates (events/s, bytes/turn) per provider | Record wire traffic of three representative turns per provider |
| X-04 | Codex concurrent turns across threads in one process | S1 extension |
| X-05 | Approval wait limits per provider (Codex, Claude adapter, Grok) | S1–S4: hold an approval 10 min; observe |
| X-06 | WKWebView total footprint incl. XPC processes vs B3 | S5 using `footprint`/Activity Monitor on all `com.apple.WebKit.*` children |
| X-07 | Android PWA Web Push delivery for a self-hosted VAPID sender | Phase 3 spike |

## 8. Recommendation

**ACCEPT WITH CHANGES** for the overall direction (Rust daemon per host, thin web clients, official protocols, single-writer journal, explicit approvals). **REWORK before Level 2** of: approval/security broker (CR-01, CR-03, CR-07, CR-14), client communication (CR-02, CR-13), session/event engine (CR-05, CR-06, CR-09, CR-16, CR-17), and Claude channel (CR-11, owner/legal). This report authorizes nothing and does not overrule the owner.
