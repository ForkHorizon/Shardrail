# 02 — Conceptual Architecture Stress Test (WP-C)

> **Stage:** 0 · **Status:** FINAL FOR ROUND r01 · **Author:** Claude (Opus 5.5), 2026-10-15
> **Subject:** the **original Grok baseline** (not the v0.2 candidate). Conceptual analysis only — nothing was executed or simulated.
> Finding references (CR-xx) point to `01-INDEPENDENT-REVIEW.md`.

Verdict key: **OK** (architecture holds), **PATCH** (holds with a local rule), **CHANGE** (architecture must change).

## Summary

| # | Scenario | Verdict | Primary weakness | Findings |
| --- | --- | --- | --- | --- |
| 1 | Many agents stream large outputs | CHANGE | No delta tier, no client backpressure | CR-06 |
| 2 | Provider crash mid-tool | PATCH | Unknown tool outcome not modeled; replay duplicates on load | CR-05, CR-09 |
| 3 | Desktop window closes during execution | CHANGE | D11 kills all turns | CR-08 |
| 4 | Remote link drops during approval | CHANGE | Disconnect/timeout = deny; no CAS | CR-07 |
| 5 | Open thousands of historical events | PATCH | No paging contract, full projection fold | CR-06 |
| 6 | Provider upgrade changes protocol | CHANGE | Hard refusal vs. tolerant evolution | CR-10 |
| 7 | Two clients modify the same session | CHANGE | No preconditions / approval CAS | CR-07, CR-16 |
| 8 | Malicious workspace | CHANGE | Git config execution; self-approval; render injection | CR-01, CR-03, CR-04 |
| 9 | Network interruption → repeated commands | PATCH | No intent record, unbounded `command_id` semantics | CR-16 |
| 10 | Same user on macOS + remote Linux | CHANGE | Manual tunnels; no unified view | CR-13, CR-14 |
| 11 | Large repos browsed while agents write | PATCH | Watch limits, status cost, Git config exec | CR-04, CR-26c |
| 12 | Multi-day continuous operation | PATCH | WAL growth, journal growth, WebView memory | CR-18, CR-26b |

---

## S-1. Multiple agents emit large event streams simultaneously

- **Expected (baseline):** each adapter maps provider updates to common events; the single-writer journal appends each; clients receive events by cursor; UI virtualizes.
- **Failure:** 4 sessions × token-level deltas (tens to hundreds per second each during fast generation; command output deltas can be larger) → every delta is a durable row and a socket frame. The writer becomes the bottleneck or fsync-bound; a slow client (phone) accumulates an unbounded queue; the WebView re-renders per delta.
- **Weakness:** B10 assumes 200 events/turn; no distinction between ephemeral and durable events; no per-client bound.
- **Detection/recovery:** writer queue depth and per-client queue bytes as metrics; on per-client overflow, drop deltas and send snapshot + cursor.
- **Performance constraints:** B4 (p95 ≤ 50 ms event→frame), B8 (memory drift), B10. Coalescing to frame cadence (~16–33 ms per item) bounds UI work independent of provider rate.
- **Modification:** **required** — tiered events and bounded fan-out (candidate D17).

## S-2. Provider process crashes during an active tool operation

- **Expected:** stdio EOF → session `degraded`; resume button if capability exists; no auto re-prompt.
- **Failure:** the tool (e.g., a shell command) may have completed, partially completed, or still be running as an orphan child of the dead provider. The journal shows `tool_started` without `tool_finished`. On `session/load` (ACP), the provider replays the whole history, which the adapter appends as new events (duplicates).
- **Weakness:** no `tool_outcome_unknown` terminal state; no orphan-process policy for provider-spawned children; replay mode missing.
- **Detection/recovery:** on EOF, close open tool calls as `outcome_unknown`; supervise provider in its own process group and report surviving descendants (kill only on user command); reconcile replay (CR-05); prefer `session/resume` when advertised.
- **Performance:** none significant; replay of very long sessions must be streamed, not buffered.
- **Modification:** PATCH (state model + replay mode).

## S-3. Desktop window closes while an agent is executing

- **Expected (D11):** daemon is a child of the app; closing the window stops the daemon and cancels turns via protocol.
- **Failure:** user intent was "hide window"; work is cancelled; mid-edit agents leave partially modified trees; approvals pending are denied.
- **Weakness:** lifetime coupled to a window, not to user intent; violates macOS convention.
- **Recovery:** none after the fact — cancellation is destructive to the turn.
- **Modification:** **required** — window close ≠ quit; daemon lives for the app lifetime (menu-bar presence while sessions run); quit prompts; optional login agent later (CR-08).

## S-4. Remote connection fails while the user responds to an approval

- **Expected:** "client dropped mid-approval → card timeout expires → deny sent".
- **Failure modes:** (a) user taps Allow; the frame is lost; timeout denies; user believes they allowed. (b) user taps Allow; frame arrives after the provider already cleared the request (turn ended) — undefined. (c) phone retries the Allow after reconnect while desktop already denied — two resolutions.
- **Weakness:** approval resolution is not an idempotent, single-assignment operation with acknowledgement; disconnect is conflated with refusal.
- **Recovery:** approval record on the daemon; client response carries `approval_id` + `command_id`; daemon resolves by compare-and-set and acknowledges with final state; clients reconciling after reconnect read the final state; UI shows "your response was not applied: expired at T".
- **Modification:** **required** (CR-07; candidate D19).

## S-5. User opens thousands of historical events

- **Expected:** client requests ranges; transcript virtualized; 5 000-event budget in S5.
- **Failure:** a 50 000-event session folded into a projection client-side costs seconds and hundreds of MB; Markdown/syntax highlighting of every item on load blocks the main thread.
- **Weakness:** no server-side projection snapshot/paging contract; "client may discard projection and request a range" is not enough for random access (jump to turn 300).
- **Recovery:** daemon serves **item-level projections** (completed items, not raw deltas) by page with stable item IDs; client renders visible window only; highlight lazily; projection snapshots persisted per session every N events.
- **Performance:** proposed budget: time-to-first-visible-page of a 50 000-event session ≤ 300 ms (PROPOSED, unmeasured).
- **Modification:** PATCH.

## S-6. A provider upgrade changes protocol behavior

- **Expected:** unknown version → refuse to start without override; Codex schema drift test in CI.
- **Failure:** provider auto-updates overnight (several do) → every session of that provider is blocked until a Shardrail release; or the user habitually overrides, defeating the check. Subtle semantic changes (e.g., approval default) pass schema checks.
- **Weakness:** binary allow/deny gate; no runtime shadow validation; no semantic canary.
- **Recovery:** compatibility classes (tested / untested-newer / known-bad); tolerant deserialization + structured "unmapped event" notices; on first run of a new version, run the read-only schema comparison (Codex) and flag; approval-path invariants enforced by Shardrail regardless of provider (an approval request that does not arrive is still never an allow).
- **Modification:** **required** (CR-10; candidate D23).

## S-7. Two clients modify the same session simultaneously

- **Expected:** single writer serializes; `command_id` dedups retries.
- **Failure:** desktop sends a new prompt while phone sends cancel for the previous turn; ordering at the daemon makes cancel hit the new turn. Two approval responses with different decisions.
- **Weakness:** commands lack preconditions; approval lacks single-assignment.
- **Recovery:** `expected_turn_id` / `expected_state` preconditions (reject with current state); approval CAS; presence indicator ("also open on phone").
- **Modification:** **required** (CR-16, CR-07).

## S-8. Untrusted workspace with malicious instructions or hooks

- **Expected:** trust `unknown` blocks Claude/Grok starts that load hooks; sandbox defaults not off; approval cards from structured fields.
- **Failure paths not covered:** (a) merely **viewing** the repo runs `git status` → `core.fsmonitor` command executes (E-07); (b) instructions in files induce an agent with weak sandbox to connect to the Shardrail socket / read the bridge secret and self-approve; (c) tool output contains Markdown image URLs that exfiltrate data when rendered, or bidi characters that disguise an approval command; (d) Codex/Hermes project-scoped config not covered by F13.
- **Recovery:** library Git or hardened Git invocation; credentialed clients + agent-peer rejection; sanitized rendering with no remote loads and visible control characters; per-provider project-config table.
- **Modification:** **required** (CR-01, CR-03, CR-04, CR-20).

## S-9. Network interruption causes repeated command submission

- **Expected:** `command_id` makes retries idempotent.
- **Failure:** daemon crash between "write to provider stdin" and "commit" → after restart the client's retry is treated as new (no record) and a second prompt is sent; or the first prompt is lost and the user is told nothing.
- **Weakness:** no write-ahead intent; dedup window unspecified.
- **Recovery:** journal `command_accepted` before dispatch, `command_dispatched` after; retries return the stored result; intent without dispatch confirmation after crash → `delivery_unknown`, human decides.
- **Modification:** PATCH (CR-16).

## S-10. One user operates agents on macOS and remote Linux

- **Expected:** separate daemons and databases; Mac shows remote journal via manual `ssh -L`; no merged inbox.
- **Failure:** approvals pending on the server go unnoticed while the user looks at local sessions; tunnel setup friction; phone needs its own tunnel.
- **Weakness:** no host registry, no client federation, no attention model across hosts.
- **Recovery:** client-side federation over N daemon connections (SSH stdio bridge); global attention inbox keyed by `(host, session)`; per-host health.
- **Modification:** **required** (CR-13, CR-21).

## S-11. Large Git repositories browsed while several agents modify files

- **Expected:** FSEvents/inotify debounce 200 ms; lazy tree; status on event.
- **Failure:** agents writing build outputs generate event storms → repeated full `git status` on a 500k-file repo (seconds each, CPU-bound); inotify watch limits exhausted on Linux; diff shown for the wrong worktree when sessions share a repository (R5).
- **Recovery:** watch only expanded directories + `.git` index/HEAD per worktree; status computation coalesced (at most one in flight, trailing run), incremental where the library supports it; status per session cwd/worktree; show "stale since T" rather than blocking.
- **Performance:** proposed budget: status refresh must not exceed one concurrent computation per worktree; idle CPU ≈ 0 when no FS events.
- **Modification:** PATCH (plus CR-04 security change).

## S-12. Platform runs continuously for several days

- **Expected:** B8 bounds daemon RSS drift over 8 h; no polling.
- **Failure:** WAL never checkpoints because a long-lived reader (client catch-up) holds a snapshot → WAL grows to GBs; journal grows unbounded; WebView memory grows with long transcripts despite virtualization (retained closures, image caches); provider processes leak (excluded from budget but still the user's problem); log files grow.
- **Recovery:** short read transactions, explicit checkpoint policy and WAL size alarm; retention/compaction of deltas into items; WebView memory watchdog with transparent reload of the view; provider RSS shown per session with "restart provider" suggestion when idle; log rotation.
- **Performance:** extend B8 to 72 h soak (PROPOSED) incl. WAL size and WebView footprint.
- **Modification:** PATCH.
