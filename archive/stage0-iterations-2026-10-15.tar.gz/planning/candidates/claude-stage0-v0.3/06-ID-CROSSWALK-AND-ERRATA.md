# 06 — ID Crosswalk and Errata (v0.3)

> **Status:** PROPOSED. Frozen documents (r01 review, r02 review, v0.2) are **not edited**; this file is the authoritative correction layer for readers following references.

## 1. r01 "candidate D" references → final decision IDs

r01 `01-INDEPENDENT-REVIEW.md` cited provisional numbers before the v0.2 register was finalized. Use this table:

| r01 finding | r01 text says | Correct decision |
| --- | --- | --- |
| CR-02 | candidate D16 | **D16** (correct) |
| CR-03 | candidate D21 | **D22** (untrusted rendering) |
| CR-04 | candidate D22 | **D23** (safe Git) |
| CR-06 | candidate D17 | **D17** (correct) |
| CR-07 | candidate D19 | **D19** (correct) |
| CR-09 | candidate D18 | **D18** (correct) |
| CR-10 | candidate D23 | **D24** (compatibility) |
| CR-13 | candidate D24 | **D25** (multi-host) |
| CR-14 | candidate D20 | **D21** (client identity) |
| CR-17 | candidate D25 | **D26** (journal versioning) |
| CR-01 | (no number) | **D20** (replaced in v0.3) |
| CR-16 | (no number) | **D30** |
| CR-11 | (no number) | **D29** |
| CR-05 | (no number) | **D33** (v0.3; v0.2 reconciliation rule superseded) |
| R2-22 | — | **D31** write lease |
| R2-03 | — | **D32** containment |

`02-STRESS-TEST.md` ST-6 (S-6 in that file) cites "candidate D23" → **D24**.

## 2. Errata to frozen documents

| Document | Item | Erratum |
| --- | --- | --- |
| r01 review | CR-02 severity BLOCKING | Revised to **IMPORTANT**: the baseline implies a loopback bridge for the window (RU §4.6 line 193, §10.2); the transport was under-specified, not impossible (R2-25). |
| r01 review | CR-01 framing | Exposure is state integrity and daemon identity, not only secrecy (R2-01); see D20 v0.3. |
| r01 review | CR-04 | Fix incomplete: filter drivers and agent-written `.git/config` in trusted workspaces (R2-02). |
| r01 review | E-03 "pending requests cleared on turn start/complete/interrupt" | Documented only for `item/tool/requestUserInput`; for approvals **INFERRED / REQUIRES FUTURE EXPERIMENT** (R2-27). |
| r01 review | E-10 adapter license UNVERIFIED | License **VERIFIED Apache-2.0** (EV-16 = r02 E2-06). |
| v0.2 consistency | C-04 "providers lose their channel" | Assumption invalid; see D32 (R2-03). |
| v0.2 consistency | C-06 "real control is credential secrecy" | Invalid; see D20 v0.3. |
| v0.2 consistency | C-09 adapter license UNVERIFIED | Resolved: Apache-2.0. Usage terms remain open (U9). |
| v0.2 d13 §5 | "history import is read-only and low risk" | Invalid: journaling imports contradicts baseline §9.1 (R2-17); F15 changed. |
| v0.2 D29 | "personal development builds unaffected" | Not supported by the Anthropic note (R2-12). |
| v0.2 d05 §2 | "Pending approval on turn end … VERIFIED" | Relabel INFERRED (R2-27). |

## 3. Namespaces from v0.3 on

| Old (ambiguous) | New | Meaning |
| --- | --- | --- |
| E-01…E-10 (r01), E2-01…E2-08 (r02) | **EV-01…EV-10**, **EV-11…EV-18** | evidence |
| B-1…B-6 (v0.2 d08 trust boundaries) | **TB-1…TB-6** | trust boundaries |
| S-1…S-12 (r01 stress test) | **ST-1…ST-12** | stress scenarios |
| P1…P6 (handoff packets) | **PK-1…PK-6** | review packets |
| unchanged | F, N, B (budgets), D, R, U, S (spikes), CR, R2, C, X, E0.x…E4.x (epics), T (tasks), M (modules), L2 (outlines), P0…P4 (phases) | — |
