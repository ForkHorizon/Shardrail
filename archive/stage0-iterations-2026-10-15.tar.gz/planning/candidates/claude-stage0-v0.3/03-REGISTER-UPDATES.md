# 03 — Requirement, Budget, Risk and Question Updates (v0.3)

> **Status:** PROPOSED — NOT OWNER-APPROVED. Changes over `../claude-stage0-v0.2/03-RISK-QUESTION-REGISTER.md`; unlisted entries stand. Budgets are proposed, not measured.

## 1. Requirements

| ID | v0.2 | v0.3 | Driver |
| --- | --- | --- | --- |
| F13 | trust gating per provider via project-config table | + **Claude:** in `unknown`/`restricted`, SDK `settingSources: []` (no project hooks, CLAUDE.md, skills), auto memory disabled, claude.ai connectors disabled; channel must be able to pass these (S4). Acceptance: fixture repo with project hooks, CLAUDE.md and a memory-writing prompt produces no hook execution and no memory write. Exact switch names: confirm in S4. | R2-11 |
| F15 | import external history into journal (Phase 1 close) | **Read-through viewing** of external history via official APIs; cached in memory only, never journaled; "continue as new session" via official resume/fork. Phase 2. Imported content untrusted (D22). | R2-17 |
| F17 | "purged session leaves no rows" | Purge procedure per D26; content unrecoverable from DB, WAL and Shardrail-managed copies; exports warned. | R2-16 |
| F19 | — | **NEW** One write-capable session per worktree by default (D31); lease visible; second session read-only or offered a provider-native worktree. | R2-22 |
| F20 | — | **NEW** Orphan providers detected after daemon restart; a session is never resumed while its previous provider process is alive (D32). | R2-03 |
| N4 | paired scoped credentials for every client | Clients `full` (local desktop: peer UID + code-signing identity; SSH-bridged desktop: SSH) and `limited` (paired, challenge-response). Clients authenticate the daemon. | R2-21 |
| N10 | agents cannot use the control plane (best effort) | Approval guarantee stated per session: protected only when the D20 boundary holds; otherwise persistent indicator + explicit acknowledgement. | R2-01 |

## 2. Budgets

| ID | Change | Driver |
| --- | --- | --- |
| B9 | Scope: **Shardrail-owned timers** (daemon + UI code) — none more frequent than 15 s at rest (baseline value). | R2-24 |
| B11 | Scope: **measured total** idle wakeups of the process tree incl. WebKit; ≤ 1/s average (PROPOSED). Presence/keepalive: event-driven or ≥ 15 s. | R2-24 |
| B15 | Measures **bytes written** per turn (incl. checkpoints) as well as bytes retained; written ≤ 3× completed item content (PROPOSED). | R2-29 |
| P1a gate | B1, B4, B7 only; other budgets at Phase 1 close. | R2-23 |

## 3. Risks (new / changed)

| ID | Risk | Severity | Treatment |
| --- | --- | --- | --- |
| R15 (changed) | Agent self-approves **or tampers with Shardrail state / impersonates the daemon** | high | D20 boundary, server auth, S7 extended |
| R18 (changed) | Repository config executes programs via Git (fsmonitor, filter drivers, diff drivers) **in any trust state** | high | D23 |
| R22 (changed) | Replay duplication | low (was medium) | D33 makes it structurally impossible |
| R26 | Orphan provider keeps executing after daemon crash; second process on same provider session | high | D32 |
| R27 | Policy-widening approval granted from a limited client | high | D19 option classes, D21 |
| R28 | Unknown provider request blocks a turn indefinitely | medium | D24 refusal invariant |
| R29 | User believes an allow took effect after provider-side expiry | medium | D19 acknowledgement tracking |
| R30 | Two agents writing the same worktree | high | D31 |
| R31 | Most sandbox profiles may not satisfy the D20 boundary, weakening the product's central safety claim | high (product) | S7 first; honest labelling; U11 |
| R32 | Purged sensitive content survives in copies | medium | D26 |

## 4. Open questions (new)

| ID | Question | Interim / recommendation |
| --- | --- | --- |
| U16 | Ship Phase 1 as daemon + browser UI only (no Tauri)? | **Recommend no**: desktop shell is needed for peer-identity bootstrap, keychain, OS notifications for approvals; browser-only adds a TCP listener where WebView/browser XSS = credential theft. Accept only if S5 rejects Tauri **and** the Swift fallback. |
| U17 | Maximum approval hold bound | PROPOSED default 2 h; staleness re-confirmation at 15 min |
| U18 | Orphan-daemon policy after shell crash | PROPOSED: keep turns ≤ 10 min without any client, then cancel |
| U19 | Manual handoff MVP at Phase 1 close (moved from Phase 4)? | Recommend yes: text bundle edited by user → first prompt of a new session; full Task model stays Phase 4 |
| U11 (changed weight) | Separate Unix user for agents on remote hosts by default | Recommendation strengthened to **default yes on remote hosts** because a shared UID cannot satisfy D20 on Linux without a sandbox |
