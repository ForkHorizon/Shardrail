# 01 — Disposition of Round r02 Findings

> **Candidate:** v0.3 · **Status:** PROPOSED — NOT OWNER-APPROVED · Claude (Opus 5.5), 2026-10-15
> **Source:** `../../reviews/claude-fresh-r02/01-REVIEW.md` (R2-01…R2-32). The r02 review is not edited; this file records what v0.3 does with each finding.
> Marks: **ACCEPT** (adopted as proposed) · **ACCEPT-MOD** (adopted with a stated modification) · **OWNER** (needs an owner decision; v0.3 gives a recommendation) · **REJECT** (not adopted; reason given).

| ID | Sev. | Topic | Mark | v0.3 position (and why, where it differs from r02) | Where |
| --- | --- | --- | --- | --- | --- |
| R2-01 | BLOCKING | D20 protects secrecy, not integrity / daemon identity | ACCEPT-MOD | D20 replaced by an **approval-integrity boundary**: the guarantee holds only when the sandbox (or a separate UID) denies write to Shardrail data/binaries/socket dir and connect to the socket; otherwise sessions carry a persistent "approvals not protected" label and start only after explicit acknowledgement. Challenge-response client proof + server authentication adopted. Modification: the keychain MAC over security rows is moved to **Phase 2 defense in depth**, not P1a, because the sandbox/UID boundary is the real control and the MAC adds complexity without closing the same-UID gap on Linux. | 02 D20 |
| R2-02 | BLOCKING | Safe Git misses filter drivers | ACCEPT | Rule: Shardrail never executes any program named by repository-local config or attributes, in any trust state. CLI fallback dropped. | 02 D23 |
| R2-03 | BLOCKING | Orphan providers after daemon crash | ACCEPT-MOD | New D32 (containment). macOS mechanism left to spike (shim with parent-exit watch vs alternatives); the requirement, not the mechanism, is fixed now. | 02 D32, 04 |
| R2-04 | IMPORTANT | App crash leaves orphan daemon | ACCEPT | Shell connects first (authenticating the daemon), spawns only if absent; orphan-daemon policy is an owner question with a safe default. | 02 D11, U18 |
| R2-05 | IMPORTANT | D18 lacks transitions | ACCEPT | Full transition tables written. | 04 |
| R2-06 | IMPORTANT | ID-based replay reconciliation impossible | ACCEPT | New D33: discard replay when the journal is complete; separate "provider history" view when a gap is known. | 02 D33 |
| R2-07 | IMPORTANT | Unknown server requests hang turns | ACCEPT | Adapter invariant: refuse unknown requests immediately. Codex permission-grant, elicitation, user-input requests added to the card contract. | 02 D24, D19 |
| R2-08 | IMPORTANT | Widening approval options bypass `control_policy` | ACCEPT | Options classified `once` / `widening`; widening only from `full`-scope clients. | 02 D19, D21 |
| R2-09 | IMPORTANT | Provider-side expiry invisible | ACCEPT | Card state `responded_unacked` until the provider's next event for that tool call; withdrawal signals defined. | 02 D19, 04 |
| R2-10 | IMPORTANT | No ACP reject option | ACCEPT | Deny/expiry → `reject_once` if offered, else cancel the turn and answer `cancelled`. | 02 D19 |
| R2-11 | IMPORTANT | Claude trust gating mechanism | ACCEPT-MOD | F13 for Claude restated around SDK `settingSources: []` plus disabling auto memory and connectors. The exact switch names cited by r02 are marked "confirm in S4" — r02 verified the loading behavior, not every switch. | 03 F13 |
| R2-12 | IMPORTANT | D29 personal-build carve-out | ACCEPT | Carve-out removed from the recommendation; owner may reinstate it only as "owner's own machine, never distributed". Branding rule added. | 02 D29 |
| R2-13 | IMPORTANT | Claude question on Phase 1 critical path | ACCEPT | Edges decoupled; P1 close = "Claude included or formally excluded". | 05 |
| R2-14 | IMPORTANT | Off-by-one CR→D references; ID collisions | ACCEPT | Crosswalk + errata; new namespaces from v0.3 on. r01 not edited. | 06 |
| R2-15 | MINOR | Module dependency cycles | ACCEPT | Ports defined; table authoritative. | 05 §4 |
| R2-16 | IMPORTANT | Purge vs backups | ACCEPT | No automatic journal backups by default; purge procedure defined. | 02 D26 |
| R2-17 | IMPORTANT | F15 contradicts §9.1 | ACCEPT | F15 becomes read-through viewing (memory cache only), moved to Phase 2. | 03 F15, 05 |
| R2-18 | IMPORTANT | Runtime schema generation reverses §7.3 | ACCEPT | Optional and diagnostic-only; recorded as contradiction C-15. | 02 D24, 90 |
| R2-19 | IMPORTANT | Warn-and-run should be strictest | ACCEPT | `untested-newer` = strictest sandbox, no widening options, no allow-all. | 02 D24 |
| R2-20 | IMPORTANT | Cursors after DB recreation | ACCEPT | `journal_epoch` in handshake and cursors; `HostId` regenerated when a copied data dir is detected (epoch + machine binding). | 02 D26 |
| R2-21 | IMPORTANT | Pairing bootstrap; SSH redundancy | ACCEPT-MOD | Local desktop admitted by peer UID + code-signing identity of the peer (REQUIRES FUTURE EXPERIMENT for audit-token-based checks); SSH-bridged desktop admitted by SSH. Pairing only for `limited` clients. | 02 D21 |
| R2-22 | IMPORTANT | Two write-capable agents on one worktree | ACCEPT | New D31 write lease + F19. | 02 D31 |
| R2-23 | IMPORTANT | P1a still too large | ACCEPT-MOD | P1a cut as proposed. The "browser-only Phase 1, no Tauri" alternative is recorded as owner question U16 with a recommendation **against** it (loses peer-identity bootstrap, OS notifications, keychain; adds TCP and XSS→credential exposure). | 05, U16 |
| R2-24 | MINOR | B11 vs B9 | ACCEPT | B9 = Shardrail timers; B11 = measured total wakeups incl. WebKit. | 03 |
| R2-25 | IMPORTANT | CR-02 overstated | ACCEPT | CR-02 severity revised to IMPORTANT (errata); D16 becomes a trade-off decided by S5; credential delivery to WebView specified; D22 is a prerequisite. | 02 D16, 06 |
| R2-26 | IMPORTANT | Unbounded hold for Codex | ACCEPT | Mandatory upper bound (U17) and re-confirmation when stale or when workspace HEAD/diff changed. | 02 D19 |
| R2-27 | MINOR | E-03 overstated | ACCEPT | Relabelled INFERRED / REQUIRES FUTURE EXPERIMENT (S1). | 06 |
| R2-28 | MINOR | Delta before `item_started` | ACCEPT | Delta frames carry provisional item metadata. | 02 D17 |
| R2-29 | MINOR | Quadratic checkpoints | ACCEPT | Append-only checkpoint chunks; B15 measures bytes written. | 02 D17, 03 |
| R2-30 | MINOR | P1a gate omits F8, F10 | ACCEPT | Added. | 05 |
| R2-31 | QUESTION | Handoff vs history import order | OWNER | Recommend a manual handoff MVP (edited text bundle → first prompt) at Phase 1 close; F15 to Phase 2. | 05, U19 |
| R2-32 | MINOR | Perpetual upcasting | ACCEPT | Forward migration after a temporary pre-migration copy; `schema_version` kept for detection. | 02 D26 |
| (D30 note) | MINOR | `command_id` retention for non-session commands | ACCEPT | Host-level command log, bounded retention (PROPOSED 24 h). | 02 D30 |

**Rejected:** none. Where v0.3 differs from r02 it is in staging (R2-01 MAC, R2-23 browser-only) or evidence labelling (R2-11, R2-21), not in direction.
