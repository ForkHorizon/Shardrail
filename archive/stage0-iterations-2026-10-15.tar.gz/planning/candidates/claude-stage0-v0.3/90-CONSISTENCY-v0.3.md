# 90 — Consistency Check and Self-Review (v0.3)

> **Status:** PROPOSED · Claude (Opus 5.5), 2026-10-15. Continues the C-list of `../claude-stage0-v0.2/90-CONSISTENCY-REPORT.md` (C-01…C-14 stand unless corrected in `06-ID-CROSSWALK-AND-ERRATA.md`).

## 1. New or newly recorded contradictions

| ID | Relationship | Contradiction | Resolution in v0.3 | Status |
| --- | --- | --- | --- | --- |
| C-15 | D24 ↔ baseline §7.3 | Runtime schema generation vs "reference is the saved file" | Generation optional, diagnostic-only; saved reference remains primary | resolved (recommended) |
| C-16 | F15 ↔ baseline §9.1 | Journaling imported transcripts copies provider data | F15 = read-through view, memory cache only | resolved |
| C-17 | F17 ↔ D26 backups | Purge vs backup copies | No automatic backups; defined purge procedure | resolved |
| C-18 | B9 ↔ B11 | Two idle targets with no scope split | B9 = Shardrail timers; B11 = measured process-tree wakeups | resolved |
| C-19 | Backlog ↔ stop rule | Claude/U9 on Phase 1 critical path | Edges removed; "included or formally excluded" | resolved |
| C-20 | D11 window-close keeps agents ↔ U18 orphan policy cancels turns | Both are "no window" situations | Different causes: window close = app alive (menu bar, notifications); orphan = shell crashed (no UI path at all). Policies differ deliberately | resolved (documented) |
| C-21 | D31 write lease ↔ provider-native worktrees | Second-session worktree depends on provider support (only Grok documented) | Fallback = read-only second session; per-provider worktree support from spikes | open (spike) |
| C-22 | D20 boundary ↔ product safety claim | If S7 shows common profiles do not deny Shardrail paths, most sessions are "not protected" | Honest labelling; U11 default for remote; owner must accept the claim scope after S7 | **open — highest product risk** |
| C-23 | D32 macOS helper ↔ B1/B11 | One extra helper process per provider group | Helper is tiny and event-driven; measured in its own column; mechanism chosen in spike | open (measure) |
| C-24 | D21 code-signing bootstrap ↔ development builds | Unsigned dev builds cannot pass a code-signing peer check | Dev builds use an explicit developer-mode admission flag stored outside agent-writable paths; never enabled in release builds | resolved (recommended) |
| C-25 | D19 re-confirmation ↔ mobile UX | Re-confirmation adds friction to remote approvals | Re-confirmation only when stale or workspace changed; shows why | accepted trade-off |

## 2. Check of r02's "wrong or overstated" list
All eight items are accepted and recorded as errata (`06` §2). None of r01's or v0.2's text was edited.

## 3. Adversarial self-review of v0.3

- **Did v0.3 over-accept r02?** Every finding was adopted. Two were staged rather than adopted whole (R2-01 MAC to Phase 2; R2-23 browser-only Phase 1 turned into owner question U16 with a "no" recommendation). The risk is that a second Claude review shares blind spots with the first; the next reviewer should preferably be a different model family.
- **Complexity balance.** v0.3 adds D31, D32, D33 and transition tables, but removes from P1a: four scopes → one, pairing, browser listener, wire codegen, fake app-server, history import, five budget gates → three, perpetual upcasting, automatic backups. Net P1a scope is smaller than v0.2.
- **D20 remains the weakest point.** v0.3 makes the claim honest instead of strong. If S7 is negative, Shardrail's approval protection against a compromised agent is only as good as the provider sandbox, and on a shared UID without a sandbox there is none. This is a property of running agents as the user, not a Shardrail defect, but the product must say it.
- **New unverified dependencies.** Code-signing peer identification on macOS (audit token), parent-exit helper on macOS, Claude switch names (`settingSources`, auto-memory and connector disablement through the adapter), ACP reject-option prevalence.
- **Still unread primary sources.** Grok/xAI docs; Hermes docs not re-read after r01; Tauri 3 status.

## 4. Readiness
v0.3 is ready for: owner decisions (U9, U10/U17, U11, U13, U14, U16, U18, U19, U3, U6) and one more independent review focused on D20, D23, D32 and the transition tables. It is not ready for Level 2 detail on L2-01/L2-04 until S7 and the D32 mechanism spike exist.
