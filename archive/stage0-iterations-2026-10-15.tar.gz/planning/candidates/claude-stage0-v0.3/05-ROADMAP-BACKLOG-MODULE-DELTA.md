# 05 — Roadmap, Backlog and Module Changes (v0.3)

> **Status:** PROPOSED — NOT AUTHORIZED. Changes over `../claude-stage0-v0.2/d13-roadmap.md`, `../../backlog/proposed/BACKLOG.md` and `../../level-2/proposed/`. Those files are not edited; apply these deltas when the owner accepts v0.3.
> ID note: from v0.3, packets are `PK-n`, stress scenarios `ST-n`; phases keep `P0…P4`, spikes keep `S1…S8`, budgets keep `B1…`.

## 1. Phase 0 spike additions

| Spike | Added in v0.3 | Driver |
| --- | --- | --- |
| S1–S4 | "kill the daemon, observe provider and the running tool" | D32 |
| S1 | does Codex clear pending **approvals** at turn end/interrupt (only `requestUserInput` documented) | R2-27 |
| S1 | behavior on unknown/refused server requests; permission-grant and elicitation flows | D24, D19 |
| S2, S3 | ACP reject option presence; `cancelled` answer path | D19 |
| S4 | channel can pass `settingSources: []`, disable auto memory and connectors; API-key auth path | F13, D29 |
| S5 | relay vs loopback (latency, code size, credential delivery to WebView) | D16 |
| S7 | sandbox denial of **write** to data dir/binaries and **bind/connect** to socket dir, per provider profile; code-signing peer check feasibility | D20, D21 |
| S8 | full fixture list incl. filter drivers and `.git/config` rewritten by an agent | D23 |

## 2. Phase 1 slices (replaces v0.2 d13 §2 table)

| Slice | Content | Gate |
| --- | --- | --- |
| 1a | **one** local desktop client, **one** transport (per S5); `full` scope only; no browser listener; journal schema (D27) with hand-written wire types; **one** fake ACP agent; daemon core + D32 containment; journal (tiers, epoch); engine with v0.3 transition tables; approvals (D19 incl. option classes, ack tracking); trust; safe Git view (D23); write lease (D31); one ACP provider | F2–F10, F12, F13, F18, F19, F20 on fixtures; **B1, B4, B7** |
| 1b | Codex adapter; fake app-server agent; D24 refusal invariant | Codex fixtures + live smoke |
| 1c | second ACP provider | fixtures + live smoke |
| 1d | Claude per S4 **if** U9 resolved; otherwise formally excluded by recorded decision | fixtures + smoke, or exclusion record |
| P1 close | manual handoff MVP (U19, recommended); budget report | baseline gate + B11, B13, B14; "Claude included **or** formally excluded" |

Moved out of Phase 1: F15 (now read-through viewing) → Phase 2; browser client, `limited` scope, pairing → Phase 2/3.

## 3. Backlog deltas (`backlog/proposed/BACKLOG.md`)

| Item | Change |
| --- | --- |
| §5 edge `E04 --> E06` | **remove**; E0.6 (S7) depends only on the providers selected for P1a |
| §2 P1a dependency | "P0 S2/S3/S5/S7/S8" retained; S4/U9 explicitly **not** a P1a dependency |
| E1.16 | becomes Phase 2 epic "History read-through view", per provider, no journaling; not a P1-close dependency |
| E1.15 | parallel, optional for P1 close (include or exclude decision) |
| P1 close gate | "Claude included or formally excluded" |
| E1.8 | P1a: one transport, `full` scope only; pairing/`limited` scope → new E2.5 (Phase 2) |
| E1.1 | journal schema only in P1a; wire codegen when a second client type appears |
| E1.2 | P1a: one fake ACP agent; fake app-server moves to 1b (E1.13) and must include permission-grant, elicitation, user-input requests |
| E1.3 | add D32 containment (survivor detection, parent-death handling) |
| E1.9 | D23 rule (no repo-named programs in any trust state); T1.9.1 fixture list = S8 list |
| **E1.18 (new)** | Write lease per worktree (D31), Phase 1a |
| **E1.19 (new)** | Manual handoff MVP (U19), Phase 1 close, if owner agrees |
| **E2.5 (new)** | Paired `limited` clients (browser), challenge-response, Phase 2 |
| E4.1 | full Task model stays Phase 4 |
| T1.7.1 | add option classes, ack tracking, reject/cancel mapping, hold bound, re-confirmation |
| T1.8.1 | becomes Phase 2 (E2.5) |
| **T1.3.1 (new)** | kill-daemon fixture: provider group terminated (Linux) / helper terminates group (macOS); restart shows no survivors or `orphan_alive` |
| **T1.5.3 (new)** | transition-table conformance tests generated from `04-STATE-TRANSITIONS.md` (every cell, incl. impossible cells → notice) |

Revised critical path: G0 → P0 (S5, S7, S8 longest) → E1.1 (journal schema) → E1.4 → E1.5 → E1.6 → E1.17 → G2. Claude (E0.4/E1.15) is **off** the critical path.

## 4. Module index fixes (`level-2/proposed/00-MODULE-INDEX.md`, R2-15)

- **Ports break the cycles:** `ApprovalStore` (owned by M09, implemented by M04); `NotificationSink` (owned by M09/M03, implemented by M10). Then M09 depends on M03 (events) and ports only; M10 depends on M09 via `NotificationSink` implementation, not the reverse.
- M01 depends on M04 (startup opens the journal) and M05.
- M10 depends on M11 (workspace queries) — add to table.
- The §1 table is authoritative; the §2 graph must be regenerated from it.
- New responsibilities: M05 gets D32 containment; M09 gets option classes and ack tracking; M11 gets D31 write lease and the D23 rule; M10 gets server authentication and (Phase 2) pairing.

## 5. Level 2 outline impacts

| Outline | Required change |
| --- | --- |
| L2-01 | D32 containment; connect-first and orphan-daemon policy (D11/U18); startup step "detect survivors" before marking sessions |
| L2-02 | use `04-STATE-TRANSITIONS.md`; D33 replay rule (invariant 5 now structural); `journal_epoch`; append-only checkpoints; provisional item metadata; forward migration; purge procedure |
| L2-03 | refusal invariant for unknown requests; ACP completion synthesis; option classification output; untested-newer strict mode; D33 |
| L2-04 | D20 replaced (boundary + label + acknowledgement); option classes; ack tracking; reject/cancel mapping; hold bound + re-confirmation; new request kinds in card contract; §7 already corrected for restart, extend with orphan case |
| L2-05 | two scopes; bootstrap via peer UID + code-signing; SSH = admission; challenge-response; server authentication; `journal_epoch` in handshake; WebView short-lived token (D16); pairing only for `limited` clients |
