# 04 — Session State Transition Tables (D18, v0.3)

> **Status:** PROPOSED — normative for L2-02 detailed planning once approved. Replaces the diagram in `../claude-stage0-v0.2/d04-system-and-process.md` §3.
> Rule for unlisted (state, event) cells: **impossible** → record a `notice` with both values, do not change state. Timers named `T_*` are PROPOSED defaults, configurable.

## 1. Process dimension (per provider process)

| From \ Event | spawn requested | spawn ok | spawn failed | exit / stdio EOF | terminate requested | daemon restart finds pid alive | orphan exits / user terminates |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `none` | `spawning` | — | — | — | — | — | — |
| `spawning` | — | `alive` | `exited(spawn_error)` | `exited(code)` | `terminating` | — | — |
| `alive` | — | — | — | `exited(code)` | `terminating` | — | — |
| `terminating` | — | — | — | `exited(code)` | — | — | — |
| `exited` | `spawning` (resume/restart, only if no `orphan_alive` for this provider session) | — | — | — | — | — | — |
| *(after restart)* | — | — | — | — | — | `orphan_alive` (D32) | — |
| `orphan_alive` | **refused** | — | — | — | `terminating` (signal recorded pgid) | — | `exited(orphan)` |

`terminating` escalation: protocol cancel → wait `T_grace` (PROPOSED 10 s) → SIGTERM to group → wait 5 s → SIGKILL to group.

## 2. Link dimension (protocol session with the provider)

| From \ Event | process `alive` | initialize ok | initialize error / timeout `T_init` | protocol error (bad frame, unknown response id) | resume/load requested | resume/load complete | resume/load failed | process exits |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `none` | `initializing` | — | — | — | — | — | — | — |
| `initializing` | — | `ready` | `desynced` | `desynced` | — | — | — | `none` |
| `ready` | — | — | — | `desynced` | `resuming` | — | — | `none` |
| `resuming` | — | — | — | `desynced` | — | `ready` | `desynced` | `none` |
| `desynced` | — | — | — | — | — | — | — | `none` |

Recovery from `desynced` is only by user action "restart provider": process → `terminating` → `exited` → `spawning` → link `initializing` → `resuming` (D33).

## 3. Turn dimension (one active turn per session)

| From \ Event | prompt dispatched | turn finished (provider) | cancel requested | cancel acknowledged | `T_cancel` elapsed (PROPOSED 30 s) | no provider event ≥ `T_stall` (15 min) **and** no pending approval | any provider event | process exits / link `desynced` |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `idle` | `running` | — | — | — | — | — | — | — |
| `running` | — | `idle` + outcome (`completed` / `failed` / `refused`) | `cancelling` | — | — | `stalled` | `running` | `idle` + `interrupted`; open tools → `outcome_unknown` |
| `stalled` | — | `idle` + outcome | `cancelling` | — | — | — | `running` | `idle` + `interrupted` |
| `cancelling` | — | `idle` + `cancelled` | — | `idle` + `cancelled` | process → `terminating`; turn stays `cancelling` | — | `cancelling` | `idle` + `cancelled_by_termination` |

On daemon restart every non-`idle` turn becomes `idle` + `unknown_after_restart`. `turn_outcome` is durable and shown in the transcript.

## 4. Approval record (per request; D19)

| From \ Event | authorized response (once/deny; widening needs `full`) | provider acknowledges (next event for tool call consistent with response) | provider withdraws (terminating update, turn end, JSON-RPC error) | expiry policy fires | stale threshold / workspace changed | turn cancelled | daemon restart |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `pending` | `responded_unacked` (CAS: first wins) | — | `withdrawn` | `expired` → send reject_once or cancel turn (D19.3) | `pending` + `needs_reconfirmation` flag | `withdrawn` (answer `cancelled`) | `withdrawn(daemon_restart)` |
| `responded_unacked` | rejected (typed error, final state) | `allowed` / `denied` | `withdrawn` | — | — | `withdrawn` | `withdrawn(daemon_restart)` |
| `allowed`/`denied`/`expired`/`withdrawn` | rejected (typed error, final state) | — | — | — | — | — | — |

An allow on a `needs_reconfirmation` record requires an explicit second confirmation in the same client action.

## 5. Delivery dimension (per mutating command; D30)

| From \ Event | journaled `command_accepted` | journaled `command_dispatched` | provider confirms (e.g., `turn_started`, response) | daemon restart | user: resend | user: discard | user: mark as delivered |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `none` | `accepted` | — | — | — | — | — | — |
| `accepted` | — | `dispatched` | — | `unknown` | — | — | — |
| `dispatched` | — | — | `confirmed` | `unknown` | — | — | — |
| `unknown` | — | — | — | — | new command (new `command_id`); old → `resolved_resent` | `resolved_discarded` | `resolved_confirmed` |

## 6. Derived badge (replaces v0.2 precedence)

`orphan provider running` > `needs approval` > `approvals not protected` (D20, persistent overlay) > `degraded` (process `exited` or link `desynced`) > `delivery unknown` > `resuming` > `stalled` > `cancelling` > `running` > `idle`. Client-local overlay: host `disconnected`.
