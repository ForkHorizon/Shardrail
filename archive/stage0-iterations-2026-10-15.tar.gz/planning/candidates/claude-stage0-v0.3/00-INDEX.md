# Shardrail Architecture Candidate v0.3 — Claude Revision after Round r02

> **Status:** PROPOSED CANDIDATE — NOT OWNER-APPROVED. Implementation NOT authorized. Stage 0.
> **Author:** Claude (Opus 5.5), 2026-10-15.
> **Layering:** v0.3 is a **delta over v0.2** (`../claude-stage0-v0.2/`), which is a delta over the Grok baseline (`../../level-1/`). v0.2, the r01 review and the r02 review are unchanged. Where v0.3 says nothing, v0.2 stands; where v0.2 says nothing, the baseline stands.
> **Input:** fresh-context review `../../reviews/claude-fresh-r02/` (32 findings: 3 BLOCKING, 21 IMPORTANT, 7 MINOR, 1 QUESTION).

## Reading order

| # | Document | Purpose |
| --- | --- | --- |
| 1 | [01-R2-DISPOSITION](01-R2-DISPOSITION.md) | What v0.3 does with each R2 finding, and why |
| 2 | [02-DECISION-REGISTER-v0.3](02-DECISION-REGISTER-v0.3.md) | Changed decisions (D11, D16–D21, D23, D24, D26, D27, D29, D30) and new D31–D33 |
| 3 | [03-REGISTER-UPDATES](03-REGISTER-UPDATES.md) | F13, F15, F17, F19, F20, N4, N10; B9, B11, B15; R26–R32; U16–U19 |
| 4 | [04-STATE-TRANSITIONS](04-STATE-TRANSITIONS.md) | Normative transition tables for D18 |
| 5 | [05-ROADMAP-BACKLOG-MODULE-DELTA](05-ROADMAP-BACKLOG-MODULE-DELTA.md) | Spike additions, smaller P1a, Claude decoupled, backlog/module/L2 impacts |
| 6 | [06-ID-CROSSWALK-AND-ERRATA](06-ID-CROSSWALK-AND-ERRATA.md) | CR→D crosswalk, errata to frozen docs, new ID namespaces |
| 7 | [90-CONSISTENCY-v0.3](90-CONSISTENCY-v0.3.md) | C-15…C-25, self-review, readiness |

## Change log v0.2 → v0.3 (summary)

| Area | v0.2 | v0.3 | Mark |
| --- | --- | --- | --- |
| Approval protection | credential secrecy (D20) | integrity boundary via sandbox/separate UID + honest "not protected" label | REPLACE |
| Git safety | library or hardened CLI, unknown workspaces | never execute repo-named programs, all trust states, no CLI | MODIFY |
| Process lifetime | providers assumed to die with daemon | D32 containment, `orphan_alive` | NEW |
| Approvals | CAS + expiry policy | + once/widening, ack tracking, ACP reject mapping, bounded hold, re-confirmation | MODIFY |
| Replay | ID reconciliation | D33 discard-or-separate-view | REPLACE |
| Unknown requests | → notice | immediate refusal + notice | MODIFY |
| Untested provider versions | warn-and-run | warn-and-run in strictest mode | MODIFY |
| Clients | four scopes, pairing for all | `full`/`limited`; peer-identity/SSH admission; pairing only for limited | MODIFY |
| Desktop transport | relay adopted | relay vs loopback decided by S5; D22 prerequisite | MODIFY |
| Concurrency on a worktree | not addressed | D31 write lease | NEW |
| Journal | backups, upcasting forever | epoch, no auto backups, purge procedure, forward migration | MODIFY |
| History import | journaled, Phase 1 | read-through, Phase 2 | MODIFY |
| Claude | personal builds unaffected | API key in all builds until U9; branding; off critical path | MODIFY |
| Phase 1a | large | one client, one transport, one scope, one fake agent, 3 budgets | MODIFY |

## Owner decisions needed (v0.3 additions in bold)

U9 Claude terms · U10/**U17** approval expiry and hold bound · U11 separate agent user (now recommended default on remote) · U13 Rust vs Go · U14 repo visibility · U3 license · U6 continuous Mac · **U16 browser-only Phase 1 (recommend no)** · **U18 orphan-daemon policy** · **U19 manual handoff MVP at Phase 1 close (recommend yes)** · D31 write-lease default.
