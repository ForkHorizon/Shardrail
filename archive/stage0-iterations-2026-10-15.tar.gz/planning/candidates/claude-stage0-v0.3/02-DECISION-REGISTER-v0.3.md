# 02 — Decision Register v0.3 (changes over v0.2)

> **Status:** PROPOSED — NOT OWNER-APPROVED. Only decisions that change in v0.3 are listed; every other entry of `../claude-stage0-v0.2/02-DECISION-REGISTER.md` stands. IDs are preserved; new IDs D31–D33.
> Evidence IDs from v0.3 on: `EV-` prefix. EV-01…EV-10 = r01 E-01…E-10; EV-11…EV-18 = r02 E2-01…E2-08 (see `06-ID-CROSSWALK-AND-ERRATA.md`).

## Summary

| ID | v0.2 | v0.3 | Driver |
| --- | --- | --- | --- |
| D11 | lifetime = app | + connect-first; orphan-daemon policy | R2-04 |
| D16 | relay adopted | relay **or** loopback decided by S5; credential delivery specified | R2-25 |
| D17 | tiers | + provisional item metadata; append-only checkpoints; ACP completion synthesis | R2-06, R2-28, R2-29 |
| D18 | dimensions | full transition tables (`04-STATE-TRANSITIONS.md`) | R2-05 |
| D19 | approval record | + once/widening; ack tracking; ACP reject mapping; bounded hold | R2-07–R2-10, R2-26 |
| D20 | control-plane isolation (secrecy) | **REPLACE**: approval-integrity boundary | R2-01 |
| D21 | four scopes, pairing | two scopes; bootstrap; pairing only for limited clients | R2-08, R2-21, R2-23 |
| D23 | safe Git | never execute repo-named programs, all trust states, no CLI fallback | R2-02 |
| D24 | compatibility classes | + refuse unknown requests; strictest policy for untested; schema generation diagnostic-only | R2-07, R2-18, R2-19 |
| D26 | versioning, retention, backups | + `journal_epoch`; no auto backups; purge procedure; forward migration | R2-16, R2-20, R2-32 |
| D27 | schema-first everywhere | journal schema first; wire types hand-written until a second client | R2-23 |
| D29 | API-key-only in product builds; personal builds unaffected | carve-out removed; branding rule | R2-12 |
| D30 | command intent | + host-level command log retention | r02 §4.2 |
| D31 | — | **NEW** write lease per worktree | R2-22 |
| D32 | — | **NEW** provider lifetime containment | R2-03 |
| D33 | — | **NEW** replay handling | R2-06 |

## Records

**D11 — Daemon lifetime (MODIFY again)**
- Add: the shell always **connects first**, authenticating the daemon (D21 server authentication); it spawns a daemon only if none answers. A live daemon whose shell crashed ("orphan daemon") follows policy U18. Recommended default: keep running turns for up to 10 minutes without any client; after that, cancel turns (pending approvals expire per D19 and are never allowed). Rationale: nobody can see approvals while no client is attached.
- Confidence: high. Owner: U18.

**D16 — Client transport for the desktop (MODIFY → trade-off)**
- One wire protocol: retained. Desktop path: Tauri byte relay **or** loopback WebSocket, chosen in S5 on latency, code size and credential exposure. Both need a defined way to deliver a credential to WebView JavaScript; in both, script injection into the WebView means credential theft. Therefore **D22 is a prerequisite of D16**, and the WebView gets a short-lived session token minted by the shell, never the long-lived credential.
- r01 CR-02 severity revised to IMPORTANT (errata). Confidence: medium.

**D17 — Tiered events (MODIFY)**
- Delta frames carry provisional item metadata (`item_id`, kind, session, turn), so clients can render before `item_started` is committed (R2-28).
- In-progress checkpoints are **append-only chunks** (never rewrite the full text); compaction joins chunks into the completed item (R2-29).
- ACP has no "item completed" for message text; the adapter synthesizes completion when the update type changes, a tool call starts, or the `session/prompt` response arrives (R2-06).

**D18 — Session state (MODIFY)**
- Normative transition tables in `04-STATE-TRANSITIONS.md`; adds `turn_outcome`, link state `resuming`, process state `orphan_alive`, cancel escalation, `delivery_unknown` resolution.

**D19 — Approval record (MODIFY)**
1. **Option classes:** every provider option is classified `once` (allow once, deny once) or `widening` (ACP `allow_always`/`reject_always` where it persists a rule, Hermes `allow_always`, Codex `acceptForSession`, `acceptWithExecpolicyAmendment`, `item/permissions/requestApproval` with `scope: "session"`). `widening` requires a `full`-scope client (D21). `limited` clients see once/deny only.
2. **Acknowledgement:** after a client responds, the record is `responded_unacked` until the provider's next event for that tool call; withdrawal is inferred from (a) an update terminating the same tool call without the expected effect, (b) turn end, (c) a JSON-RPC error on the response. The UI never shows "allowed" before acknowledgement.
3. **Deny/expiry mapping:** select a `reject_once`-class option if offered; otherwise cancel the turn (`session/cancel`) and answer the pending request with `cancelled` (EV-11).
4. **Hold bound:** `hold_until_provider_limit` replaced by `hold(max = owner-set bound, U17)`. An allow is re-confirmed when older than a staleness threshold (PROPOSED 15 min) or when workspace HEAD or diff changed since the request.
5. New request kinds in the card contract: permission grants (network/filesystem), MCP elicitation, tool user-input (EV-13).
- Invariant unchanged: nothing becomes allow without an explicit authorized human action.

**D20 — Approval-integrity boundary (REPLACE)**
- Statement: Shardrail's approval guarantee holds for a session **only if** the agent cannot (a) write Shardrail's data directory, (b) modify Shardrail or provider binaries Shardrail launches, (c) bind or connect to Shardrail's socket directory. This is enforced by the provider sandbox profile (to be verified per profile in S7, extended to writes and bind) or by running agents as a separate Unix user (U11).
- Sessions that do not meet the boundary show a persistent **"approvals not protected from this agent"** indicator and start only after an explicit acknowledgement (same treatment as allow-all).
- Defense in depth (not claimed as the boundary): environment scrubbing; peer-ancestry rejection; challenge-response client proof (no bearer secrets on the socket); **server authentication** (client verifies daemon key pinned at first admission; SSH host key for remote); provider binary path and, where available, code-signing identity shown and change-flagged.
- Deferred to Phase 2: integrity MAC over security-relevant rows with a keychain-held key on macOS (does not help on a shared-UID Linux host).
- Consequence (C-22): if S7 shows common profiles do not deny these paths, the product cannot claim protected approvals for those profiles; this must be stated in UI and documentation.
- Confidence: high on the analysis; enforcement REQUIRES FUTURE EXPERIMENT.

**D21 — Client identity and scopes (MODIFY)**
- Two scopes for v1: **`full`** (local desktop; SSH-bridged desktop) and **`limited`** (paired browser and mobile: observe, prompt, respond with once/deny).
- Bootstrap: local desktop admitted by peer UID **and** code-signing identity of the peer process (macOS; audit-token-based check REQUIRES FUTURE EXPERIMENT); credential then stored in keychain. SSH-bridged desktop admitted by SSH authentication; no second credential.
- Pairing (one-time code from a `full` client) only for `limited` clients. Proof is challenge-response.
- Policy-weakening actions and `widening` approval options require `full`.

**D23 — Safe Git (MODIFY)**
- Rule: **Shardrail never executes any program named by repository-local configuration or attributes, in any trust state.**
- Library-based status/diff/tree with fsmonitor, hooks, filter drivers (`clean`/`smudge`/`process`), external diff and textconv disabled. Note: gix-filter supports external filters (EV-18), so "use a library" is not sufficient by itself. Files whose comparison would require a filter show "content check skipped (filter)".
- No hardened-CLI fallback in product builds.
- S8 fixtures: `core.fsmonitor`, `filter.*.clean`, `filter.*.process`, `diff.*.textconv`, `diff.external`, `core.hooksPath`, and an agent rewriting `.git/config` mid-session.

**D24 — Provider compatibility (MODIFY)**
1. Every **unknown server request** gets an immediate refusing response (decline / empty grant / JSON-RPC error) and a `notice`; unknown notifications become `notice`.
2. `untested-newer` runs with the strictest supported sandbox, no `widening` options, no allow-all, until marked `tested`.
3. Runtime schema generation (Codex) is optional and diagnostic-only; the bundled reference + tolerant parsing + capability negotiation are the primary guard. Recorded as C-15 (reverses baseline §7.3 only in this diagnostic form).

**D26 — Journal versioning, retention, recovery (MODIFY)**
- `journal_epoch` (random per DB creation) in handshake and cursors; mismatch forces a full resync. A data dir copied to another machine is detected (machine binding) and gets a new `HostId`.
- No automatic journal backups by default; user-initiated export only (exports carry a warning that purge cannot reach them).
- Purge (F17): delete rows → `secure_delete` on → WAL checkpoint (truncate) → incremental VACUUM; acceptance = content not recoverable from DB, WAL, or Shardrail-managed backups.
- Schema evolution: forward migration of stored rows after a temporary pre-migration copy, which is deleted after verification; `schema_version` retained for detection; no perpetual upcasting.

**D27 — Schema-first (MODIFY)**
- Journal event schema first (it is long-lived). Wire protocol types hand-written until a second client type exists (browser or mobile), then generated.

**D29 — Claude terms (MODIFY)**
- Remove "personal builds unaffected". Recommendation: until U9 is answered, Claude runs only with user-configured API-key authentication in any build. Owner may decide a narrower exception ("owner's own machine, never distributed") explicitly.
- UI naming per SDK branding rules: the provider is labelled "Claude Agent" (or "Claude" inside an "Agents" menu), never "Claude Code".
- Adapter license verified Apache-2.0 (EV-16); usage-terms question unchanged.

**D30 — Command intent (MODIFY)**
- Non-session commands (create session, pairing, host operations) are recorded in a host-level command log with bounded retention (PROPOSED 24 h).

**D31 — Write lease per worktree (NEW)**
- At most one write-capable session per worktree by default. A second session on the same worktree starts read-only, or the user is offered a provider-native worktree where available (Grok `x.ai/git/worktree/*`; others per spike). The UI shows which session holds the lease; the lease is released at session close or by explicit transfer.
- Limitation: Shardrail cannot stop an agent outside its sandbox from writing; the lease governs which sandbox profile Shardrail selects (`read-only` vs `workspace-write`).
- Evidence: baseline §2.4 two-writer argument; R2-22. Confidence: high. Owner: approve default.

**D32 — Provider lifetime containment (NEW)**
- Durable `provider_spawned` event: pid, pgid, process start time, binary path.
- On daemon start: enumerate recorded groups; survivors become `orphan_alive`; UI offers "terminate"; a session whose old process is alive is **never** resumed into a second process.
- Linux: parent-death signal set before exec, plus cgroup-based kill in the systemd unit.
- macOS: a small Shardrail helper per provider group that terminates the group when its parent daemon exits (mechanism — pipe EOF or process-exit watch — chosen in spike).
- Spikes S1–S4 add "kill daemon, observe provider and running tool".
- Confidence: high on the requirement; mechanism REQUIRES FUTURE EXPERIMENT.

**D33 — Replay handling (NEW; supersedes the v0.2 reconciliation rule)**
- Prefer `session/resume` (no replay) when advertised (EV-12).
- On `session/load`: if the journal has no known gap for the session, **discard** replayed updates (used only to restore provider state) and journal one `provider_reloaded` marker.
- If a gap is known (crash loss), present the replay as a separate, clearly labelled **provider history** view; never merge it into the journal.
- L2-02 invariant "replay never duplicates" holds trivially under this rule.
