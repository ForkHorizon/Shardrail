# d13 — Global Delivery Roadmap (delta vs baseline 13)

> **Status:** PROPOSED · Baseline: `level-1/13-global-delivery-roadmap.md` (§16). Phase identifiers 0–4 preserved; Phase 1 sliced into 1a–1d. **Nothing here authorizes execution**; Phase 0 requires explicit owner authorization after Stage 0 ends.
> Detailed epics: `backlog/proposed/BACKLOG.md`.

## 1. Phase 0 — spikes (augmented)

| ID | Baseline question | Added by v0.2 |
| --- | --- | --- |
| S1 Codex | thread/turn/approval/kill/resume, schema, TUI coexistence | concurrent turns across threads in one process (X-04); approval held 10 min (X-05); `thread/resume` replay semantics; delta rates (X-03) |
| S2 Grok | two sessions, sandboxes, `auto` permission | `session/resume` support (X-02); socket/secret reachability per profile (X-01) |
| S3 Hermes | prompt, deny-by-timeout, resume, foreign `session/load` | replay volume on `session/load` (X-02); effective toolset display |
| S4 Claude | adapter vs SDK: approval, cancel, resume, untrusted start | **terms checkpoint (U9/D29)** before any product decision; API-key path |
| S5 UI | Tauri WKWebView B3/B4/B5, 5 000 events | full pipeline (coalescing, incremental Markdown, virtualization); relay latency (D16); footprint across WebKit processes (B3 methodology); 50 000-event paging (B13) |
| S6 no TUI attach | negative test | unchanged |
| **S7 Control-plane isolation** | — | X-01 across all providers' sandbox profiles; peer-ancestry rejection feasibility on macOS/Linux |
| **S8 Safe Git** | — | library coverage for status/diff/worktrees; confirm no repo-config execution; B16 |

Live models only in Phase 0, on a test repository without production secrets (retained).

## 2. Phase 1 — local Mac, sliced

| Slice | Content | Gate |
| --- | --- | --- |
| 1a Foundation | schema-first contracts (D27), fake ACP + fake app-server agents, daemon core, journal (tiers), gateway + shell relay, minimal UI (inbox, session view), **one ACP provider** (Grok or Hermes by S2/S3 outcome), approvals (D19), trust, safe Git view | F2–F7, F9, F12, F13, F18 on fixtures; B1, B4, B7, B9, B12 |
| 1b Codex | app-server adapter, compatibility policy (D24), schema reference | Codex fixtures + live smoke; drift test |
| 1c Second ACP provider | reuse ACP client | fixtures + live smoke |
| 1d Claude | channel per S4 **and** D29 | fixtures + live smoke; terms decision recorded |
| Phase 1 close | all of the above + history import (F15) for available providers | baseline gate retained (F1–F10, F12–F13, B1–B7, B9, B8 once, no open Severity-1) + B11, B13, B14 |

Location-agnostic daemon from 1a: the Linux build of the same daemon runs in CI from 1a so Phase 2 is packaging + bridge, not redesign.

## 3. Phase 2 — Linux and continuous operation
Baseline content retained, plus: SSH stdio bridge (D25), host management (F16), client federation + cross-host inbox (F14, U15), optional macOS launch agent (`SMAppService`, U6), optional separate agent Unix user (U11), 72 h soak (B8 extension).

## 4. Phase 3 — Mobile
Entry requires D28 decision (U4 widened). Gates retained (revocation, ≤ 1 s approval delivery with live link) + notification path verified (X-07) + scope enforcement test.

## 5. Phase 4 — handoff and worktree clarity
Unchanged. History import (F15) moved earlier to Phase 1 because it is read-only and low risk.

## 6. Stop condition
Baseline stop rule retained (Claude without two-way approval stays out). Added: if U9 forbids subscription login and the owner rejects API-key-only, Claude is excluded from product builds without affecting other adapters.
