# d08 — Security and Trust (delta vs baseline 08)

> **Status:** PROPOSED · Baseline: `level-1/08-security-and-trust.md` (§10). All baseline countermeasures retained unless replaced.
> Decisions: D12→D19, D20, D21, D22, D23, D26, D29. Security claims are qualified; nothing here is verified by testing.

## 1. Trust boundaries (explicit)

| Boundary | Trusted side | Untrusted side | Enforcement |
| --- | --- | --- | --- |
| B-1 Provider stdout → daemon | daemon | provider output, model text, tool output | schema validation, size caps, never executed |
| B-2 Daemon → client rendering | daemon data | content inside events | D22 rendering policy |
| B-3 Client → gateway | paired client with scope | any other process, including agents | D20, D21 |
| B-4 Workspace files → Shardrail | Shardrail code | repository content and `.git/config` | D23, F13 |
| B-5 Remote host ↔ desktop | SSH-authenticated bridge | network | OpenSSH; daemon never listens on network |
| B-6 Agent ↔ agent | — | each provider's env and credentials | separate env (retained), separate Unix user optional (U11) |

## 2. Threat table additions

| Threat | Countermeasure | Residual |
| --- | --- | --- |
| Agent connects to daemon socket / reads client credential and self-approves (R15) | D20: no endpoint/secret in provider env; credentials in keychain (macOS); peer-ancestry rejection; socket outside workspaces; sandbox deny paths where supported; separate Unix user on remote | An unsandboxed agent on a shared UID can still ptrace/inspect same-user processes on some systems; stated, not hidden |
| Rendered content exfiltrates data or disguises a command (R17) | D22 | Social engineering through legitimate text remains |
| Viewing a repo executes `core.fsmonitor` / diff drivers (R18) | D23 | Library bugs |
| Browser page reaches loopback listener | listener off by default; paired credential (no ambient auth), Origin + Host checks, no credential in URL | — |
| Stolen/compromised client device | per-device revocation; scopes; `control_policy` only from local desktop | Window between theft and revocation |
| Stale/duplicated approval response applies to a different request | approval CAS by `approval_id` (D19) | — |
| Journal disclosure (R19) | file `0600`, data dir `0700`, retention, purge, best-effort redaction; encryption deferred (U12) | Secrets in tool output may persist |
| Provider version weakens approval semantics | D24 shadow validation; Shardrail-side invariant: absent/failed approval ≠ allow | Provider-internal auto-approvals are invisible to Shardrail |

## 3. Approval lifecycle (replaces §10.1 timeout paragraph; see D19)
- States `pending → allowed | denied | expired | withdrawn`; single assignment.
- Expiry policy per workspace; default `deny_after(min(180 s, provider limit))` (baseline value, U10 open); opt-in `hold_until_provider_limit`.
- Allow-all modes: retained rule (never initial, explicit action, persistent indicator) + only via `control_policy` scope.

## 4. Secrets (refines §10.2)
- Provider credential stores never read (retained).
- N3 restated (register §1.1): journal may contain secrets that appeared in tool output; classified sensitive.
- Redaction: prefix denylist (retained) + format/entropy detectors, best effort; redaction applies to journal, logs, diagnostics export and handoff.

## 5. Claude-specific (D29)
Product builds: API-key auth for Claude until U9 is answered. No Claude Code branding imitation.
