# d-minor — Small deltas for domains 01, 03, 09, 11, 12

> **Status:** PROPOSED. These domains change only slightly; each section names its baseline file. Domains 02 and 14 are covered by `03-RISK-QUESTION-REGISTER.md` and `02-DECISION-REGISTER.md`; domain 15 is historical and unchanged.

## 01 — Product foundation (`level-1/01-product-foundation.md`)
- §2.2 scenarios: add (9) see everything needing attention across all hosts in one inbox; (10) browse and continue sessions that were started outside Shardrail, read-only, via official history APIs.
- §2.3 in product: add host management via system SSH; history import.
- §2.4 out of product: unchanged, including live TUI capture (Unsupported). Clarify "merging feeds into one global inbox is out of plan" → **replaced**: a client-side inbox is in plan (Phase 2); a merged daemon-side journal remains out.

## 03 — Technology selection (`level-1/03-technology-selection.md`)
- §4.2: D1 retained conditionally (D27; U13 owner proficiency). Corrects one argument: Go is memory-safe; the safety argument for Rust applies relative to C/C++, not Go.
- §4.3: D2 retained; shell = relay (D16); Tauri 2.12.3 confirmed as current stable on 2026-10-15 (E-08). Tauri 3 alpha status not re-confirmed.
- §4.4: D3 modified (bounded projection; S5 criteria include accessibility cost).
- §4.5: D5 modified (tiers, versioning, retention, backup).
- §4.6: D4 modified (relay, pairing, opt-in loopback, SSH stdio bridge).

## 09 — Performance (`level-1/09-performance.md`)
- Budgets B3, B4, B8 methodology changes and new B11–B16: see register §2.
- Measurement rules (new): report phys_footprint per process tree; separate columns for daemon, shell+WebKit, each provider; record provider versions; no budget closes without a stored trace.
- Linux watchers: watch only expanded directories and Git metadata; respect inotify limits; degrade to manual refresh with visible notice.

## 11 — Quality, observability, reliability (`level-1/11-quality-observability-reliability.md`)
- Fake agents (ACP and app-server simulators with scripted scenarios: deltas at high rate, crash mid-tool, replay on load, approval storms, withdrawn approvals) are a **Phase 1a deliverable**, not test incidentals.
- Contract tests generated from schemas (D27); shadow validation logs for `untested-newer` providers (D24).
- Added test classes: approval CAS under concurrent clients; disconnect never resolves approval; `delivery_unknown` after crash between accept and dispatch; per-client queue overflow → resync; rendering fixtures for D22; repo with malicious `core.fsmonitor` (D23); agent-peer rejection (D20).
- Spans added: `gateway.fanout`, `command.accept`, `command.dispatch`, `approval.respond`, `replay.reconcile`.
- §13.3 dedup rule replaced by replay mode (d05 §1) + item-ID reconciliation.

## 12 — Release, distribution, licensing (`level-1/12-release-distribution-licensing.md`)
- macOS: Developer ID + notarization (retained). Mac App Store distribution documented as incompatible with spawning user-installed CLIs under App Sandbox (INFERRED).
- Claude: in addition to bundling license (R10), **usage terms** (D29, U9) gate commercial builds.
- Privacy notes: Codex `clientInfo.name` reaches OpenAI compliance logs (E-03).
- Repository visibility (U14) and product license (U3) are **owner decisions**; the baseline recommendation (private, all rights reserved) is recorded but not adopted by this candidate.
