# 03 — Risk, Requirement and Open-Question Register (proposed additions)

> **Status:** PROPOSED — NOT OWNER-APPROVED. Original R1–R14, U1–U8, F1–F13, N1–N9, B1–B10 remain in the baseline; this file lists only proposed changes and additions. Numbers below are **proposed budgets**, not measurements.

## 1. Requirements

### 1.1 Modified
| ID | Baseline | Proposed | Source |
| --- | --- | --- | --- |
| F1 | Unknown/too-new build marked unverified; no start without override | Version classes `tested` / `untested-newer` (start with warning + shadow validation) / `known-bad` (refuse without override) | D24, CR-10 |
| F5 | Timeout and window close = deny | Approval resolved once (CAS); disconnect/window close never resolve; expiry per policy; expiry never = allow | D19, CR-07 |
| F8 | Read-only tree and diff of session dir | + no repository-controlled command executes during viewing | D23, CR-04 |
| F13 | Trust states; no start that loads hooks in `unknown`/`restricted` (Claude, Grok tested) | Applies to every provider via a per-provider project-config execution table | CR-20 |
| N3 | Provider secrets are not read into the DB and do not leave the host | Provider **credential stores** are never read; the journal is classified sensitive (may contain secrets from tool output); best-effort redaction; retention and purge | CR-19 |
| N4 | Only `0600` Unix socket or loopback with `0600` secret | + every client authenticated with a paired, scoped, revocable credential; loopback listener opt-in | D21 |

### 1.2 New
| ID | Requirement | Acceptance (future) |
| --- | --- | --- |
| F14 | Global attention inbox across sessions and hosts (pending approvals, failures, completions) with OS notifications when hidden | Approval on host B surfaces while viewing host A; notification while window hidden |
| F15 | Read-only import of external session history via official APIs; "continue as new session" via official resume/fork | Codex `thread/list`/`read`, Claude `listSessions`/`getSessionMessages`, Hermes list/load — fixture tests |
| F16 | Host management: add/remove remote hosts using system SSH; per-host health | Bridge connects through user SSH config incl. jump host |
| F17 | Per-session purge and journal retention settings | Purged session leaves no rows; WAL checkpointed |
| F18 | Delivery uncertainty is visible: `delivery_unknown` and `outcome_unknown` states | Crash between accept and dispatch yields `delivery_unknown`, no resend |
| N10 | Supervised agent processes cannot use the control plane (best effort; residual risk documented per sandbox profile) | X-01 results per profile; peer-ancestry rejection test |
| N11 | Untrusted content renders without active content or remote loads; approval cards reveal hidden characters | Fixture with bidi/zero-width command; Markdown image URL not fetched |
| N12 | Idle efficiency: no periodic wakeups beyond B9; energy measured | B11 |

## 2. Budgets (PROPOSED, unmeasured; verification method stated)

| ID | Change | Budget | Method |
| --- | --- | --- | --- |
| B3 | MODIFY methodology | ≤ 180 MB **total phys_footprint** of app + all WebKit helper processes, idle, empty transcript (value retained, scope widened — may need re-baselining **with** measurement, never silently) | `footprint`/Activity Monitor per process tree |
| B4 | MODIFY methodology | p95 ≤ 50 ms daemon-receive → painted frame; timestamps from one host monotonic clock via echo/round-trip calibration | S5 trace |
| B8 | EXTEND | Retained (8 h); add 72 h soak: daemon RSS ≤ 1.3× at 10 min; WAL ≤ 64 MiB; WebView footprint ≤ B3 + 150 MB | soak harness |
| B11 | NEW | Idle (no active turn): daemon + shell ≤ 1 wakeup/s average, CPU ≈ 0 %; energy impact "Low" in Activity Monitor | `powermetrics`, Activity Monitor |
| B12 | NEW | Per-client outbound queue ≤ 8 MiB; overflow → resync, never growth | fault-injection test with stalled client |
| B13 | NEW | First visible page of a 50 000-event session ≤ 300 ms (warm DB) | fixture DB |
| B14 | NEW | Approval round trip (client tap → provider receives response) ≤ 100 ms local, excluding network on remote | span `approval.respond` |
| B15 | NEW | Durable journal growth ≤ 2× completed item content size per turn (deltas excluded) | journal statistics on recorded sessions |
| B16 | NEW | Git status refresh: ≤ 1 concurrent computation per worktree; ≤ 1 s for 100k tracked files on reference machine | bench on fixture repo |

## 3. Risks (new)

| ID | Risk | Severity | Treatment |
| --- | --- | --- | --- |
| R15 | Prompt-injected agent self-approves through the control plane | high | D20, D21, X-01 |
| R16 | Claude Agent SDK terms restrict subscription-login use in third-party products | high (product) | D29, U9 |
| R17 | Untrusted content rendering (exfiltration via remote loads, disguised approval commands) | high | D22 |
| R18 | Repository config executes commands during Git viewing | high | D23 |
| R19 | Journal exposes secrets/proprietary code at rest (Mac and remote) | medium | N3 restated, D26 retention, U12 |
| R20 | Provider release cadence breaks adapters faster than a solo maintainer can follow | high | D24, contract fixtures, capability negotiation |
| R21 | Phase 1 scope exceeds solo capacity | high | Phase 1a–1d slicing, fake-agent harness |
| R22 | History duplication or divergence after `session/load` replay | medium | replay mode (L2-03), prefer `session/resume` |
| R23 | TCC grants accumulate on Shardrail.app for all agents | medium | document; show which agent triggered; no extra grants requested by Shardrail itself |
| R24 | WebView memory growth over multi-day use | medium | B8 extension, view reload watchdog |
| R25 | `clientInfo.name` reported to OpenAI compliance logs; product name exposure | low | disclose; stable name |

Updated: **R3** severity reason widened — shared UID affects approval integrity (R15), not only credential reading. **R6** treatment adds D24 (auto-updates are expected, not exceptional).

## 4. Open questions (new; baseline U1–U8 retained)

| ID | Question | Blocks | Interim behavior |
| --- | --- | --- | --- |
| U9 | May Shardrail drive Claude Code via Agent SDK/ACP adapter with users' subscription login? (legal/policy) | Claude in Phase 1 product builds; commercialization | API-key-only for Claude in product builds (D29) |
| U10 | Default approval expiry: `deny_after(180 s)` or `hold_until_provider_limit`? | L2-04 | baseline 180 s deny |
| U11 | Separate Unix user for agents on remote hosts by default? | Phase 2 | recommend, not default |
| U12 | Journal encryption at rest; key management on Linux | Phase 2 | off; retention/purge available |
| U13 | Owner proficiency Rust vs Go (decision input for D1) | Phase 1 start | Rust |
| U14 | Repository visibility (public/private) — separated from license U3 because they are independent | first public commit | private (baseline), owner decides |
| U15 | Is a cross-host unified inbox required in Phase 1 or Phase 2? | F14 scope | Phase 2 with first remote host |
