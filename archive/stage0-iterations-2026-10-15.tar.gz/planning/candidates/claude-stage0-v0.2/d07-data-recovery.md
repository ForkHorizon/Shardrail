# d07 — Data, Synchronization and Recovery (delta vs baseline 07)

> **Status:** PROPOSED · Baseline: `level-1/07-data-synchronization-recovery.md` (§9). Data ownership table (§9.1) and single-writer rule retained.
> Decisions: D5, D17, D19, D25, D26, D30.

## 1. Synchronization (replaces the multi-host paragraph of §9.2)
Each host's daemon is the only writer for its sessions (retained). A client may connect to several hosts; it federates projections client-side, keyed by `(HostId, SessionId)`, with one cursor per host. There is no daemon-to-daemon replication and no global journal. A cross-host inbox (F14) is a client view.

## 2. Concurrency between clients (new)
- All mutations go through the command router; preconditions (`expected_turn_id`, `expected_state`) reject stale intent with the current state.
- Approval resolution is single-assignment (D19); the second responder receives the final state.
- Presence: clients see which other clients are attached to a session (no locking).

## 3. Recovery table (replaces §9.3 rows where different)

| Failure | Proposed behavior |
| --- | --- |
| kill -9 of daemon | WAL recovers committed events; sessions start with process=`exited`; accepted-but-undispatched commands → `delivery_unknown`; open tool items → `outcome_unknown`; no automatic resend (retained) |
| stdio break / provider crash | process=`exited`; open tools → `outcome_unknown`; surviving descendants of the provider process group reported; resume offered per capability, preferring `resume_without_replay` |
| Hang without break | turn=`stalled` after threshold (baseline 15 min, configurable); no auto-kill (retained) |
| Client drops mid-approval | approval remains `pending`; resolved only by a client response, provider withdrawal, or policy expiry (never allow) |
| Client reconnects | catch-up by cursor; if gap exceeds retention or queue overflowed, snapshot + cursor |
| Remote link (SSH) drops | remote sessions continue (retained); client marks host `disconnected`; reconnect via bridge |
| Repeated command after network error | same `command_id` returns stored result; never re-executes |
| SQLite corruption | open read-only, integrity check, offer export/salvage; new DB only on explicit choice; last online backup offered |
| WAL growth | checkpoint policy; readers use short transactions; alarm above B8 WAL limit |
| Linux reboot / Mac reboot | retained (no auto-continuation) |

## 4. Retention (new)
Default: keep durable events; compact delta checkpoints; per-session purge (F17); optional age-based retention (owner setting). Purge never touches provider directories.
