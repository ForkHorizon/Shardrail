# d10 — Interface and Visual System (delta vs baseline 10)

> **Status:** PROPOSED · Baseline: `level-1/10-interface-and-visual-system.md` (§12). All baseline principles retained (visible state, approval as its own modality, collapsed thoughts, readable diffs, keyboard, reduced motion, AA, native window chrome).
> Decisions: D3, D17, D22, D25; requirements F14, N11.

## 1. Information architecture (new)

| Surface | Purpose | Notes |
| --- | --- | --- |
| Attention inbox (F14) | everything that needs the human, across hosts: approvals, failures, `delivery_unknown`, completions | default landing view; keyboard: next/prev item, allow/deny |
| Session list | sessions grouped by host → workspace, derived state badge, provider, sandbox indicator | federated client-side (D25) |
| Session view | transcript (virtualized), tool cards updated in place, approval modality, composer, queue indicator | per-item streaming |
| Workspace pane | read-only tree, Git status, diff for the session's actual cwd/worktree | "unknown cwd" shown as such (retained) |
| Command palette | every action reachable by keyboard | — |
| Diagnostics | provider versions + compatibility class, binary paths, socket/bridge state, per-session provider footprint | extends §13.2 |

Layouts: single session, split (2–4 sessions tiled), inbox + session. Density setting (comfortable/compact). Layout state is per-client view state (D3).

## 2. Rendering pipeline requirements (new; feeds S5)
- Deltas arrive coalesced (D17); the UI appends to the item's buffer and repaints at most once per frame.
- Markdown parsed **incrementally** (only the open tail block re-parsed); code highlighting deferred until a block closes and is visible.
- Large tool output and diffs: virtualized lines, collapsed by default beyond a threshold, "open full" on demand.
- Untrusted content per D22: allowlisted Markdown, no raw HTML, no remote loads, visible control/bidi characters in commands.
- Memory: transcript items outside the virtual window hold only lightweight records; WebView reload watchdog for multi-day use (R24).

## 3. Visual identity
Retained baseline v1 tokens until U2 (brand book). Clarification: the "nine primitives" list is the **Phase 1a** floor, not a ceiling for the product; the design system is a first-class module (L2 future: "UI system and rendering"), developed alongside the backend, not after it.

## 4. Mobile consistency
Same data model and derived states; one column; approval and inbox first (retained). Mobile approval cards show command + cwd + sandbox in full; truncation never hides the executable part.
