# d04 — System and Process Architecture (delta vs baseline 04)

> **Status:** PROPOSED · Baseline: `level-1/04-system-and-process-architecture.md` (§5, §6). Unchanged baseline text applies unless replaced here.
> Decisions: D2, D4, D8, D11, D16, D18, D20, D25, D30.

## 1. Components (replaces §5 table where rows differ)

| Component | Does | Does not | Change |
| --- | --- | --- | --- |
| `shardraild` | hosts all components below; one per host; same binary on macOS and Linux | call models directly | unchanged |
| Client gateway | authenticates paired clients, enforces scopes, fans out events with bounded per-client queues, resync on overflow | interpret provider protocols | **new** (D16, D17, D21) |
| Command router | `command_id` idempotency, preconditions, intent journaling | execute provider I/O | **new** (D30) |
| Session engine | orthogonal state, projections, delta coalescing, replay reconciliation | own processes | split from "Session service" (D17, D18) |
| Provider supervisor | spawns providers per topology table, process groups, stdio, health, crash detection, env sanitization | translate protocol | split from daemon core (D8, D20) |
| Adapters | one protocol each (ACP client; Codex app-server); capability negotiation; normalization; replay mode | render UI, store secrets | refined (D24) |
| Approval broker | approval records, CAS resolution, expiry policy, notifications | judge command safety from text | refined (D19) |
| Workspace service | trust state, read-only tree, safe Git, scoped watchers | write files | refined (D23) |
| Handoff | unchanged | — | — |
| Shell (desktop) | window, menu-bar presence, notifications, keychain, deep links, **frame relay**, host connection launcher (`ssh … bridge`) | domain logic, message parsing | refined (D2, D11, D16, D25) |
| Web UI | projection and input; client-side host federation and attention inbox | source of truth | refined (D25, F14) |

## 2. Process tree (macOS, Phase 1)

```
Shardrail.app (shell; lifetime = user session of the app)
└─ shardraild (child; lifetime = app; survives window close)
   ├─ provider process group: codex app-server (topology per D8)
   ├─ provider process group: grok agent stdio (per session until S2)
   ├─ provider process group: hermes acp
   └─ provider process group: claude adapter → claude CLI per session
```
- Window close hides; menu-bar item lists running sessions/pending approvals; quit asks: cancel all turns (protocol cancel → grace → terminate group) or keep running (only if Phase 2 opt-in launch agent is enabled).
- Linux: `shardraild` under systemd **user** service (unchanged); remote clients arrive via `shardraild bridge` invoked by SSH (D25).

## 3. Session state (replaces §6.4)

```mermaid
stateDiagram-v2
  direction LR
  state "process" as P {
    [*] --> spawning
    spawning --> alive
    alive --> exited
  }
  state "turn" as T {
    [*] --> idle
    idle --> running
    running --> cancelling
    running --> stalled
    stalled --> running
    cancelling --> idle
    running --> idle
  }
```
Dimensions: process {spawning, alive, exited(code)} · link {initializing, ready, desynced} · turn {idle, running, cancelling, stalled} · approvals {pending set, 0..n} · delivery {confirmed, unknown}. Derived badge precedence: `needs approval` > `degraded` (exited/desynced) > `delivery unknown` > `stalled` > `cancelling` > `running` > `idle`. `disconnected` is a client-local overlay per host.

Queue policy (F7) unchanged: one pending instruction per session owned by Shardrail; providers with native steering (Codex `turn/steer`, `expectedTurnId`) may receive it via capability after spike.

## 4. Provider process topology (replaces the uniform rule in §6.1)
See proposal §3.5. Default process-per-session until each spike rules (baseline safe default retained).

## 5. Environment sanitization (new, D20)
Provider processes receive an allowlisted environment: user's normal variables needed by the provider, minus any `SHARDRAIL_*`, socket paths, and client credentials. Each provider's environment is never copied to another (baseline retained).

## 6. Unchanged
§5.1 module name list is superseded by the proposed module index (`level-2/proposed/00-MODULE-INDEX.md`); §6.2 Linux rules retained (+ U11); §6.3 retained with D21 scopes.
