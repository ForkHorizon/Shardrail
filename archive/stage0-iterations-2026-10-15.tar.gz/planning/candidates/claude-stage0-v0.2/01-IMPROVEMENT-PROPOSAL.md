# 01 — Architecture Improvement Proposal (WP-D)

> **Candidate:** Shardrail Architecture Candidate v0.2 — Claude Revision · **Status:** PROPOSED — NOT OWNER-APPROVED
> **Author:** Claude (Opus 5.5), 2026-10-15 · **Inputs:** review `reviews/claude-stage0-r01/01-INDEPENDENT-REVIEW.md` (CR-xx), stress test `02-STRESS-TEST.md` (S-x)
> Decision records for every change: [`02-DECISION-REGISTER.md`](02-DECISION-REGISTER.md).

## 1. What stays

The baseline direction is retained: **one Rust daemon per host that owns provider processes and the journal; thin web clients; official provider protocols only; explicit approvals that never default to allow; read-only workspace view; explicit handoff.** Changes below harden boundaries and fill gaps; none removes a baseline capability.

## 2. Proposed target shape

```mermaid
flowchart LR
  subgraph clients [Clients]
    Desk[Desktop app: Tauri shell + Web UI]
    Brw[Browser: Web UI]
    Mob[Mobile: Phase 3, deferred]
  end
  subgraph host [Each host: macOS local or Linux remote]
    GW[Client gateway: auth, scopes, fan-out, backpressure]
    CMD[Command router: command_id, preconditions]
    SES[Session engine: state dimensions, projections]
    JR[(Journal: SQLite WAL, durable tier)]
    APB[Approval broker: records, CAS, policy, notify]
    SUP[Provider supervisor: topology, process groups]
    WS[Workspace service: trust, tree, safe Git, watchers]
    HO[Handoff]
    subgraph adapters [Adapters]
      ACP[ACP client: Grok, Hermes, Claude-ACP]
      CDX[Codex app-server client]
    end
  end
  Desk -- frames relayed by shell to Unix socket --> GW
  Desk -- ssh host shardraild bridge (stdio) --> GW
  Brw -- loopback WebSocket, opt-in, paired --> GW
  GW --> CMD --> SES
  SES --> JR
  SES <--> APB
  SES <--> SUP --> adapters
  CMD --> WS
  CMD --> HO
```

Key properties:
- **One wire protocol** (schema-first, JSON) for every client and transport (D16, D27).
- **Two event tiers**: ephemeral deltas (memory, coalesced) and durable events (journal) (D17).
- **Approval as a daemon-owned record** resolved exactly once (D19); agents cannot use the control plane (D20).
- **Hosts are federated by the client**, not by daemons (D25).

## 3. Alternatives for the highest-consequence decisions

### 3.1 Daemon language — Rust vs Go (D1, D27)

| Criterion (Shardrail workload) | Rust | Go | Notes |
| --- | --- | --- | --- |
| Workload character | N child processes, line-delimited JSON at KB/s–low MB/s, SQLite appends, socket fan-out | same | Neither language is near its throughput limit here (INFERRED) |
| Memory safety parsing untrusted JSON | safe | safe | Baseline's "fewer memory-corruption bugs" argument applies vs C/C++, **not** vs Go |
| Idle footprint / GC | no GC; small static binary | GC; small static binary; idle RSS low | Both expected to fit B1 (≤ 40 MB) — REQUIRES FUTURE EXPERIMENT; GC pauses irrelevant at these event rates |
| ACP library | official `agent-client-protocol` crate | third-party `acp-go-sdk` | Real advantage for Rust; the ACP surface used is small enough to hand-write in either |
| Codex app-server types | generated from JSON Schema | generated from JSON Schema | Neutral |
| Shell integration | Tauri shell is Rust | Shell would be Swift/thin WKWebView | Under D16 the shell is a frame relay; the "Tauri brings Rust anyway" argument is weaker than the baseline states |
| Solo iteration speed | slower builds, async/borrow complexity | faster builds, simpler concurrency | The main real cost of Rust |
| Long-term maintainability | strong typing of protocol enums | simpler code, weaker sum types | Rust's enums fit event/state modeling well |

**Recommendation:** RETAIN Rust, conditioned on **schema-first contracts** (D27) so the client protocol and journal formats are language-neutral and a Go rewrite stays possible. **Owner input needed:** the decisive factor for a solo project is the owner's own proficiency; if the owner is markedly faster in Go, Go + thin Swift WKWebView shell is a legitimate equal-performance alternative (baseline Alternative B). Confidence: medium.

### 3.2 Separate daemon vs runtime embedded in the app (D11)

| Option | Pros | Cons |
| --- | --- | --- |
| A. Embedded in shell process | simplest IPC | Linux needs a headless daemon anyway → two hosting modes; UI crash kills sessions |
| B. Separate process, lifetime = window (baseline D11) | TCC identity, no orphans | window close cancels work (S-3) |
| **C. Separate process, lifetime = app; window close hides** | survives window close; same binary as Linux; conventional macOS behavior | must show menu-bar presence while sessions run; quit must ask |
| D. Always-on launch agent (`SMAppService`) | continuous local operation | approval UX in System Settings, background policy, orphans; opt-in only |

**Recommendation:** C for Phase 1; D as an explicit opt-in in Phase 2 (U6).

### 3.3 UI rendering strategy (D2, D3)

| Option | Desktop quality | Browser/mobile reach | Solo cost | Risk |
| --- | --- | --- | --- | --- |
| **System WebView + one web UI (baseline)** | good if pipeline disciplined | one codebase | lowest | WKWebView footprint/latency (S5) |
| Native per platform (SwiftUI, Compose, web) | best | three codebases | highest | infeasible solo |
| GPU-native Rust UI (GPUI/Slint/egui) | excellent latency | no browser; mobile weak | high | accessibility maturity, text rendering |
| Electron | good | one codebase | low | bundled Chromium contradicts priority #2 |

**Recommendation:** RETAIN system WebView. Performance is decided by the pipeline, not the framework: daemon-side coalescing, per-item fine-grained updates, virtualization, incremental Markdown parsing, lazy highlighting, no remote resources. Framework (Solid vs React, U8) decided in S5 against N7 accessibility cost as well as B4/B5.

### 3.4 Client transport (D4, D16)

| Option | Security | Simplicity | Remote | Verdict |
| --- | --- | --- | --- | --- |
| Tauri `invoke` as domain API | no TCP; ties domain to Tauri | simple | no | REJECT (baseline also rejects) |
| Loopback WebSocket for all clients | TCP surface, DNS rebinding, Origin checks | simplest | via tunnel | browser path only, opt-in |
| **Unix socket + byte-level shell relay for desktop** | no TCP; peer checks | small relay | via SSH stdio bridge | **ADOPT** |
| gRPC / gRPC-web | proxies needed in browser | heavier | yes | REJECT for now |

Encoding: JSON first; binary (CBOR/MessagePack) only if measurement shows serialization in the B4 critical path.

### 3.5 Provider process topology (D8)

Replace the uniform rule with a per-provider table decided by spikes:

| Provider | Default until spike | Candidate after spike | Basis |
| --- | --- | --- | --- |
| Codex | process per session | process per workspace (threads share; per-turn `sandboxPolicy`/`cwd`) if S1 confirms concurrent turns and isolation | E-03 |
| Grok | process per session | shared only for profiles S2 allows | baseline §6.1 |
| Hermes | process per session | shared if S3 shows per-session approval/toolset isolation | E-06 |
| Claude | per adapter process; each session spawns its own CLI anyway | adapter process shared, CLI per session | E-10 (UNVERIFIED) |

### 3.6 Event persistence (D5, D17, D26)

| Option | Crash safety | Query/paging | Cost | Verdict |
| --- | --- | --- | --- | --- |
| SQLite, every delta durable | high | good | write amplification, size | REJECT |
| **SQLite, durable tier + ephemeral deltas + checkpoints** | loses ≤ checkpoint interval of in-progress text (still in provider) | good | low | **ADOPT** |
| JSONL files per session | simple | poor random access | low | REJECT |
| No own journal (provider = truth) | depends on provider | inconsistent across providers | lowest | REJECT: breaks F9, history when provider dead |

### 3.7 Remote communication (D4, D25, D28)

| Option | Setup | Security | Phone | Verdict |
| --- | --- | --- | --- | --- |
| Manual `ssh -L` (baseline) | user-managed | good | poor | superseded |
| **App-spawned `ssh host shardraild bridge` (stdio)** | uses existing SSH config/keys/jump hosts | good, no listening port | no | **ADOPT for desktop** |
| User-managed mesh VPN + daemon listener (paired creds) | moderate | depends on pairing/TLS | yes | candidate for Phase 3 (U4) |
| Own relay service | none for user | operational burden, new trust party | yes | REJECT for solo project now |

### 3.8 Permission and capability abstraction (D12, D19–D21)

- **Provider-native decisions preserved** (baseline §7.4 retained): no single "autonomy slider"; `allow_always`/`acceptForSession` labeled with their real scope.
- **Approval record** with single-assignment resolution, policy-driven expiry, and fan-out notification (D19).
- **Client scopes** (`observe`, `respond_approval`, `prompt`, `control_policy`) and step-up for policy-weakening actions (D21).
- **Control-plane isolation from agents** (D20): the approval channel must not be operable by the supervised processes.

## 4. Capabilities deliberately deferred (with future requirements)

| Capability | Why defer | Architectural requirement kept now |
| --- | --- | --- |
| Mobile client (Phase 3) | transport and notification unresolved (U4) | client scopes, pairing, approval record already support remote responders |
| Continuous local Mac operation | background policy, approval UX | daemon already separate process; `SMAppService` path documented |
| Encryption at rest of journal | Linux key management open | journal access isolated in one module; retention/purge now |
| Live TUI attach | Unsupported by all providers | read-only history import (F15) instead |
| Human file editing | two-writer races | read-only now; workspace service owns all FS access |
| Cross-host global search | no measured need | per-host query API; client merges |
