# Shardrail Architecture Candidate v0.2 — Claude Revision

> **Status:** PROPOSED CANDIDATE — NOT OWNER-APPROVED. Implementation NOT authorized. Stage 0.
> **Author:** Claude (Opus 5.5), 2026-10-15 · **Baseline:** Grok Master Plan (`../../source/MASTER_PLAN.original.ru.md`, English: `../../level-1/`)
> **Preceded by:** independent review `../../reviews/claude-stage0-r01/` (written before this candidate).

## How to read this candidate

This is a **delta** over the baseline, not a new monolithic plan. Where a domain is not mentioned, the baseline Level 1 file stands.

| Order | Document | Purpose |
| --- | --- | --- |
| 1 | [01-IMPROVEMENT-PROPOSAL](01-IMPROVEMENT-PROPOSAL.md) | Target shape and alternatives compared |
| 2 | [02-DECISION-REGISTER](02-DECISION-REGISTER.md) | ADR-style records: D1–D15 dispositions, new D16–D30 |
| 3 | [03-RISK-QUESTION-REGISTER](03-RISK-QUESTION-REGISTER.md) | Requirement changes (F/N), budgets (B), risks (R15+), questions (U9+) |
| 4 | [04-CHANGELOG](04-CHANGELOG.md) | Original → proposal → justification → affected docs |
| 5 | Domain deltas | [d04 system/process](d04-system-and-process.md) · [d05 providers](d05-provider-integrations.md) · [d06 sessions/events](d06-sessions-events.md) · [d07 data/recovery](d07-data-recovery.md) · [d08 security](d08-security.md) · [d10 interface](d10-interface.md) · [d13 roadmap](d13-roadmap.md) · [d-minor: 01, 03, 09, 11, 12](d-minor-domains.md) |
| 6 | [90-CONSISTENCY-REPORT](90-CONSISTENCY-REPORT.md) | Cross-document contradictions and adversarial self-review |

Provisional next-level planning (also PROPOSED): `../../level-2/proposed/`, `../../backlog/proposed/`.

## Domain coverage

| Baseline domain | v0.2 treatment |
| --- | --- |
| 01 product | small delta (d-minor) |
| 02 requirements | register §1 |
| 03 technology | small delta (d-minor) + D1–D5 records |
| 04 system/process | d04 |
| 05 providers | d05 |
| 06 sessions/events | d06 |
| 07 data/recovery | d07 |
| 08 security | d08 |
| 09 performance | register §2 + d-minor |
| 10 interface | d10 |
| 11 quality | d-minor |
| 12 release/licensing | d-minor |
| 13 roadmap | d13 |
| 14 decisions/risks | registers 02, 03 |
| 15 original self-review | unchanged (historical) |

## Owner decisions this candidate needs (summary)

U9/D29 Claude terms · U10 approval expiry default · U11 separate agent user on remote · U13 Rust vs Go proficiency · U14 repository visibility · U3 license · U6 continuous local Mac · D11 window-close behavior · D24 warn-and-run for untested provider versions · D28 mobile at Phase 3 entry.
