# 90 — Cross-Document Consistency Report and Adversarial Self-Review (WP-H, Pass 6)

> **Status:** PROPOSED · Author: Claude (Opus 5.5), 2026-10-15. Covers baseline ↔ candidate v0.2 ↔ proposed Level 2/backlog.
> Resolution here = **recommended**, not approved. No difficult requirement was removed to resolve a conflict.

## 1. Contradictions found

| ID | Relationship | Contradiction | Recommended resolution | Alternatives | Impact |
| --- | --- | --- | --- | --- | --- |
| C-01 | Requirements ↔ architecture | N2/B9 forbid periodic timers < 15 s; D17 flushes deltas per frame and checkpoints every 2 s | Clarify N2/B9 apply to **idle** state; timers may be armed only while data is flowing and must disarm when a turn ends | Event-driven flush only (no timer) — worse latency under bursty input | 02 N2, 09 B9, d06 |
| C-02 | Session lifecycle ↔ approvals | `stalled` after 15 min without events (baseline §9.3) would fire on a turn legitimately held in `hold_until_provider_limit` | Exclude turns with pending approvals from stall detection | Separate longer threshold for approval waits | d07, L2-04 |
| C-03 | Recovery ↔ process ownership | D11 "keep running on quit" needs the daemon to be owned by launchd, but in Phase 1 it is an app child; ownership cannot transfer for live processes | Ownership mode fixed at daemon start: app-child (Phase 1 default) or launch agent (Phase 2 opt-in); switching requires no active turns | Always launch agent (rejected: Phase 1 complexity, U6 open) | d04, D11, L2-01 |
| C-04 | Recovery ↔ approvals | First draft of L2-04 suggested re-presenting approvals after daemon restart; providers are stdio children and lose their channel | **Resolved** in L2-04 §7: all pending → `withdrawn(daemon_restart)` | — | L2-04 |
| C-05 | Security ↔ remote access | Opt-in loopback WebSocket on a **shared remote Linux host** is reachable by other local users | On remote hosts prefer the stdio bridge; loopback listener refused when other interactive users exist unless owner overrides; paired credential always required | Unix socket only on remote (no browser access) | d08, L2-05 |
| C-06 | Security ↔ D20 heuristic | Peer-ancestry rejection is defeated by double-fork/`setsid` | Treat ancestry check as noise reduction only; the real control is credential secrecy (keychain on Mac; credentials never stored on remote hosts — only verifiers) + separate agent user (U11) | — | d08, L2-04, L2-05 |
| C-07 | Performance ↔ technology | B3 (≤ 180 MB) was set for "shell RSS"; with the corrected methodology (all WebKit processes, phys_footprint) the same number may be unattainable | Re-baseline B3 **with** S5 measurement and an explicit decision record; never raise silently (baseline rule retained) | Keep number, change scope back (rejected: hides cost) | 09, D2 |
| C-08 | UI requirements ↔ budgets / solo scope | Inbox, layouts, palette, rich rendering (d10) vs B3/B5 and P1a capacity | Phase 1a ships inbox + single session view + palette; layouts and density in Phase 1 close or later | Defer inbox (rejected: core product value) | d10, BACKLOG |
| C-09 | Licensing ↔ integrations | N8 forbids copyleft but says nothing about **proprietary usage terms** (Agent SDK Commercial Terms, E-04); `claude-agent-acp` license UNVERIFIED | Extend N8: "dependency licenses **and usage terms** permit Fork Horizon's intended distribution"; verify adapter license before P1d | — | 02 N8, 12, D29 |
| C-10 | Provider capabilities ↔ F15 | Baseline marks loading arbitrary Hermes CLI sessions as Plausible/not promised; F15 lists Hermes history | F15 limited to sessions the provider's official API can list/load; CLI-created Hermes sessions depend on S3 | — | d05, F15 |
| C-11 | Roadmap ↔ dependencies | d13 moves history import (F15) into Phase 1 close while Phase 4 baseline gate covers fork/worktree; no conflict, but F15 needs adapters from 1b–1d | Keep F15 at Phase 1 close as listed in backlog (E1.16 after E1.13–E1.15) | Move F15 to Phase 2 if Phase 1 slips | d13, BACKLOG |
| C-12 | Product vision ↔ baseline §9.2 | "Unified session management" vs "global inbox out of plan" | Client-side federation (D25); daemon-side merge remains out | — | 01, 07 |
| C-13 | Governance ↔ this round | REVIEW_PROTOCOL forbids Level 2/3 in Stage 0; assignment permitted labeled drafts | Owner amends protocol or rejects `level-2/proposed/` and `backlog/proposed/` | — | governance |
| C-14 | D1 ↔ D2 rationale | Baseline justifies Rust partly by Tauri; D16 shrinks shell code to a relay | D1 justification restated (ACP crate, enums, no second language in daemon); Tauri no longer a strong argument | — | 03, D1 |

## 2. Cross-domain impact of key decisions

| Decision | Documents that must change if approved |
| --- | --- |
| D16 relay | 03 §4.3/§4.6, 04 §5 diagram, 08 §10.2 (bridge secret), 12 §14 (browser served "with window") |
| D17 tiers | 06 §8.2, 07 §9.3, 09 B10/B4, 11 §13.1 |
| D19 approvals | 02 F5, 07 §9.3, 08 §10.1, 11 §13.1, 14 D12 |
| D20/D21 | 04 §6.3, 08 §10.1–10.2, 13 Phase 3 gate |
| D24 | 02 F1, 05 §7.3, 12 §14, 14 R1/R6 |
| D25 | 01 §2.2–2.4, 04 §6.2, 07 §9.2, 13 Phase 2 |
| D29 | 05 §7.3, 12 §15, 13 stop condition, 14 R10 |

## 3. Adversarial self-review of candidate v0.2

**Where v0.2 adds complexity a solo developer may not afford.** Pairing + four scopes, CAS approvals, two event tiers, client federation, schema codegen. Minimal viable cut for P1a: credentials yes but only two scopes (local-full, remote-limited); tiers yes (they reduce work); CAS yes (small); federation deferred to P2; codegen for Rust↔TS only. If the owner finds even this heavy, the first thing to drop is the browser loopback listener (desktop relay alone covers P1a).

**Where v0.2 may be wrong.**
- D20 may give false confidence: its effectiveness depends on provider sandboxes and is unmeasured (S7). On a shared UID without sandbox, an agent can always act as the user. v0.2 must not be read as "self-approval solved".
- D19 `hold_until_provider_limit` lets an approval answered hours later execute in a changed workspace. Mitigation candidates: show approval age prominently; require re-confirmation beyond a staleness threshold. Not designed yet.
- D17 loses in-progress text since the last checkpoint if both daemon and provider die. Alternative not chosen: journal deltas in a cheap, TTL-compacted side table — simpler recovery, more writes. Revisit with X-03 data.
- D16 assumes a Tauri relay can stream at UI rates with negligible latency — UNVERIFIED; fallback is the loopback WebSocket for the desktop too.
- D25 depends on remote `shardraild` being installed and on PATH for non-interactive SSH sessions — a common source of setup friction.
- D28's PWA + Web Push path is INFERRED; Android delivery for self-hosted VAPID senders unverified.
- D1: leaving Rust vs Go partly to owner proficiency may look indecisive; it reflects that no workload-based evidence separates them here.

**Evidence gaps that remain.** Grok primary docs (relied on baseline's local manual), claude-agent-acp README and license, Codex approval wait behavior, Codex concurrent turns, ACP `session/resume` adoption by Grok/Hermes, Tauri 3 status, all performance numbers.

**What v0.2 deliberately did not change.** Official-protocol-only rule; no TUI capture; D7; timeout never allow; no bundling; explicit handoff; budgets-not-measurements discipline; Phase 0 before product code.
