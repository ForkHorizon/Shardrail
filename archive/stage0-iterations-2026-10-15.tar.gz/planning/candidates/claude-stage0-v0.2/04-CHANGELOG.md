# 04 — Change Log: Baseline → Candidate v0.2

> **Status:** PROPOSED. Every line is a recommendation awaiting owner decision. Format: original → Claude proposal → justification → affected documents.

| # | Original (baseline) | Claude proposal | Mark | Justification | Affected |
| --- | --- | --- | --- | --- | --- |
| 1 | D1 Rust core | Rust + schema-first contracts; owner proficiency as input | RETAIN | CR-23 | 03, 14, d-minor, D27 |
| 2 | D2 Tauri shell, domain API via daemon socket | Shell is a byte-level frame relay; footprint across WebKit processes | MODIFY | CR-02, CR-18 | 03, 04, 09, d04 |
| 3 | D3 no state layer | Bounded projection; S5 criteria include accessibility and pipeline | MODIFY | CR-06, CR-22 | 03, 10, d10 |
| 4 | D4 Unix socket + manual SSH forward + loopback bridge with single secret | Relay, paired scoped clients, opt-in loopback, SSH stdio bridge, agent isolation | MODIFY | CR-01, CR-02, CR-13, CR-14 | 03, 04, 08, d04, d08 |
| 5 | D5 SQLite WAL, every event | Durable tier only + versioning, retention, salvage, backup | MODIFY | CR-06, CR-17, CR-19, CR-26a/b | 03, 06, 07, d06, d07 |
| 6 | D6 protocol per provider | Retained; Claude gated by terms | RETAIN / OPEN QUESTION | CR-11 | 05, d05, D29 |
| 7 | D7 no ACP client fs/terminal | — | RETAIN | sound | — |
| 8 | D8 process per session everywhere | Per-provider topology after spikes | MODIFY | CR-12, E-03 | 04, 05, 09, d04 |
| 9 | D9 no bundling | — | RETAIN | — | — |
| 10 | D10 explicit handoff | — | RETAIN | — | — |
| 11 | D11 daemon lifetime = window | Lifetime = app; window close hides; opt-in launch agent later | MODIFY | CR-08, S-3 | 04, 10, 12, d04 |
| 12 | D12 timeout 180 s = deny; window close = deny | Approval record, CAS, disconnect never resolves, expiry policy; never allow | MODIFY | CR-07, S-4, S-7 | 02, 07, 08, d07, d08 |
| 13 | D13 own read-only Git via CLI | Safe Git (library; hardened CLI fallback) | MODIFY | CR-04, E-07 | 08, 09, d08 |
| 14 | D14 no bypass default | — | RETAIN | — | — |
| 15 | D15 plans in `planning/` | — | RETAIN | — | — |
| 16 | — | D16 one wire protocol + relay | NEW | CR-02 | d04 |
| 17 | — | D17 tiered events, bounded fan-out | NEW | CR-06 | d06, d09 |
| 18 | §6.4 linear lifecycle | D18 orthogonal state | REPLACE | CR-09 | d04 |
| 19 | — | D19 approval record | NEW | CR-07 | d08 |
| 20 | §10.1 same-user process listed, no countermeasure | D20 control-plane isolation | NEW | CR-01 | d08 |
| 21 | single bridge secret | D21 pairing and scopes | REPLACE | CR-14 | d08 |
| 22 | — | D22 untrusted rendering policy | NEW | CR-03 | d08, d10 |
| 23 | — | D23 safe Git | NEW | CR-04 | d08 |
| 24 | F1 hard refusal | D24 compatibility classes | REPLACE | CR-10 | d05, register |
| 25 | §9.2 no unified inbox | D25 SSH stdio bridge + client federation | REPLACE | CR-13 | d07, d-minor 01 |
| 26 | — | D26 journal versioning/retention/recovery | NEW | CR-17, CR-19 | d06, d07 |
| 27 | — | D27 schema-first contracts | NEW | CR-23 | d-minor 03/11 |
| 28 | U4 SSH vs mesh vs mTLS | D28 mobile approach incl. PWA + Web Push option | DEFER | CR-15 | d13 |
| 29 | R10 bundling license only | D29 Claude usage terms | OPEN QUESTION | CR-11, E-04 | d05, d08, d13 |
| 30 | `command_id` only | D30 intent journaling, `delivery_unknown`, preconditions | MODIFY | CR-16 | d07 |
| 31 | F5, F1, F8, F13, N3, N4 | Modified text | MODIFY | register §1.1 | 02 |
| 32 | — | F14–F18, N10–N12 | NEW | register §1.2 | 02 |
| 33 | B3, B4, B8 | Methodology change / extension | MODIFY | CR-18 | 09 |
| 34 | — | B11–B16 | NEW | CR-18, S-5, S-11 | 09 |
| 35 | R1–R14 | R3, R6 treatment widened; R15–R25 added | MODIFY / NEW | review | 14 |
| 36 | U1–U8 | U9–U15 added; U3 split from U14 (repo visibility) | NEW | review | 14 |
| 37 | Phase 1 monolithic | Phase 1a–1d slices; S7, S8 added; S1–S5 extended | MODIFY | CR-24 | 13, d13 |
| 38 | §12 nine primitives as design-system scope | Attention inbox, layouts, palette, rendering pipeline; primitives = floor | MODIFY | CR-21 | 10, d10 |
| 39 | §13.3 dedup by external IDs | Replay mode + item reconciliation | REPLACE | CR-05 | 05, 11, d05 |
| 40 | §2.4 history of foreign sessions not addressed | F15 read-only history import via official APIs | NEW | CR-25 | 01, 05 |
