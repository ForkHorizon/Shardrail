# 02 — Decision Register (proposed changes, ADR form)

> **Status:** PROPOSED — NOT OWNER-APPROVED. No entry here is binding.
> Original IDs D1–D15 are preserved (see baseline `level-1/14-decisions-risks-open-questions.md` §17.2). New IDs start at D16. Nothing is renumbered.
> Status vocabulary: **RETAIN · MODIFY · REPLACE · DEFER · OPEN QUESTION**. "Owner decision" says what the owner must approve or choose.

## 1. Disposition of original decisions

| ID | Disposition | Change summary | Detailed record |
| --- | --- | --- | --- |
| D1 | RETAIN (conditional) | Rust daemon, conditioned on D27 schema-first contracts; owner proficiency is an explicit input | §2 D1 |
| D2 | MODIFY | Tauri shell becomes a byte-level relay (D16); footprint measured across WebKit processes | §2 D2 |
| D3 | MODIFY | Bounded client projection; framework criteria include accessibility and pipeline | §2 D3 |
| D4 | MODIFY | Unix socket retained; adds relay (D16), client identity (D21), SSH stdio bridge (D25), agent isolation (D20) | §2 D4 |
| D5 | MODIFY | SQLite WAL retained; adds tiers (D17), versioning/retention/recovery (D26) | §2 D5 |
| D6 | RETAIN + OPEN QUESTION | Channels retained; Claude subject to D29 | D29 |
| D7 | RETAIN | — | — |
| D8 | MODIFY | Per-provider topology table | §2 D8 |
| D9 | RETAIN | — | — |
| D10 | RETAIN | — | — |
| D11 | MODIFY | Daemon lifetime = app, not window | §2 D11 |
| D12 | MODIFY | Invariant "never allow without explicit human decision" retained; timeout policy and resolution semantics replaced by D19 | §2 D12 |
| D13 | MODIFY | Safe Git access (D23) | §2 D13 |
| D14 | RETAIN | — | — |
| D15 | RETAIN | Candidate files also live in `planning/` | — |

## 2. Modified original decisions

**D1 — Rust daemon (RETAIN, conditional)**
- Current: Rust core, no Go in v1. Proposed: same, **plus** D27; record owner proficiency as a decision input.
- Evidence: official ACP crate (baseline E); review CR-23. Advantages: one systems language with shell, strong types for event/state enums. Disadvantages: compile/iteration cost. Performance: no measurable difference expected at Shardrail event rates (INFERRED). Security: Go is equally memory-safe; no security delta claimed. Complexity: medium. Affected: 03, 04, 14. Confidence: medium. Owner decision: confirm Rust vs Go given own proficiency. Reconsider: two phases slip due to Rust iteration cost, or B1/B4 fail for reasons Rust does not fix (baseline condition retained).

**D2 — Tauri 2 + WKWebView (MODIFY)**
- Proposed: shell owns window, menu-bar presence, notifications, keychain, deep links, and a **frame relay** to the daemon socket with no message parsing (D16). B3 measured as total footprint of app + all `com.apple.WebKit.*` helpers (phys_footprint).
- Evidence: Tauri 2.12.3 current stable (E-08); CR-02, CR-18. Performance: relay adds one in-process hop (expected sub-ms, REQUIRES FUTURE EXPERIMENT in S5). Security: no TCP listener for desktop. Complexity: low. Affected: 03, 04, 09. Confidence: medium. Owner: approve relay approach. Reconsider: S5 failure → thin Swift WKWebView shell (baseline fallback retained; relay is reimplemented in Swift, ~same size).

**D3 — Frontend state (MODIFY)**
- Proposed: daemon remains source of truth; the client holds a **bounded** projection (visible window + small cache) and per-view state; a small reactive store is acceptable if it only mirrors daemon projections. Framework chosen by S5 using B4/B5 **and** the cost of meeting N7 (accessible primitives availability).
- Evidence: CR-06, CR-22. Affected: 03, 10. Confidence: medium. Owner: none until S5.

**D4 — Local transport (MODIFY)**
- Proposed: Unix socket (`0700` dir, `0600` socket, peer credential check) remains the daemon's only default listener. Desktop uses the shell relay; remote desktop uses SSH stdio bridge (D25); browser uses an **opt-in** loopback WebSocket listener with paired credentials, Origin and Host checks. All clients authenticate (D21). Agents are kept off the control plane (D20).
- Evidence: CR-01, CR-02, CR-13, CR-14. Security: removes the single shared secret; adds per-client revocation. Complexity: medium. Affected: 03, 04, 08. Confidence: medium-high. Owner: approve.

**D5 — Persistence (MODIFY)**
- Proposed: SQLite WAL, single writer retained; durable tier only (D17); per-event schema version (D26); retention/purge (D26); corruption → read-only salvage + explicit choice (D26); explicit checkpoint policy.
- Evidence: CR-06, CR-17, CR-19, CR-26a/b. Affected: 03, 06, 07, 09. Confidence: high.

**D8 — Process topology (MODIFY)**
- Proposed: per-provider topology table (proposal §3.5); default remains process-per-session until each spike rules.
- Evidence: E-03 per-turn `sandboxPolicy`/`cwd`; CR-12. Performance: may reduce provider memory for Codex/Hermes (unmeasured). Security: shared processes only where isolation is protocol-level per turn. Affected: 04, 05, 09. Confidence: medium. Reconsider: spike outcomes.

**D11 — Mac daemon lifetime (MODIFY)**
- Proposed: daemon is a separate process launched by the app, lifetime = app. Closing the window hides it; a menu-bar item shows running sessions and pending approvals; quitting asks to cancel or keep (keep = only when the opt-in launch agent of Phase 2 exists). OS notifications for approvals while hidden.
- Evidence: CR-08, S-3. TCC note: agent-triggered TCC prompts are attributed to Shardrail.app (INFERRED) — documented as R23. Complexity: low-medium. Affected: 04, 10, 12. Confidence: high. Owner: approve; decide U6 for Phase 2.

**D12 — Approval timeout (MODIFY → see D19)**
- Retained invariant: **no expiry, disconnect, error, or replay ever produces allow.** Replaced: fixed 180 s deny and "window close = deny".

**D13 — Files and Git (MODIFY → see D23)**

## 3. New decisions

**D16 — One wire protocol; desktop shell relays frames**
- Proposal: a single schema-defined message protocol (request/response with `command_id`, server-push events with per-host cursor) carried over: Unix socket (length-prefixed frames), WebSocket (one message per frame), SSH stdio (length-prefixed). The desktop shell relays bytes between WebView and Unix socket without parsing.
- Evidence: CR-02; browsers cannot open Unix sockets (INFERRED). Advantages: one client codebase; shell replaceable. Disadvantages: relay must handle flow control. Performance: one extra hop. Security: no TCP for desktop. Complexity: low. Affected: 03, 04, L2-05. Confidence: high. Owner: approve. Reconsider: relay latency fails B4 in S5.

**D17 — Tiered events and bounded fan-out**
- Proposal: **ephemeral** deltas (text/output chunks) live in memory, coalesced per item to the client flush interval, broadcast only; **durable** events (session/turn/item lifecycle, completed items, approvals, commands, notices, periodic checkpoints of in-progress items) are journaled. Each client has a bounded outbound queue; overflow drops deltas and triggers snapshot + cursor resync.
- Evidence: E-03 (`item/completed` authoritative over deltas); CR-06; S-1, S-12. Advantages: bounded DB growth and memory. Disadvantages: crash loses in-progress text since last checkpoint (provider still holds it). Performance: new budgets B12/B15. Security: fewer copies of sensitive text. Complexity: medium. Affected: 06, 07, 09, L2-02. Confidence: high. Reconsider: if providers lack completion events with full content (then checkpoint more often).

**D18 — Orthogonal session state**
- Proposal: process {spawning, alive, exited}, link {initializing, ready, desynced}, turn {idle, running, cancelling, stalled}, approvals {pending set}, delivery {confirmed, unknown}; UI badge derived by precedence. `disconnected` is client-local.
- Evidence: CR-09, S-2. Affected: 04, 06, 07, 10, L2-02. Confidence: high.

**D19 — Approval record semantics**
- Proposal: daemon-owned record `pending → allowed | denied | expired | withdrawn`, single assignment by compare-and-set on `approval_id`; responses idempotent by `command_id`; client disconnect never resolves; expiry policy per workspace: `deny_after(T)` (default T = provider limit or 180 s, whichever smaller — baseline value retained as default) or `hold_until_provider_limit` (opt-in, for remote/unattended work); all attached clients notified; stale responses get a typed rejection with final state; provider-side clearing (`serverRequest/resolved`) maps to `withdrawn`.
- Evidence: E-03, E-06, CR-07, S-4, S-7. Security: invariant preserved; adds explicit "never allow by default". Complexity: medium. Affected: 02 (F5), 07, 08, L2-04. Confidence: high. **Owner decision:** default expiry policy (U10).

**D20 — Agents must not operate the control plane**
- Proposal: (1) no Shardrail endpoint, secret, or socket path in provider environments; (2) client credentials stored where agents cannot read them (macOS keychain with app-scoped ACL; Linux: separate agent Unix user recommended for remote hosts); (3) gateway rejects connections whose peer PID descends from a supervised provider tree (defense in depth, not a boundary); (4) the socket directory is outside every workspace and listed in Shardrail-selected sandbox deny paths where providers allow it; (5) residual risk stated for unsandboxed agents on a shared UID.
- Evidence: CR-01; X-01 experiment pending. Security: primary. Complexity: medium. Affected: 04, 08, L2-01, L2-04, L2-05. Confidence: medium (effectiveness per provider sandbox is REQUIRES FUTURE EXPERIMENT). **Owner decision:** whether separate Unix user becomes default for remote hosts (U11).

**D21 — Client identity, pairing, scopes**
- Proposal: every client holds a paired credential (per device, revocable, last-seen); scopes `observe`, `prompt`, `respond_approval`, `control_policy`; `control_policy` (trust changes, sandbox weakening, allow-all) only from a local desktop client; pairing via a one-time code shown in an already-authenticated client.
- Evidence: CR-14. Affected: 04, 08, L2-05. Confidence: high.

**D22 — Untrusted content rendering policy**
- Proposal: all provider/tool/file content is untrusted. Allowlisted Markdown subset, no raw HTML, strict CSP (no remote origins; `img` only from local cache after explicit user action), ANSI rendered by a safe parser, approval cards render structured fields with visible escapes for control/bidi/zero-width characters and a raw view; size caps with incremental parsing.
- Evidence: CR-03, S-8. Affected: 08, 10, L2 UI (future). Confidence: high.

**D23 — Safe Git access**
- Proposal: status/diff/tree through a library that does not execute hooks, fsmonitor commands, or filters; any `git` CLI fallback forced with `-c core.fsmonitor=false -c core.hooksPath=/dev/null --no-ext-diff --no-textconv` and protected-scope overrides; never run CLI Git in `unknown` workspaces. Status computation coalesced (one in flight per worktree).
- Evidence: E-07, CR-04, S-11. Affected: 08, 09, L2 workspace (future). Confidence: high for the threat; library choice REQUIRES FUTURE EXPERIMENT (feature coverage of worktrees/diff).

**D24 — Provider compatibility policy**
- Proposal: per provider, version classes `tested`, `untested-newer` (start with warning + shadow validation logging), `known-bad` (refuse); never opt into experimental surfaces (e.g., Codex `experimentalApi`) in product builds; on version change, compare generated schema (Codex) with bundled reference before first session; unmapped messages become `notice` events, not crashes.
- Evidence: E-03, CR-10, S-6. Affected: 02 (F1), 05, 12, L2-03. Confidence: medium-high. **Owner decision:** accept warn-and-run for untested versions.

**D25 — Multi-host: SSH stdio bridge and client federation**
- Proposal: desktop app manages a host list; remote connection = spawn system OpenSSH `ssh <host> shardraild bridge` (relays stdio to the remote daemon socket); no forwarded ports; client federates N hosts keyed by `(host_id, session_id)` with per-host cursors; global attention inbox (F14) built client-side. No daemon-to-daemon sync.
- Evidence: CR-13, S-10. Security: relies on SSH auth; remote daemon never listens on network. Complexity: low-medium. Affected: 01, 04, 07, L2-05. Confidence: high.

**D26 — Journal versioning, retention, recovery**
- Proposal: each durable event carries `schema_version`; readers upcast old versions; migrations never rewrite history destructively; retention policy (default keep; per-session purge; delta checkpoints compacted after item completion); corruption → open read-only, integrity check, offer salvage/export, start a new DB only after explicit choice; periodic online backup (SQLite backup API) to the data dir.
- Evidence: CR-17, CR-19, CR-26a/b. Affected: 06, 07, 08, L2-02. Confidence: high.

**D27 — Schema-first contracts**
- Proposal: client protocol, durable event payloads, and adapter-normalized events are defined as JSON Schema in the repository; Rust and TypeScript types generated; contract tests run against fixtures.
- Evidence: CR-23; Codex already publishes generated schema (E-03). Affected: 03, 11, L2-02, L2-03, L2-05. Confidence: medium-high.

**D28 — Mobile approach (DEFER)**
- Proposal: decide at Phase 3 entry between (a) PWA served by the daemon through a user-managed mesh VPN or SSH, with Web Push for approval notifications (no own relay — INFERRED, verify X-07), (b) Tauri Android shell, (c) Kotlin WebView shell. Requirements fixed now: paired scoped credential (D21), approval record (D19), notification payload contains no secrets or command text by default.
- Evidence: CR-15. Owner: decide U4 at Phase 3 entry.

**D29 — Claude channel authentication and terms (OPEN QUESTION)**
- Proposal: before Claude enters Phase 1, owner obtains a legal/policy answer on whether Shardrail may drive a user's Claude Code via the Agent SDK (or ACP adapter) with subscription login. Until then, product builds support Claude **only** with API-key authentication configured by the user, matching the documented requirement; personal development builds unaffected. Also: the adapter is ACP-organization code, not Anthropic's; branding must follow the SDK branding rules.
- Evidence: E-04, E-10, CR-11. Affected: 05, 12, 13, R16, U9. Confidence in the evidence: high; in the interpretation: low. **Owner decision required.**

**D30 — Command intent, delivery, and preconditions**
- Proposal: mutating commands carry `command_id` (retained per session lifetime) and optional preconditions (`expected_turn_id`, `expected_state`); daemon journals `command_accepted` before side effects and `command_dispatched` after; after a crash, accepted-but-unconfirmed commands become `delivery_unknown` and require a human decision; no automatic resend (baseline retained).
- Evidence: CR-16, S-7, S-9; Codex `turn/steer` uses `expectedTurnId` (E-03) as precedent. Affected: 07, L2-02, L2-05. Confidence: high.
