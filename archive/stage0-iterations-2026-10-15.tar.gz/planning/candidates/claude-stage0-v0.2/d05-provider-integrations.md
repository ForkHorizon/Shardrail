# d05 — Provider Integrations (delta vs baseline 05)

> **Status:** PROPOSED · Baseline: `level-1/05-provider-integrations.md` (§7). Matrix and per-provider policy retained unless changed here.
> Decisions: D6 (retained), D7 (retained), D8, D24, D29. Evidence IDs E-xx: `reviews/claude-stage0-r01/01-INDEPENDENT-REVIEW.md` §2.

## 1. Adapter contract additions (§7.1)

- Capability negotiation at `initialize` is authoritative; static per-version tables are hints only.
- Required new optional capabilities: `resume_without_replay` (ACP `session/resume`, E-01), `load_with_replay` (ACP `session/load`), `list_external_sessions`, `read_external_history` (F15), `steer_active_turn`, `concurrent_sessions_per_process`.
- **Replay mode**: during `session/load`, the adapter tags incoming updates as replay, the session engine reconciles them against the journal (tool-call IDs, item IDs, turn boundaries) and journals only a `provider_history_reconciled` event plus detected gaps. Live updates resume after the load response.
- Unmapped messages → `notice` with raw payload in `provider_ext` (bounded size); never crash the session.
- Compatibility class per binary version (D24).

## 2. Matrix additions (§7.2) — evidence 2026-10-15

| Capability | Codex | Claude | Grok | Hermes |
| --- | --- | --- | --- | --- |
| History listing/reading | `thread/list`, `thread/read` **VERIFIED** (E-03) | `listSessions`, `getSessionMessages` **VERIFIED** (E-05) | UNVERIFIED | list/load/resume/fork after restart **VERIFIED** (E-06) |
| Resume without replay | `thread/resume` (replay semantics UNVERIFIED) | SDK `resume` | ACP `session/resume` if advertised (UNVERIFIED for Grok) | UNVERIFIED |
| Steering active turn | `turn/steer` with `expectedTurnId` **VERIFIED** | adapter "session steering" UNVERIFIED (E-10) | UNVERIFIED | UNVERIFIED |
| Per-turn sandbox/cwd | `turn/start` `sandboxPolicy`, `cwd` **VERIFIED** | permission mode per session | profile per process (baseline) | UNVERIFIED |
| Approval decisions | `accept / acceptForSession / decline / cancel` (+ execpolicy amendment) **VERIFIED** | SDK `canUseTool` | ACP options | once / session / always / deny; timeout 300 s default **VERIFIED** |
| Pending approval on turn end | cleared, `serverRequest/resolved` **VERIFIED** | UNVERIFIED | UNVERIFIED | UNVERIFIED |
| Experimental surface gating | `capabilities.experimentalApi` opt-in **VERIFIED** — never enabled in product builds | — | `x.ai/*` vendor extensions (baseline) | — |
| Transports | stdio (default), `unix://` (WebSocket over UDS), `ws://` experimental **VERIFIED** | process | stdio | stdio |

## 3. Provider policy changes (§7.3)

- **Codex:** stdio retained; `--listen unix://` noted but not used (child ownership via stdio is simpler). Approval mapping: `acceptForSession` labeled "for this session (Codex rule)"; `acceptWithExecpolicyAmendment` hidden until the UI can show the exact amendment. `clientInfo.name` disclosed in privacy notes (E-03).
- **Hermes:** effective toolset displayed per session (default includes web/browser tools and `execute_code`, E-06). Shardrail does not modify `~/.hermes/config.yaml`; it shows a recommendation. Shardrail's own approval expiry must be ≤ Hermes `approvals.timeout` (baseline min-of-two rule retained).
- **Claude:** channel choice remains S4 (adapter vs direct SDK). Additional gate: **D29** terms. The adapter is described as "ACP-organization adapter", not "official Anthropic". Product UI follows SDK branding rules (E-04). `--bare` as explicit view mode retained.
- **Grok:** unchanged; S2 additionally reports `session/resume` support.

## 4. Unchanged
§7.4 incompatibilities retained in full (no single autonomy slider; cost "no data" not zero; protocol cancel before signals).
