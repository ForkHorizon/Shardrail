# d06 — Sessions, Events and Handoff (delta vs baseline 06)

> **Status:** PROPOSED · Baseline: `level-1/06-session-events-and-handoff.md` (§8). Identifiers (§8.1), handoff (§8.3) retained.
> Decisions: D17, D18, D26, D27, D30.

## 1. Identifiers (additions to §8.1)
- `HostId` — stable per daemon installation (random, stored in data dir); clients key everything by `(HostId, SessionId)`.
- `ItemId` — Shardrail ID for a message/tool/plan item, linked to provider item/tool-call ID where present.
- `CommandId` — client-generated UUID on every mutating request (retained from §9.3, now formal).
- `EventId` remains a per-host monotonic cursor (retained). Cursors are never compared across hosts.

## 2. Event tiers (replaces the implicit "every update is an event" model of §8.2)

| Tier | Examples | Stored | Delivered |
| --- | --- | --- | --- |
| Ephemeral | text/thought deltas, command output deltas, plan deltas | memory only; latest in-progress buffer per item | coalesced per item at client flush interval (target ≤ 1 flush per frame) |
| Durable | session/turn lifecycle, item started/completed (full content), approval records and resolutions, commands (`accepted`, `dispatched`, `rejected`), notices, state transitions, `provider_history_reconciled`, checkpoints of in-progress items (every N s or M KiB, PROPOSED 2 s / 64 KiB) | journal | by cursor; replayable |

Checkpoints are compacted (deleted) once the item's completed event is committed.

## 3. Event envelope (conceptual; schema-first per D27)
`event_id`, `host_id`, `session_id`, `schema_version`, `kind`, `occurred_at` (daemon clock), `provider_ref` (optional external IDs), `causation` (`command_id` or provider request ID), `payload`, `redaction` flags.

## 4. Projection serving
Daemon maintains per-session item projections (completed items + live in-progress buffers). Clients request pages of items by position or `ItemId`, not raw event ranges, for history views (S-5). Raw event ranges remain available for catch-up by cursor (F12).

## 5. Storage limits (refines §8.2)
Per-item stored content cap retained at 256 KiB (baseline value) with truncation marker; the full output remains with the provider. Redaction remains best effort (see d08).

## 6. Unchanged
Immutability, correction-as-new-event, handoff bundle semantics, Fork vs Transfer naming, no kanban/scheduler.
