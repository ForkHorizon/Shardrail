# 90 — Consistency Check, Staging and Self-Review (v0.4)

> **Status:** PROPOSED · Claude (Opus 5.5), 2026-10-15. Continues C-15…C-25 (v0.3); corrected items are in `06-ERRATA-v0.4.md`.

## 1. Contradictions and tensions

| ID | Relationship | Issue | Resolution (recommended) | Status |
| --- | --- | --- | --- | --- |
| C-26 | D20 sticky host state ↔ P1a provider choice | If the first ACP provider lacks an OS sandbox (Hermes likely), the host is `unprotected` whenever it runs, and under the U21 rule Phase 1 cannot claim protected approvals | Prefer a sandboxed provider (Grok, per S2) as the P1a ACP provider; decide after S7 | open (spike + owner) |
| C-27 | D20 (d) snapshot of provider config ↔ N3 (never read credential stores) | Provider config files may contain secrets (e.g. keys in a YAML config) | Snapshot stores **hashes only**, never content; credential files (`auth.json` etc.) are never read | resolved |
| C-28 | D20 (d) pinning ↔ baseline "Shardrail does not change provider configuration" | Pinning could be mistaken for modifying configs | Pinning uses documented launch-time flags/SDK options only; no provider file is written (U20 is the only exception and is opt-in) | resolved |
| C-29 | D21 SSH = `limited` ↔ remote desktop control | A remote host's policy actions need `full` | `full` over the bridge via the desktop's keychain-held key in the handshake | resolved |
| C-30 | D32 macOS sweep interval ↔ B9 | Sweeps at ≥ 15 s can miss short-lived detached processes | Known pids watched by process-exit events; the sweep only finds re-parented survivors; residual shown | accepted residual |
| C-31 | D23 Git worker ↔ B1/B11 | Extra process | Event-driven, idle when no Git query; measured as its own column | open (measure) |
| C-32 | D26 Time Machine exclusion ↔ user expectation of backups | Users may want history in backups | Visible setting; export available | owner (U23) |
| C-33 | 04 §3 `detached` ↔ D31 lease | Detached session still holds the lease | Intended: I4; lease freed only after process and descendants exit | resolved |
| C-34 | D19 `delivered_unconfirmed` ↔ D30 delivery table | Two tracking mechanisms | Approval responses excluded from §5 (04 §5 header) | resolved |

## 2. Staging (what belongs in Phase 1a)

v0.4 adds substantial machinery. To keep P1a feasible for one developer:

| Mechanism | P1a | Later |
| --- | --- | --- |
| v0.4 transition tables, `delivered_unconfirmed`, `T_ack`, `detached` | yes | — |
| Host protection state + `boundary-breaking` class + scope statement | yes (cheap, central to safety claims) | MAC re-establish (Phase 2, macOS) |
| Pinning provider approval settings at launch + config hash snapshot | yes, for the P1a provider | others with their adapters |
| `SSH_AUTH_SOCK` scrubbing, deep-link restriction, hardened runtime | yes | — |
| Asymmetric client keys, mutual handshake, SSH = limited | no (single local desktop client in P1a; peer UID + code-signing admission suffices) | Phase 2 with remote/browser clients |
| Git: bounded discovery, no program execution, symlink rules, LFS native clean | yes | — |
| Git worker with OS exec-deny + CI tripwire | yes (the CI tripwire is the cheap part; worker isolation may follow in 1b if S8 shows gix is clean with all permissions off) | — |
| macOS helper containment | yes | — |
| Linux cgroup containment, linger | — | Phase 2 (remote) |
| U11 privileged spawner | — | after mechanism is specified |

## 3. Self-review

- **Diminishing returns of same-family reviews.** r02 changed direction in several places; r03 mostly found specification errors in v0.3's new mechanisms. The next uncertainty reductions are empirical (S7, S8, S9) and an independent review by a different model family, not another Claude pass.
- **The central product claim is now conditional.** Whether Shardrail can say "approvals are protected from the agents" depends on S7. v0.4 makes sure a negative result is reported honestly instead of being hidden by per-session labels.
- **Assumptions still unverified:** Codex project rules changing approvals; Claude settings protection; ACP acknowledgement behavior; macOS TCC attribution and responsibility options; helper descendant tracking accuracy; gix behavior with all permissions off; systemd `Restart=` × `KillMode` interplay.
- **What v0.4 did not change:** direction of D16–D19, D22, D24–D30, D33; baseline principles (official protocols only, no TUI capture, timeout never allow, no bundling, explicit handoff).

## 4. Readiness
Ready for owner decisions (now including U20–U24) and for authorization of Phase 0 spikes, with S7, S8 and S9 as the highest-value experiments. Level 2 detail of L2-01/L2-04/L2-05 should wait for S7 and S9.
