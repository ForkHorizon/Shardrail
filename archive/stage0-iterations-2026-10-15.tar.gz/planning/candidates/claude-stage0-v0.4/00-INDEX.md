# Shardrail Architecture Candidate v0.4 — Claude Revision after Round r03

> **Status:** PROPOSED CANDIDATE — NOT OWNER-APPROVED. Implementation NOT authorized. Stage 0.
> **Author:** Claude (Opus 5.5), 2026-10-15.
> **Layering:** v0.4 is a delta over v0.3 (`../claude-stage0-v0.3/`) → v0.2 → Grok baseline (`../../level-1/`). Earlier candidates and reviews r01–r03 are unchanged. Exception: `04-STATE-TRANSITIONS-v0.4.md` is **self-contained** and supersedes the v0.3 tables.
> **Input:** focused review `../../reviews/claude-fresh-r03/` (34 findings: 4 BLOCKING, 21 IMPORTANT, 8 MINOR, 1 QUESTION) on D20, D23, D32 and the transition tables.

## Reading order

| # | Document | Purpose |
| --- | --- | --- |
| 1 | [01-R3-DISPOSITION](01-R3-DISPOSITION.md) | What v0.4 does with each R3 finding |
| 2 | [02-DECISION-REGISTER-v0.4](02-DECISION-REGISTER-v0.4.md) | D11, D19, D20, D21, D23, D26, D31, D32 changes |
| 3 | [03-REGISTER-UPDATES-v0.4](03-REGISTER-UPDATES-v0.4.md) | N4, N10, F8, F17, F19–F22; R33–R38; U20–U24 |
| 4 | [04-STATE-TRANSITIONS-v0.4](04-STATE-TRANSITIONS-v0.4.md) | Full, self-contained transition tables, timers, badges, invariants |
| 5 | [05-SPIKES-ROADMAP-DELTA-v0.4](05-SPIKES-ROADMAP-DELTA-v0.4.md) | Spike scope (S1–S9), P1a gate, backlog and L2 impacts |
| 6 | [06-ERRATA-v0.4](06-ERRATA-v0.4.md) | Errata to v0.3; evidence renumbering EV-19…EV-28 |
| 7 | [90-CONSISTENCY-v0.4](90-CONSISTENCY-v0.4.md) | C-26…C-34, P1a staging, self-review, readiness |

## Change log v0.3 → v0.4 (summary)

| Area | v0.3 | v0.4 |
| --- | --- | --- |
| Approval protection | per-session label, boundary (a)–(c) | host × UID sticky state; boundary (a)–(e) incl. provider approval config and persistence paths; inherited capabilities; pre-registered marketing rule |
| Approval outcomes | `responded_unacked` could become `withdrawn` | `delivered_unconfirmed`; `boundary-breaking` class; fail-closed unknown options |
| Client auth | SSH ⇒ full; SSH host key as server auth | SSH ⇒ limited; asymmetric keys; transcript-bound mutual handshake; daemon key pinned through bridge |
| Git safety | no repo-local programs | no programs from any scope/attribute/env; bounded discovery; symlink rules; native LFS; exec-denied worker |
| Containment | process groups + PDEATHSIG | all descendants; Linux cgroup guarantee; macOS best effort; identity and spawn-intent fixes |
| State model | v0.3 tables | four cell kinds; `detached`, `leader_exited`, `kill_failed`, `exited(lost)`; timers table; corrected badges; invariants I1–I6 |
| Purge | wrong order | corrected; pre-migration copies; Time Machine |

## Owner decisions needed (v0.4 additions in bold)

U9 · U10/U17 · U11 (now "mechanism TBD") · U13 · U14 · U3 · U6 · U16 · U18 · U19 · **U20 pre-create `.codex/`** · **U21 protection-claim threshold** · **U22 auto-terminate on desync** · **U23 Time Machine exclusion** · **U24 refuse second session when read-only is unenforceable**.
