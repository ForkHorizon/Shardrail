# 03 — Requirement, Risk and Question Updates (v0.4)

> **Status:** PROPOSED — NOT OWNER-APPROVED. Changes over `../claude-stage0-v0.3/03-REGISTER-UPDATES.md`; unlisted entries stand.

## 1. Requirements

| ID | v0.3 | v0.4 |
| --- | --- | --- |
| N10 | approval guarantee stated per session | Host × UID protection state (`protected`/`unprotected`, sticky); per-session causes shown; scope statement in UI and docs (D20) |
| N4 | `full` via peer identity or SSH; `limited` paired | SSH alone = `limited`; `full` requires desktop keychain key; asymmetric keys; mutual transcript-bound handshake; remote daemon key pinned through the bridge (D21) |
| F8 | read-only tree/diff, no repo-controlled execution | + no program from any Git config scope/attribute/env; bounded discovery; no symlink escape; LFS compared natively; never "modified" from unfiltered bytes (D23) |
| F17 | purge procedure | corrected procedure incl. pre-migration copies; Time Machine exclusion default (U23) |
| F19 | write lease | journaled lease; release rule; refusal when read-only unenforceable (U24) |
| F20 | orphan detection | all-descendant containment: Linux guarantee via cgroup, macOS best effort with residual shown; `killed_mid_tool` outcome |
| F21 | — | **NEW** Approval outcomes are never misreported: a delivered decision is shown as allowed/denied or "outcome not confirmed", never as withdrawn (04 §4) |
| F22 | — | **NEW** Approvals that act outside the sandbox are labelled `boundary-breaking`, `full`-scope only, and end host protection on allow (D19, D20) |

## 2. Risks (new / changed)

| ID | Risk | Severity | Treatment |
| --- | --- | --- | --- |
| R15 (changed) | Compromise of shared host state via **any** unprotected session or approved escalation affects all sessions | high | D20 host-level sticky state |
| R26 (changed) | Detached descendants survive containment | high (macOS) / low (Linux) | D32 cgroup; macOS best effort + residual label |
| R31 (changed) | Few provider profiles satisfy the boundary | high (product) | pre-registered decision rule (D20.6, U21) |
| R33 | Provider approval configuration (project `.codex/rules`, `.claude/settings*.json`, user configs) modified by the agent so the provider stops asking | high | D20 (d): pin + snapshot; U20 |
| R34 | Inherited capabilities (SSH agent, TCC grants, deep links) let an agent act as a client | high | D20.4, D21 |
| R35 | False LFS diffs drive wrong user decisions | medium | D23 native LFS clean |
| R36 | Delivered allow reported as withdrawn | high | F21, 04 §4 |
| R37 | Escalating cancel on a shared provider process kills other sessions' turns | medium | 04 §1 shared-process guard |
| R38 | Linux remote sessions die at logout without linger | medium | D32 linger check |

## 3. Open questions (new / changed)

| ID | Question | Recommendation |
| --- | --- | --- |
| U11 (changed) | Separate agent UID by default on remote hosts | **Recommended, mechanism TBD** (privileged spawner, containment, Git trust) — not a default until specified (R3-16) |
| U20 | May Shardrail pre-create a protected `.codex/` in trusted workspaces? | Ask per workspace at trust time; default no |
| U21 | Threshold for marketing "protected approvals" after S7 | All P1a providers in their default Shardrail profile; otherwise host banner only |
| U22 | Desync with live process: automatic termination? | User-confirmed while a client is attached; automatic after `T_grace` only when no client is attached |
| U23 | Exclude data directory from Time Machine by default? | Yes, with a visible setting |
| U24 | Second session on a worktree when the provider cannot enforce read-only | Refuse; offer a separate worktree |
