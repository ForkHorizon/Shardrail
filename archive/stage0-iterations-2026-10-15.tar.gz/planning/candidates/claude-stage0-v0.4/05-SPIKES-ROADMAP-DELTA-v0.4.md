# 05 — Spikes, Roadmap and Backlog Changes (v0.4)

> **Status:** PROPOSED — NOT AUTHORIZED. Changes over `../claude-stage0-v0.3/05-ROADMAP-BACKLOG-MODULE-DELTA.md`. Backlog and Level 2 files are not edited.

## 1. Spike additions

| Spike | Added in v0.4 | Driver |
| --- | --- | --- |
| S1 | Codex escalation request fields (which requests are `boundary-breaking`); whether project `.codex/rules` change approval decisions; documented `-c` overrides for approval/sandbox pinning; background terminals after turn end and after daemon kill; per-provider approval wait limit (X-05, from R2-09) | D19, D20, D32 |
| S2, S3 | ACP agents' `tool_call_update` after allow/deny (acknowledgement definition); Hermes sandboxing and approval-config pinning | D19, D20 |
| S4 | Claude: `.claude/settings*.json` write protection under its sandbox; pinning permission mode/`settingSources` in **all** trust states; candidate switch `CLAUDE_CODE_DISABLE_AUTO_MEMORY=1` (from R2-11) and connector disablement | D20, F13 |
| S1–S4 | "tool that detaches" (`setsid`, `nohup`, dev server) + daemon kill; observe containment | D32 |
| S7 | Per provider × profile: (a)–(e) of D20 incl. reads of identity material, LaunchAgents, rc files, `~/.ssh/config`, app bundle, WebKit storage; `SSH_AUTH_SOCK` reachability; TCC attribution of descendants and "responsibility" options; keychain prompt behavior against same-user access; code-signing peer check via audit token; outcome table feeds the pre-registered rule (U21) | D20, D21 |
| S8 | Add: user-level config, `include`/`includeIf`, `config.worktree`, `GIT_*` env, upward discovery, out-of-workspace gitdir/`core.worktree`, symlink and hardlink escapes, LFS repository, exec-denied worker with `execve` CI tripwire; gix status/diff coverage with all permissions off | D23 |
| **S9 (new)** | Linux containment: per-provider cgroup via systemd user scope/delegation, `cgroup.kill`, `KillMode` and `Restart=` interaction, linger, pidfds; macOS helper prototype plan (descendant tracking accuracy) | D32 |

## 2. Phase 1a gate additions
F21, F22 on fixtures; containment fixture (T1.3.1 extended to detached tools); Git worker `execve` tripwire.

## 3. Backlog deltas (to apply with v0.3 deltas)

| Item | Change |
| --- | --- |
| E0.6 (S7) | scope per §1; produces the U21 decision input |
| E0.7 (S8) | scope per §1 |
| **E0.9 (new)** | S9 containment spike |
| E1.3 | D32 v0.4 (spawner thread, spawn intent, cgroup/helper, boot id, pidfds) |
| E1.7 | `boundary-breaking` class, `delivered_unconfirmed`, `T_ack`, host protection state |
| E1.8 | asymmetric keys, mutual handshake, SSH = limited, deep-link restriction |
| E1.9 | exec-denied Git worker, native LFS clean, bounded discovery |
| E1.18 | journaled lease, release rule |
| T1.5.3 | conformance tests over the four cell kinds of `04-STATE-TRANSITIONS-v0.4.md` |
| **T1.7.2 (new)** | crash between response write and acknowledgement → `delivered_unconfirmed`, never `withdrawn` |
| **T1.9.2 (new)** | CI tripwire: any `execve` from the Git worker fails the build |

## 4. Level 2 outline impacts (in addition to v0.3 §5)

| Outline | Change |
| --- | --- |
| L2-01 | D32 v0.4 in full; restart resolution order (04 §0) |
| L2-02 | v0.4 tables; `delivered_unconfirmed`; purge procedure |
| L2-04 | host-level protection state machine; boundary (a)–(e); pinning/snapshot of provider approval config; `boundary-breaking` class |
| L2-05 | asymmetric keys; mutual handshake; SSH = limited; deep links |
| Workspace (future L2) | D23 v0.4 incl. worker isolation |
