# 02 — Decision Register v0.4 (changes over v0.3)

> **Status:** PROPOSED — NOT OWNER-APPROVED. Only decisions that change in v0.4 are listed; all other entries of v0.3 (and through it v0.2) stand. No new decision IDs; D18 is now specified by `04-STATE-TRANSITIONS-v0.4.md`.
> Evidence: EV-19…EV-28 = r03 EV3-01…EV3-10 (PR_SET_PDEATHSIG man page, systemd.kill, git-config, git(1) environment, gix open permissions, gix-filter options, SQLite pragmas, ACP prompt-turn, Codex app-server background terminals, Codex sandbox docs on `.codex`).

## Summary

| ID | v0.3 | v0.4 | Driver |
| --- | --- | --- | --- |
| D11 | connect-first; orphan policy | + version-skew rule; `withdrawn(orphan_timeout)` | R3-19 |
| D18 | v0.3 tables | v0.4 tables (supersede) | R3-20…R3-29 |
| D19 | once/widening; ack; reject mapping; hold | + `boundary-breaking` class; fail-closed unknown kinds; `delivered_unconfirmed`; `T_ack` | R3-04, R3-20, R3-24, R3-31 |
| D20 | per-session boundary (a)–(c) | **host-level, sticky protection state**; boundary (a)–(e); pinned provider approval settings; inherited-capability rules; pre-registered decision rule | R3-01…R3-08 |
| D21 | `full`/`limited`; SSH = full | SSH alone = `limited`; asymmetric keys; daemon identity key; mutual transcript-bound handshake; deep-link restriction; dev builds unprotected | R3-05, R3-06, R3-33 |
| D23 | no repo-local programs | no programs from **any** Git config scope, attribute or env var; bounded discovery; symlink/hardlink rules; native LFS clean; exec-denied Git worker | R3-09…R3-11 |
| D26 | purge procedure | corrected order; pre-migration copies; Time Machine | R3-30 |
| D31 | lease | journaled; release rule; refusal when read-only is unenforceable (owner) | R3-17, R3-34 |
| D32 | process groups + PDEATHSIG + macOS helper | all-descendant containment; per-provider cgroup on Linux; best effort on macOS; identity, TOCTOU, spawn intent; helper spec; U11 interaction | R3-12…R3-18 |

## Records

**D11 — Daemon lifetime (MODIFY)**
- Orphan-daemon cancellation produces approvals `withdrawn(orphan_timeout)`.
- Version skew: a new shell finding an older daemon (after an app update) offers "restart daemon"; restart uses D32 termination semantics and the §1 restart resolution of `04-STATE-TRANSITIONS-v0.4.md`. The shell never speaks an incompatible protocol version.

**D19 — Approval record (MODIFY)**
- Option classes: `once`, `widening`, **`boundary-breaking`** (any approval that runs an action outside the session's sandbox: escalated/unsandboxed commands, Codex `thread/shellCommand`-like requests, permission grants that remove filesystem/network restrictions). `boundary-breaking` requires `full`, shows an explicit consequence line ("approving ends approval protection on this host"), and on allow moves host protection to `unprotected` (D20).
- Unknown option kinds fail closed to `widening`; to `boundary-breaking` if sandbox or permission semantics are indicated. `untested-newer` providers hide both.
- Delivered decisions are never "withdrawn": `responded_unacked` resolves to `allowed`/`denied` on acknowledgement, `withdrawn` only on a JSON-RPC error, otherwise `delivered_unconfirmed(decision)` (turn end, cancel, process loss, restart, `T_ack`).
- Events anchored per ACP: pending requests are answered `cancelled` when cancel is **requested** (EV-26).

**D20 — Approval-integrity protection (MODIFY — restated)**
1. **Unit:** protection is a **host × UID** state, `protected` or `unprotected`. It is `protected` only while every live Shardrail-launched process on that host/UID runs under a profile that satisfies the boundary below, and no `boundary-breaking` approval has been allowed since the state was last established.
2. **Boundary** (per launched process, verified per provider profile in S7):
   - (a) no write to Shardrail's data directory; (b) no write to Shardrail's app/daemon binaries or to any file of a provider's install tree or interpreter that Shardrail launches; (c) no bind/connect to Shardrail's socket directory and no read of Shardrail's identity material where it is file-based;
   - (d) no write to any file the provider reads to decide whether to ask for approval or what to run — user level (`~/.codex/config.toml`, `~/.claude/settings*.json`, `~/.hermes/config.yaml` allowlist/approvals, Grok config) and project level (`.codex/`, `.claude/settings*.json`, equivalents) — **or** the provider's approval-relevant settings are pinned at launch through documented command-line/SDK overrides and verified by a snapshot taken at session start and checked at session end;
   - (e) writes confined to the session's writable roots and temp, so no deferred-execution persistence (LaunchAgents, shell rc files, PATH directories, `~/.ssh/config`, `~/.gitconfig`, crontab, the app bundle, WebKit/Tauri storage).
3. **Sticky loss:** once `unprotected`, the state stays so until the user explicitly re-establishes it: all Shardrail-launched processes stopped, daemon restarted, binaries and data-directory integrity verified (Phase 2 on macOS: keychain-held MAC with a monotonic counter against rollback; Linux shared UID: no integrity verification possible — documented).
4. **Inherited capabilities:** provider environments drop `SSH_AUTH_SOCK` and GPG agent sockets by default (opt-in per session marks the host `unprotected`); granting Shardrail Accessibility, Automation or Screen Recording voids protection (shown); hardened runtime without `get-task-allow`; Linux `ptrace_scope` shown in diagnostics.
5. **Scope statement (UI and docs):** the claim covers Shardrail's approval decisions while the host is `protected`. It does not cover processes outside Shardrail (the user's terminals, IDEs, other agents) or code the user later runs from the workspace (e.g. `.envrc`, `package.json` scripts, `.vscode/tasks.json`).
6. **Pre-registered decision rule (before S7):** for each P1a provider × sandbox profile, S7 yields protected / not. If fewer than the threshold of U21 (recommended: all P1a providers in their default Shardrail profile) can reach `protected`, the product does not market "protected approvals"; the indicator becomes a host-level banner with one acknowledgement per host × provider, not per session.
7. **Open owner question U20:** may Shardrail pre-create an empty, read-only-protected `.codex/` in trusted workspaces to activate Codex's own protection (EV-28)? It writes into the user's repository.
- Confidence: high on analysis; enforcement REQUIRES FUTURE EXPERIMENT (S7).

**D21 — Client identity (MODIFY)**
- Keys: clients hold **asymmetric** keys (desktop: keychain); the daemon stores public keys only. The daemon's identity key lives in the macOS keychain; on Linux it is a `0600` file readable by the same UID (documented weakness; reinforces U11).
- Handshake: mutual, transcript-bound (Noise-style pattern; selection at L2-05). The remote daemon's key is pinned end to end **through** the SSH bridge, in addition to SSH host authentication.
- Scopes: local desktop admitted by peer UID + code-signing identity → `full`. SSH bridge alone → `limited`; `full` over the bridge requires the desktop's keychain-held client key in the handshake. Paired browser/mobile → `limited`.
- Deep links (`shardrail://…`) never carry approval, policy, or pairing actions.
- Developer builds: a build-time constant enables developer admission; developer builds always report the host as `unprotected`.

**D23 — Safe Git (MODIFY)**
- Rule: **Shardrail executes no program named by any Git configuration scope, attribute, or environment variable, and performs only local read operations** (no fetch, push, commit, credential, editor, pager paths).
- Opening: gix permissions `system=false, git=false, user=false, env=false, includes=false, git_binary=false`; filter driver list empty; the daemon strips `GIT_*` from its own environment at startup (EV-21…EV-23).
- Discovery bounded to the workspace root (no upward discovery); a `gitdir:` file, `core.worktree` or worktree link pointing outside the workspace is flagged and not followed; submodules not recursed in Phase 1.
- Tree/diff views do not follow symlinks out of the workspace (target shown as text); files with link count > 1 are flagged.
- LFS: native clean direction (SHA-256 + size → pointer) for comparison; other filters → stat-only, marked "unverified"; never "modified" from an unfiltered comparison; built-in eol/`ident`/encoding conversions handled natively.
- Enforcement: Git computations run in a worker process with exec denied by the OS (macOS Seatbelt `process-exec` deny; Linux seccomp on `execve`/`execveat` or Landlock), read-only workspace, no network. CI fails if any `execve` occurs on the S8 fixture set.

**D26 — Purge (MODIFY)**
- Procedure: `PRAGMA secure_delete=ON` at every connection open → delete → full `VACUUM` → `wal_checkpoint(TRUNCATE)`; temporary pre-migration copies are deleted by purge too (EV-25).
- Data directory excluded from Time Machine by default with a visible setting (owner U23); APFS local snapshots and user-made copies documented as residual.

**D31 — Write lease (MODIFY)**
- The lease is a journaled record. It is released only when the holder's process is `exited` and no tracked descendant is alive; `orphan_alive` holds it. Lease transfer requires terminating or confirming background processes (e.g. Codex background terminals).
- For providers that cannot enforce read-only (no OS sandbox, `danger-full-access`), a second session on the same worktree is **refused** and a separate worktree is offered (recommendation; owner U24).

**D32 — Provider lifetime containment (MODIFY)**
- **Unit of containment:** all descendants, including those that changed session or process group.
- **Linux (guarantee):** one cgroup per provider (systemd transient scope or delegated subtree with `Delegate=yes`), killed with `cgroup.kill`; the daemon refuses to start providers outside a cgroup it controls, or marks containment `best effort`. `KillMode=control-group` on the unit; outcomes after restart recorded as `killed_by_restart`. Remote-host setup checks `loginctl enable-linger` and warns. PR_SET_PDEATHSIG is secondary: set from one dedicated, never-exiting spawner thread, with a parent re-check after `prctl`; not relied upon under U11 (EV-19, EV-20).
- **macOS (best effort, residual shown):** a helper is the provider's parent (stdio passthrough), started **before** the provider; it tracks descendants (process-exit watch on known pids plus a sweep at B9-compatible intervals), records every pid with start time, and on parent EOF sends SIGTERM to all tracked descendants, then SIGKILL after 5 s; if the provider exits first, the helper reports and exits. The helper is crash safety, **not** an adversarial control (a same-UID agent can kill it).
- **Identity:** records include boot id; Linux uses pidfds for signalling; `provider_spawn_intent` is journaled before spawn.
- **Protocol first:** on cancel/terminate, ask the provider to stop background processes where supported (Codex `thread/backgroundTerminals/terminate`, EV-27).
- **U11 interaction:** a separate agent UID requires a privileged spawner that spawns, contains (cgroup) and kills on the daemon's behalf and authenticates the daemon; Git trust for agent-owned repositories must be specified. Until then U11 is "recommended, mechanism TBD".
- **Mid-operation termination:** turns end `killed_mid_tool` with a workspace notice (lock files present, diff since turn start); no automatic cleanup.
