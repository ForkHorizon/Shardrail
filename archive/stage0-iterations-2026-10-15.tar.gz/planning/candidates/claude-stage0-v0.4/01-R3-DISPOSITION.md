# 01 — Disposition of Round r03 Findings

> **Candidate:** v0.4 · **Status:** PROPOSED — NOT OWNER-APPROVED · Claude (Opus 5.5), 2026-10-15
> **Source:** `../../reviews/claude-fresh-r03/01-REVIEW.md` (R3-01…R3-34). Not edited. r03 evidence EV3-01…EV3-10 is renumbered **EV-19…EV-28** from here on.
> Marks: **ACCEPT** · **ACCEPT-MOD** (adopted, modification stated) · **OWNER** (owner decides; recommendation given) · **REJECT**.

| ID | Sev. | Topic | Mark | v0.4 position | Where |
| --- | --- | --- | --- | --- | --- |
| R3-01 | BLOCKING | Protection is host-level, not per session | ACCEPT | Host protection state `protected`/`unprotected`, sticky until explicit re-establish; per-session marker only as cause | 02 D20 |
| R3-02 | BLOCKING | Provider-side approval config bypasses Shardrail | ACCEPT-MOD | Boundary item (d) + pin approval-relevant settings at launch + snapshot/change-flag. Pre-creating `.codex/` in the workspace → owner question U20 (it writes into the user's repo). Rule-file effect on Codex approvals remains INFERRED until S7 | 02 D20, U20 |
| R3-03 | IMPORTANT | Deferred-execution paths | ACCEPT | Boundary restated as "writes confined to writable roots + temp, minus provider-config paths"; explicit time scope | 02 D20 |
| R3-04 | IMPORTANT | Approved out-of-sandbox actions | ACCEPT | Third option class `boundary-breaking` | 02 D19, D20 |
| R3-05 | IMPORTANT | SSH agent, TCC, deep links, keychain, debugging | ACCEPT-MOD | Scrub `SSH_AUTH_SOCK`/GPG sockets; SSH admission alone = `limited`; `full` over the bridge needs the desktop's keychain-held client key; deep links never carry approval/policy/pairing; TCC and debugging documented as void-conditions; hardened runtime. TCC "responsibility disclaim" left as REQUIRES FUTURE EXPERIMENT | 02 D20, D21 |
| R3-06 | IMPORTANT | Server auth / challenge-response | ACCEPT | Asymmetric keys, daemon identity key in keychain (macOS) / file (Linux, documented weakness), remote daemon key pinned end to end through the bridge, transcript-bound mutual handshake (Noise-style pattern; concrete pattern chosen at L2-05) | 02 D21 |
| R3-07 | MINOR | MAC deferral rationale | ACCEPT | Rationale corrected; MAC (+ monotonic counter) becomes the Phase 2 mechanism for "re-establish protection" on macOS | 02 D20 |
| R3-08 | IMPORTANT | Acknowledgement habituation; pre-registered rule | ACCEPT-MOD | Decision rule pre-registered now (see D20); the threshold itself is owner question U21 with a recommended default | 02 D20, U21 |
| R3-09 | IMPORTANT | Git config/env/discovery isolation | ACCEPT | Rule extended to every config scope, attribute and environment variable; discovery bounded; symlink/hardlink rules | 02 D23 |
| R3-10 | IMPORTANT | LFS UX | ACCEPT | Native LFS clean (hash + size → pointer); other filters → stat-only "unverified"; never "modified" from unfiltered bytes | 02 D23 |
| R3-11 | IMPORTANT | Enforce no-exec structurally | ACCEPT | Git worker process with exec denied by the OS; CI test fails on any `execve` | 02 D23 |
| R3-12 | BLOCKING | Process groups miss detached descendants | ACCEPT | Unit of containment = all descendants. Linux: per-provider cgroup (guarantee). macOS: best effort, residual risk shown. Protocol-level termination of background processes | 02 D32 |
| R3-13 | IMPORTANT | PDEATHSIG semantics | ACCEPT | Dedicated spawner thread; parent re-check; secondary to cgroup; not relied on under U11 | 02 D32 |
| R3-14 | IMPORTANT | systemd scope, linger, selective kill | ACCEPT | Per-provider sub-cgroups (`Delegate=yes`); refuse/flag when not in a controllable cgroup; linger check; `killed_by_restart` outcome | 02 D32, 04 |
| R3-15 | IMPORTANT | pid identity, TOCTOU, spawn window | ACCEPT | boot id; pidfds on Linux; `provider_spawn_intent` before spawn; macOS helper started first | 02 D32 |
| R3-16 | IMPORTANT | D32 × U11 unspecified | ACCEPT | U11 downgraded to "recommended, mechanism TBD"; requirements for the privileged spawner listed | 03 U11 |
| R3-17 | IMPORTANT | Terminate mid-operation; lease after restart | ACCEPT | Journaled lease; released only when process `exited` and no tracked descendants; `killed_mid_tool` + workspace notice | 02 D31, 04 |
| R3-18 | MINOR | Helper failure modes | ACCEPT | Topology and kill policy specified; non-adversarial scope stated | 02 D32 |
| R3-19 | MINOR | U18 vs approval table naming; version skew | ACCEPT | `withdrawn(orphan_timeout)`; version-mismatch rule | 02 D11, 04 |
| R3-20 | BLOCKING | `responded_unacked → withdrawn` erases a delivered allow | ACCEPT | New terminal state `delivered_unconfirmed(allow|deny)`; only a JSON-RPC error on the response yields `withdrawn` | 04 §4 |
| R3-21 | IMPORTANT | `idle` with live execution | ACCEPT-MOD | New turn state `detached`. For desynced-with-process-alive, v0.4 defaults to **user-confirmed** termination with a top-priority badge, and **automatic** termination after `T_grace` only when no client is attached (owner U22) — auto-killing a working agent while the user watches would destroy work | 04 §3 |
| R3-22 | IMPORTANT | "impossible → notice" misclassifies | ACCEPT | Four cell kinds; rows list route/ignore cells explicitly | 04 |
| R3-23 | IMPORTANT | Badge precedence | ACCEPT | Protection is a host overlay; `degraded` = abnormal only; new badges | 04 §7 |
| R3-24 | IMPORTANT | Approval events mis-anchored; no timers | ACCEPT | Anchored on cancel *requested*; `T_ack`; process/link columns; "workspace changed" defined | 04 §4 |
| R3-25 | IMPORTANT | Process table gaps | ACCEPT | `exited(lost)`, `leader_exited`, `kill_failed`, `T_kill`, shared-process confirmation | 04 §1 |
| R3-26 | IMPORTANT | Link table gaps | ACCEPT | `T_resume`, dispatch guard, restart = `none`, tombstoned ids | 04 §2–§3 |
| R3-27 | IMPORTANT | Delivery table gaps | ACCEPT | `failed(reason)`, in-flight loss → `unknown`, resend guard, approval responses excluded | 04 §5 |
| R3-28 | MINOR | Timer coherence | ACCEPT | Timer table; `deny_after` default explicit | 04 §6 |
| R3-29 | MINOR | Cell inconsistencies | ACCEPT | Mirrored rows; outcome from provider stop reason | 04 §3 |
| R3-30 | IMPORTANT | Purge order / no-op pragma | ACCEPT | `secure_delete` on at open → delete → full `VACUUM` → `wal_checkpoint(TRUNCATE)`; pre-migration copies purged; Time Machine exclusion default (owner U23); APFS snapshots documented as residual | 02 D26 |
| R3-31 | MINOR | Unknown option kinds | ACCEPT | Fail closed to `widening`; to `boundary-breaking` if sandbox/permission semantics are indicated | 02 D19 |
| R3-32 | MINOR | Disposition fidelity | ACCEPT | v0.3 disposition errata recorded; omitted items added to spikes | 06 |
| R3-33 | MINOR | Dev-mode flag | ACCEPT | Build-time constant; developer builds always `unprotected` | 02 D21 |
| R3-34 | QUESTION | Lease for unsandboxed providers | OWNER | Recommend **refuse** a second session on a worktree when the provider cannot enforce read-only; offer a separate worktree instead (U24) | 02 D31 |

**Rejected:** none. Differences from r03 are in defaults that touch the user's work or repository (R3-02 `.codex/` pre-creation, R3-21 auto-termination, R3-30 Time Machine) — these go to the owner.
