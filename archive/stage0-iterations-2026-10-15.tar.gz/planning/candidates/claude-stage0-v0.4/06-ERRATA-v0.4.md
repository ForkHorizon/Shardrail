# 06 — Errata to v0.3 (frozen) and Evidence Renumbering

> **Status:** PROPOSED. v0.3 files are not edited; read them together with this list.

| v0.3 location | Erratum | Driver |
| --- | --- | --- |
| `01-R2-DISPOSITION.md` R2-05 | Mark should be **ACCEPT-MOD**: v0.3 replaced full cell enumeration with a blanket rule; v0.4 §0 defines four cell kinds instead | R3-32 |
| `01-R2-DISPOSITION.md` R2-09 | "Measure per-provider limits in X-05 before setting a default" was dropped; restored in v0.4 `05` §1 (S1) | R3-32 |
| `01-R2-DISPOSITION.md` R2-11 | Candidate switch `CLAUDE_CODE_DISABLE_AUTO_MEMORY=1` restored to the S4 checklist | R3-32 |
| `01-R2-DISPOSITION.md` R2-16 | D26's pre-migration copy reintroduced an automatic copy; v0.4 purge covers it | R3-30 |
| `01-R2-DISPOSITION.md` R2-01 | MAC deferral rationale was wrong (MAC does help on macOS against unsandboxed same-UID agents); deferral kept because provider-config bypass (R3-02) defeats it anyway; MAC becomes the re-establish mechanism | R3-07 |
| `02-DECISION-REGISTER-v0.3.md` D20 | Per-session guarantee and label are wrong; protection is host-level and sticky | R3-01 |
| `02-DECISION-REGISTER-v0.3.md` D20 | "SSH host key for remote" authenticates the host, not the daemon | R3-06 |
| `02-DECISION-REGISTER-v0.3.md` D21 | SSH admission ⇒ `full` is wrong (`SSH_AUTH_SOCK` reachable by agents) | R3-05 |
| `02-DECISION-REGISTER-v0.3.md` D26 | Purge order wrong; `incremental_vacuum` is a no-op without `auto_vacuum=incremental` (EV-25) | R3-30 |
| `02-DECISION-REGISTER-v0.3.md` D32 | Process groups + PDEATHSIG do not contain detached descendants; PDEATHSIG is thread-scoped (EV-19) | R3-12, R3-13 |
| `04-STATE-TRANSITIONS.md` §4 | `responded_unacked → withdrawn` (turn end, cancel, restart) erases delivered decisions | R3-20 |
| `04-STATE-TRANSITIONS.md` §3 | `idle + unknown_after_restart` while process `orphan_alive` is wrong (→ `detached`) | R3-21 |
| `04-STATE-TRANSITIONS.md` §6 | Badge precedence wrong; `degraded` included normal exits | R3-23 |
| `90-CONSISTENCY-v0.3.md` C-24 | "Outside agent-writable paths" does not exist on a shared UID; flag is a build-time constant | R3-33 |

## Evidence renumbering

| r03 ID | v0.4 ID | Source |
| --- | --- | --- |
| EV3-01 | EV-19 | man7 PR_SET_PDEATHSIG |
| EV3-02 | EV-20 | systemd.kill(5) |
| EV3-03 | EV-21 | git-config |
| EV3-04 | EV-22 | git(1) environment |
| EV3-05 | EV-23 | gix open permissions |
| EV3-06 | EV-24 | gix-filter pipeline options |
| EV3-07 | EV-25 | SQLite pragmas |
| EV3-08 | EV-26 | ACP prompt turn |
| EV3-09 | EV-27 | Codex app-server background terminals |
| EV3-10 | EV-28 | Codex sandbox docs (`.git`, `.codex` protection) |
