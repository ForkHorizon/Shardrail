# Review Routes — Minimal Context Packs

**Rule:** Each review starts with one domain document. Read adjacent material only when required to validate a specific dependency or cross-domain assertion. Never require all Level 1 documents by default.

| Review domain | Primary file | Suggested supporting file(s), only when needed |
| --- | --- | --- |
| Product scope | [`01-product-foundation`](../level-1/01-product-foundation.md) | 02-requirements |
| Requirements | [`02-requirements`](../level-1/02-requirements.md) | 01-product-foundation |
| Technology | [`03-technology-selection`](../level-1/03-technology-selection.md) | 09-performance, 14-decisions-risks-open-questions |
| System architecture | [`04-system-and-process-architecture`](../level-1/04-system-and-process-architecture.md) | 05-provider-integrations, 07-data-synchronization-recovery |
| Provider protocols | [`05-provider-integrations`](../level-1/05-provider-integrations.md) | 08-security-and-trust, 04-system-and-process-architecture |
| Sessions and handoff | [`06-session-events-and-handoff`](../level-1/06-session-events-and-handoff.md) | 07-data-synchronization-recovery |
| Persistence and recovery | [`07-data-synchronization-recovery`](../level-1/07-data-synchronization-recovery.md) | 06-session-events-and-handoff |
| Security | [`08-security-and-trust`](../level-1/08-security-and-trust.md) | 05-provider-integrations |
| Performance | [`09-performance`](../level-1/09-performance.md) | 03-technology-selection |
| UI/UX | [`10-interface-and-visual-system`](../level-1/10-interface-and-visual-system.md) | 09-performance |
| Testing and reliability | [`11-quality-observability-reliability`](../level-1/11-quality-observability-reliability.md) | 02-requirements |
| Distribution and licensing | [`12-release-distribution-licensing`](../level-1/12-release-distribution-licensing.md) | 03-technology-selection |
| Roadmap | [`13-global-delivery-roadmap`](../level-1/13-global-delivery-roadmap.md) | 14-decisions-risks-open-questions |
| Decision/risk consistency | [`14-decisions-risks-open-questions`](../level-1/14-decisions-risks-open-questions.md) | Relevant domain file identified by the decision ID |
| Evidence provenance | [`15-original-self-review-and-evidence`](../level-1/15-original-self-review-and-evidence.md) | Relevant domain file identified by the claim |

## Context discipline

- Reviewers may request another domain document when they can state what must be checked and why.
- Cross-references such as F#, N#, B#, D#, R#, U#, S# should be cited by their stable original IDs.
- Original § numbers remain stable and are mapped in `SOURCE_MAP.md`.
- If a question requires a whole-system review, perform that separately after domain reviews; don't silently expand every individual review to the full plan.
- The original Russian source preamble defines Verified / Plausible / Unsupported and distinguishes performance budgets from benchmarks; each review should inherit that caveat.
