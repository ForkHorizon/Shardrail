# Stage 0 — Independent Architecture Review Protocol

## Nonnegotiable rules

- **Stage 0 only:** research, documentation, critique, and architecture reconciliation. No product code, prototypes, installs, configuration changes, commits, deployments, or live-provider execution.
- **English only:** English for new/revised technical documents, reviewer reports, ADRs and agent instructions. The immutable Russian source is retained solely for traceability.
- **Review one domain at a time:** use the minimal context packs defined in `REVIEW_ROUTES.md`.
- **Independent first pass:** each reviewer receives the same approved draft snapshot, without another reviewer's conclusions.
- **Owner authority:** no model may declare a decision approved on its own. No implementation follows from an accepted review.
- **Preserve uncertainty:** source labels such as Verified/Plausible/Unsupported and performance 'budget, not measurement' are not silently upgraded.
- **No Level 2 or Level 3:** this stage only tests the global architecture and phase boundaries.

## Review lifecycle

1. Select domain + stable draft revision.
2. Prepare minimal context and versioned review prompt.
3. Save independent review as `reviews/<domain>/<reviewer>-r01.md`.
4. Compare reviews and record disagreements in a reconciliation note.
5. Evidence-check contested facts before rewriting architecture.
6. Propose targeted edits with original IDs and exact affected sections.
7. Owner approves/rejects/defers each change.
8. Update English domain draft and linked decisions/risks, add changelog entry.
9. Repeat review as needed; freeze Level 1 baseline only after explicit owner signoff.

## Status labels

- `DRAFT`: source-derived plan, not independently accepted.
- `IN_REVIEW`: frozen review candidate for the current round.
- `CHANGES_REQUESTED`: review findings awaiting resolution.
- `APPROVED`: owner explicitly accepted this domain at Level 1.
- `DEFERRED`: unresolved item recorded, with a non-misleading dependency/gate.

## Change discipline

Avoid multiple canonical copies of the same decision. Architecture body lives in its topical document; the original decision/risk register remains a crosscutting source of IDs until its English replacement is approved. Review comments must not be edited into the original source archive.
