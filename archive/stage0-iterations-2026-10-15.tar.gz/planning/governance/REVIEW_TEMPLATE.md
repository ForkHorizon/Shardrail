# Independent Review — TEMPLATE

- **Product:** Shardrail / Fork Horizon
- **Stage:** 0 (planning only)
- **Review domain:** `<one Level 1 file>`
- **Baseline revision / hash:** `<hash or commit>`
- **Reviewer/model:** `<name and version>`
- **Review round:** `01`
- **Scope supplied:** `<primary file + optional specifically justified dependencies>`
- **Review date:** `<YYYY-MM-DD>`

## 1. Scope and assumptions

State what you actually reviewed. Note anything not provided; do not assume unseen sections say what you hope they say.

## 2. Findings

For each actionable finding, provide:

- ID: `REVIEW-XX`
- Severity: `BLOCKING | IMPORTANT | MINOR | QUESTION`
- Exact section or stable source ID: `D#, F#, R#, U#, S#, B#` as applicable
- Claim or proposal being challenged
- Evidence (primary source where external verification matters)
- Why the concern matters
- Alternative or required clarification
- Dependencies / impact on other documents

## 3. Architectural disagreements

Present the strongest supported alternative, not a generic preference.

## 4. Unknowns requiring research

Do not manufacture verification. Separate known facts and assumptions.

## 5. Impact summary

List impacted documents and the minimum changes needed for another review.

## 6. Recommendation

`ACCEPT | ACCEPT WITH CHANGES | REWORK | INSUFFICIENT EVIDENCE`

**This report cannot authorize implementation or overrule the project owner.**
