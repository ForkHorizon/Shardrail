# Source Map — Lossless Stage 0 Split

Original source: `planning/source/MASTER_PLAN.original.ru.md`. Original section bodies are preserved verbatim (no translation, no architecture review).

| Original section | Source line range | New Level 1 document |
| --- | --- | --- |
| §1: Краткое резюме | 19–43 | [link](../level-1/01-product-foundation.md) |
| §2: Видение, сценарии и границы | 44–97 | [link](../level-1/01-product-foundation.md) |
| §3: Требования | 98–133 | [link](../level-1/02-requirements.md) |
| §4: Выбор технологий и альтернативы | 134–213 | [link](../level-1/03-technology-selection.md) |
| §5: Границы системы и обязанности | 214–279 | [link](../level-1/04-system-and-process-architecture.md) |
| §6: Процессы: локально и удалённо | 280–315 | [link](../level-1/04-system-and-process-architecture.md) |
| §7: Адаптеры и матрица возможностей | 316–368 | [link](../level-1/05-provider-integrations.md) |
| §8: Сессия, события, задачи | 369–406 | [link](../level-1/06-session-events-and-handoff.md) |
| §9: Данные, синхронизация, восстановление | 407–442 | [link](../level-1/07-data-synchronization-recovery.md) |
| §10: Безопасность | 443–479 | [link](../level-1/08-security-and-trust.md) |
| §11: Производительность | 480–508 | [link](../level-1/09-performance.md) |
| §12: Интерфейс и визуальная система | 509–532 | [link](../level-1/10-interface-and-visual-system.md) |
| §13: Проверка, наблюдаемость, надёжность | 533–559 | [link](../level-1/11-quality-observability-reliability.md) |
| §14: Сборка, поставка, обновления | 560–575 | [link](../level-1/12-release-distribution-licensing.md) |
| §15: GitHub, лицензия, распространение | 576–592 | [link](../level-1/12-release-distribution-licensing.md) |
| §16: Дорожная карта | 593–639 | [link](../level-1/13-global-delivery-roadmap.md) |
| §17: Зависимости, журнал решений, риски | 640–704 | [link](../level-1/14-decisions-risks-open-questions.md) |
| §18: Открытые вопросы | 705–723 | [link](../level-1/14-decisions-risks-open-questions.md) |
| §19: Критический пересмотр | 724–749 | [link](../level-1/15-original-self-review-and-evidence.md) |
| §20: Доказательства | 750–778 | [link](../level-1/15-original-self-review-and-evidence.md) |

The original preamble (status, verification definitions, and budget disclaimers) is preserved in the source file and must be considered in every review.
