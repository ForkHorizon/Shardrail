# Shardrail — Master Plan Index (Level 1)

**Organization:** Fork Horizon  
**Stage:** 0 — Architecture Sandbox  
**Plan status:** DRAFT / AWAITING INDEPENDENT REVIEW AND OWNER APPROVAL  
**Implementation:** NOT AUTHORIZED  
**Planning document language:** English is mandatory for all new and revised documents.

## Purpose

This is the **global navigation document**, not a duplicate of the detailed source plan. Its job is to identify the main project domains and phases, route reviewers to the smallest relevant context, and preserve dependencies. It is not a Level 2 module specification or a Level 3 implementation task list.

## High-level product boundaries (source-derived)

Shardrail is a Fork Horizon unified workspace for local and remote coding agents (Codex, Claude Code, Grok, Hermes). The source draft proposes a host-local daemon, thin clients, provider-specific adapters, an event journal, explicit approvals, a read-only workspace view, and a user-reviewed handoff. All of these remain **proposals**, not approved commitments.

## Global delivery phases

| Phase | Original purpose | Implementation authority during Stage 0 |
| --- | --- | --- |
| Phase 0 | Protocol and UI feasibility spikes (S1–S6) | **Not authorized**; these may involve disposable code later |
| Phase 1 | Local macOS daemon, UI, sessions, provider adapters | **Not authorized** |
| Phase 2 | Remote Linux execution and continuous operation | **Not authorized** |
| Phase 3 | Android client | **Not authorized** |
| Phase 4 | Explicit task handoff and worktree clarity | **Not authorized** |

**Terminology:** Planning *Stage 0* is a discussion/research-only governance state. Delivery *Phase 0* in the source plan proposes experiments; it does **not** grant permission to write code during Stage 0.

## Reviewable Level 1 documents

| Domain document | Original sections | Review focus |
| --- | --- | --- |
| [01. Product Vision and Scope](level-1/01-product-foundation.md) | 1, 2 | Purpose, supported workflows, and explicit boundaries. |
| [02. Functional and Nonfunctional Requirements](level-1/02-requirements.md) | 3 | Functional requirements F1–F13, nonfunctional requirements N1–N9, and acceptance language. |
| [03. Technology Selection and Alternatives](level-1/03-technology-selection.md) | 4 | Language, shell, UI, storage, and transport candidates, plus local environment assumptions. |
| [04. System and Process Architecture](level-1/04-system-and-process-architecture.md) | 5, 6 | Component responsibilities, daemon ownership, local and remote processes, and session lifecycle. |
| [05. Provider Integration and Capabilities](level-1/05-provider-integrations.md) | 7 | Adapter contracts, per-provider capabilities, protocol-specific handling, and limitations. |
| [06. Session, Events, and Handoff](level-1/06-session-events-and-handoff.md) | 8 | Identifiers, event journal semantics, and explicit task transfer boundaries. |
| [07. Data, Synchronization, and Recovery](level-1/07-data-synchronization-recovery.md) | 9 | Data ownership, single-writer model, disconnection behavior, and persistence. |
| [08. Security and Trust Boundaries](level-1/08-security-and-trust.md) | 10 | Threat model, execution controls, secrets, logging, and approval boundaries. |
| [09. Performance and Resource Budgets](level-1/09-performance.md) | 11 | Resource budgets B1–B10, measuring methodology, UI event workload, and scope of measurements. |
| [10. UI/UX and Visual System](level-1/10-interface-and-visual-system.md) | 12 | Product interaction principles, accessibility, visual constraints, and UI primitives. |
| [11. Quality, Observability, and Reliability](level-1/11-quality-observability-reliability.md) | 13 | Contract testing, operational diagnostics, failure recovery, and reliability behavior. |
| [12. Packaging, Delivery, and Licensing](level-1/12-release-distribution-licensing.md) | 14, 15 | Delivery targets, provider updates, repository policy, and distribution/licensing assumptions. |
| [13. Global Delivery Roadmap](level-1/13-global-delivery-roadmap.md) | 16 | Phase 0 spikes and Phases 1–4, major outputs, and phase gates. |
| [14. Decisions, Risks, and Open Questions](level-1/14-decisions-risks-open-questions.md) | 17, 18 | Dependency graph, decisions D1–D15, risks R1–R14, and unknowns U1–U8. |
| [15. Original Self-Review and Evidence](level-1/15-original-self-review-and-evidence.md) | 19, 20 | The drafting agent’s own retrospective and the source bibliography; not an independent review. |

## How independent reviews work

1. Select exactly one Level 1 domain document.
2. Provide that file plus only the dependencies required to evaluate it. See [Review Routes](governance/REVIEW_ROUTES.md).
3. Run reviewers independently; do not expose one model's review to the next before its own assessment.
4. Save each review as a new document under `reviews/`, without overwriting the baseline.
5. Reconcile evidence and proposed changes, documenting unresolved disagreements.
6. Apply changes to the affected document only after owner approval; update cross-document decision references and this index if needed.
7. Do not expand into Level 2 module plans or Level 3 tasks until the corresponding global architecture is approved.

See [Review Protocol](governance/REVIEW_PROTOCOL.md) and [Review Template](governance/REVIEW_TEMPLATE.md).

## Source preservation and English normalization

The uploaded source was written in Russian, despite the project’s English-only documentation policy. This package **does not silently translate or reinterpret technical claims**. Instead, it keeps a byte-for-byte original under [`source/MASTER_PLAN.original.ru.md`](source/MASTER_PLAN.original.ru.md), and splits original content into smaller domain documents. Domain contents are therefore *intermediate, not yet English-normalized*. Before circulating a domain for a full model review, translate **that domain only** to English under the controlled procedure in [Translation Procedure](translation/TRANSLATION_PROCEDURE.md). Preserve IDs, tables, citations and source traceability.

## Traceability

[Source Map](governance/SOURCE_MAP.md) maps every original numbered section to its new domain file. `manifest.json` contains source hashes and extraction metadata. The source is authoritative for what the drafting agent actually wrote; future approved English documents will be authoritative for the product architecture, with explicit change records.

## Stage 0 review round artifacts (PROPOSED — not approved)

Added 2026-10-15 by Claude review round `claude-stage0-r01`. These do not change the baseline above.

| Layer | Location |
| --- | --- |
| Translation record | [translation/records/2026-10-15-claude-en-r01.md](translation/records/2026-10-15-claude-en-r01.md) |
| Inventory, independent review, stress test | [reviews/claude-stage0-r01/](reviews/claude-stage0-r01/) |
| Architecture Candidate v0.2 (delta) | [candidates/claude-stage0-v0.2/00-INDEX.md](candidates/claude-stage0-v0.2/00-INDEX.md) |
| Proposed Level 2 outlines | [level-2/proposed/00-MODULE-INDEX.md](level-2/proposed/00-MODULE-INDEX.md) |
| Proposed backlog | [backlog/proposed/BACKLOG.md](backlog/proposed/BACKLOG.md) |
| Reviewer handoff, packets, checkpoint, summary | [handoffs/claude-stage0/](handoffs/claude-stage0/REVIEWER-HANDOFF.md) |
| Fresh-context re-review (round r02) | [reviews/claude-fresh-r02/](reviews/claude-fresh-r02/01-REVIEW.md) |
| Architecture Candidate v0.3 (delta over v0.2) | [candidates/claude-stage0-v0.3/00-INDEX.md](candidates/claude-stage0-v0.3/00-INDEX.md) |
| Architecture Candidate v0.4 (delta over v0.3, after r03) | [candidates/claude-stage0-v0.4/00-INDEX.md](candidates/claude-stage0-v0.4/00-INDEX.md) |
